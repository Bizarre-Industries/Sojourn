// App icon showcase — macOS-style spec sheet for Sojourn.
// Shows: hero · 5 modes (light/dark/tinted/liquid glass light/liquid glass dark) ·
//        scale ladder · menu bar treatments · grid construction.

const IconShowcase = () => (
  <div style={{
    width: '100%', height: '100%',
    background: 'var(--bg-primary, #f4f4f2)',
    color: 'var(--text-primary, #1a1a1c)',
    display: 'grid',
    gridTemplateColumns: '1.05fr 1fr',
    gridTemplateRows: 'auto 1fr',
    fontFamily: 'var(--f-sans), -apple-system, system-ui, sans-serif',
  }}>
    {/* Top strip — eyebrow + headline lockup */}
    <div style={{
      gridColumn: '1 / -1',
      padding: '36px 48px 28px',
      borderBottom: '0.5px solid var(--hairline)',
      display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 40,
    }}>
      <div>
        <Eyebrow>BIZARRE / SOJOURN / APP ICON · v0.1</Eyebrow>
        <div style={{
          fontFamily: 'var(--f-stencil), Impact, sans-serif',
          fontWeight: 800,
          fontSize: 76,
          lineHeight: 0.92,
          letterSpacing: '0.01em',
          marginTop: 14,
          textTransform: 'uppercase',
        }}>
          ONE MARK.<br/>
          <span className="lime-chip">FIVE</span> RENDERS.
        </div>
        <div style={{maxWidth: 540, marginTop: 18, color: 'var(--text-secondary)', fontSize: 14, lineHeight: 1.5}}>
          The same stencil S, drawn for the macOS 1024-grid with the standard
          100 pt safe area. System swaps between Light, Dark, Tinted, and
          Liquid Glass at runtime. Menu bar gets a separate template image.
        </div>
      </div>
      {/* Hero icon — Light mode */}
      <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:14, flexShrink:0}}>
        <div style={{
          width: 220, height: 220,
          filter: 'drop-shadow(0 28px 56px rgba(168,224,0,0.28)) drop-shadow(0 10px 20px rgba(0,0,0,0.40))',
        }}>
          <IconLight size={220}/>
        </div>
        <div className="mono" style={{fontSize:10, color:'var(--text-tertiary)', letterSpacing:'0.08em'}}>
          1024PT MASTER · ICONCOMPOSER
        </div>
      </div>
    </div>

    {/* LEFT COLUMN — Five rendering modes */}
    <div style={{padding: '32px 48px', borderRight: '0.5px solid var(--hairline)', overflow: 'hidden'}}>
      <Eyebrow>RENDERING MODES</Eyebrow>
      <div style={{
        marginTop: 18,
        display: 'grid',
        gridTemplateColumns: 'repeat(5, 1fr)',
        gap: 10,
      }}>
        {/* Light */}
        <div style={{
          padding: 14,
          background: '#F4F4F2',
          borderRadius: 8,
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10,
          border: '0.5px solid rgba(0,0,0,0.10)',
        }}>
          <IconLight size={88}/>
          <div className="mono" style={{fontSize:8.5, color:'rgba(0,0,0,0.7)', letterSpacing:'0.08em', textAlign:'center'}}>LIGHT</div>
        </div>
        {/* Dark */}
        <div style={{
          padding: 14,
          background: '#0E0E0E',
          borderRadius: 8,
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10,
          border: '0.5px solid rgba(255,255,255,0.06)',
        }}>
          <IconDark size={88}/>
          <div className="mono" style={{fontSize:8.5, color:'rgba(255,255,255,0.7)', letterSpacing:'0.08em', textAlign:'center'}}>DARK</div>
        </div>
        {/* Tinted */}
        <div style={{
          padding: 14,
          background: '#0E0E0E',
          borderRadius: 8,
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10,
          border: '0.5px solid rgba(255,255,255,0.06)',
        }}>
          <IconTinted size={88}/>
          <div className="mono" style={{fontSize:8.5, color:'rgba(255,255,255,0.7)', letterSpacing:'0.08em', textAlign:'center'}}>TINTED</div>
        </div>
        {/* Liquid Glass — Light wallpaper */}
        <div style={{
          padding: 14,
          background: 'linear-gradient(135deg, #FFE4B5 0%, #C9A8FF 50%, #87CEEB 100%)',
          borderRadius: 8,
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10,
          position: 'relative',
        }}>
          <IconLiquidGlass size={88} wallpaper="light"/>
          <div className="mono" style={{fontSize:8.5, color:'rgba(0,0,0,0.75)', letterSpacing:'0.08em', textAlign:'center'}}>GLASS · LIGHT</div>
        </div>
        {/* Liquid Glass — Dark wallpaper */}
        <div style={{
          padding: 14,
          background: 'linear-gradient(135deg, #2c1a4a 0%, #1a3a5a 50%, #0a2a3a 100%)',
          borderRadius: 8,
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10,
          position: 'relative',
        }}>
          <IconLiquidGlass size={88} wallpaper="dark"/>
          <div className="mono" style={{fontSize:8.5, color:'rgba(255,255,255,0.75)', letterSpacing:'0.08em', textAlign:'center'}}>GLASS · DARK</div>
        </div>
      </div>

      {/* Mode descriptions */}
      <div style={{marginTop: 18, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14}}>
        <div style={{padding: 12, background: 'rgba(255,255,255,0.5)', borderRadius: 6, border: '0.5px solid rgba(0,0,0,0.08)'}}>
          <div className="mono" style={{fontSize: 9, color:'var(--text-tertiary)', letterSpacing:'0.08em', marginBottom: 4}}>LIGHT · DEFAULT</div>
          <div style={{fontSize: 12, lineHeight: 1.45, color:'var(--text-secondary)'}}>
            Lime gradient squircle. Void mark. Standard Big Sur radius.
            Drop-shadow at runtime via system.
          </div>
        </div>
        <div style={{padding: 12, background: 'rgba(255,255,255,0.5)', borderRadius: 6, border: '0.5px solid rgba(0,0,0,0.08)'}}>
          <div className="mono" style={{fontSize: 9, color:'var(--text-tertiary)', letterSpacing:'0.08em', marginBottom: 4}}>DARK</div>
          <div style={{fontSize: 12, lineHeight: 1.45, color:'var(--text-secondary)'}}>
            Inverted figure-ground: dark slate body, lime mark with subtle
            bloom. Reads on Dock at small sizes.
          </div>
        </div>
        <div style={{padding: 12, background: 'rgba(255,255,255,0.5)', borderRadius: 6, border: '0.5px solid rgba(0,0,0,0.08)'}}>
          <div className="mono" style={{fontSize: 9, color:'var(--text-tertiary)', letterSpacing:'0.08em', marginBottom: 4}}>TINTED</div>
          <div style={{fontSize: 12, lineHeight: 1.45, color:'var(--text-secondary)'}}>
            Single monochrome glyph. System maps to the user's accent color
            via the macOS palette.
          </div>
        </div>
        <div style={{padding: 12, background: 'rgba(255,255,255,0.5)', borderRadius: 6, border: '0.5px solid rgba(0,0,0,0.08)'}}>
          <div className="mono" style={{fontSize: 9, color:'var(--text-tertiary)', letterSpacing:'0.08em', marginBottom: 4}}>LIQUID GLASS · macOS 26</div>
          <div style={{fontSize: 12, lineHeight: 1.45, color:'var(--text-secondary)'}}>
            Layered: substrate · refraction · mark · specular · bevel.
            Runtime parallax + tint pickup from wallpaper.
          </div>
        </div>
      </div>

      {/* Scale ladder */}
      <div style={{marginTop: 24}}>
        <Eyebrow>SCALE LADDER · macOS DOCK SIZES</Eyebrow>
        <div style={{
          marginTop: 16,
          padding: '24px 20px 18px',
          background: 'linear-gradient(180deg, #F4F4F2 0%, #E8E6E0 100%)',
          borderRadius: 8,
          border: '0.5px solid rgba(0,0,0,0.08)',
          display: 'flex',
          alignItems: 'flex-end',
          justifyContent: 'space-between',
          gap: 14,
        }}>
          {[16, 32, 64, 96, 128].map(sz => (
            <div key={sz} style={{display:'flex', flexDirection:'column', alignItems:'center', gap:8}}>
              <IconLight size={sz}/>
              <span className="mono" style={{fontSize:9, color:'rgba(0,0,0,0.6)', letterSpacing:'0.08em'}}>{sz}PT</span>
            </div>
          ))}
        </div>
      </div>
    </div>

    {/* RIGHT COLUMN — Menu bar + grid construction */}
    <div style={{padding: '32px 48px', overflow: 'hidden'}}>
      <Eyebrow>MENU BAR · TEMPLATE IMAGE</Eyebrow>

      {/* Menu bar — light wallpaper */}
      <div style={{
        marginTop: 18,
        background: 'linear-gradient(180deg, rgba(245,245,247,0.92), rgba(245,245,247,0.78))',
        backdropFilter: 'blur(20px)',
        borderRadius: 8,
        padding: '6px 14px',
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        fontSize: 12.5,
        color: '#1a1a1c',
        border: '0.5px solid rgba(0,0,0,0.10)',
        height: 26,
      }}>
        <SojournMenuBarIcon size={15} color="#1a1a1c"/>
        <span style={{fontWeight: 600}}>Sojourn</span>
        <span style={{color: '#1a1a1c', opacity: 0.85}}>File</span>
        <span style={{color: '#1a1a1c', opacity: 0.85}}>Edit</span>
        <span style={{color: '#1a1a1c', opacity: 0.85}}>Sync</span>
        <span style={{color: '#1a1a1c', opacity: 0.85}}>Window</span>
        <span style={{marginLeft: 'auto', display:'inline-flex', alignItems:'center', gap:14}}>
          <span style={{display:'inline-flex',alignItems:'center',gap:5, color:'#1a1a1c', opacity: 0.85}}>
            <SojournMenuBarIcon size={14} color="#1a1a1c"/>
            <span className="mono" style={{fontSize:10, letterSpacing:'0.05em', fontWeight:600}}>↑ 3</span>
          </span>
          <span style={{fontSize:11, opacity:0.7}}>Mon 28 Apr 14:30</span>
        </span>
      </div>

      {/* Menu bar — dark wallpaper */}
      <div style={{
        marginTop: 8,
        background: 'rgba(40,40,42,0.92)',
        backdropFilter: 'blur(20px)',
        borderRadius: 8,
        padding: '6px 14px',
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        fontSize: 12.5,
        color: '#f4f4f2',
        border: '0.5px solid rgba(255,255,255,0.08)',
        height: 26,
      }}>
        <SojournMenuBarIcon size={15} color="#f4f4f2"/>
        <span style={{fontWeight: 600}}>Sojourn</span>
        <span style={{opacity: 0.85}}>File</span>
        <span style={{opacity: 0.85}}>Edit</span>
        <span style={{opacity: 0.85}}>Sync</span>
        <span style={{opacity: 0.85}}>Window</span>
        <span style={{marginLeft: 'auto', display:'inline-flex', alignItems:'center', gap:14}}>
          <span style={{display:'inline-flex',alignItems:'center',gap:5, color:'var(--bzr-lime)'}}>
            <SojournMenuBarIcon size={14} color="var(--bzr-lime)"/>
            <span className="mono" style={{fontSize:10, letterSpacing:'0.05em', fontWeight:600}}>↑ 3</span>
          </span>
          <span style={{fontSize:11, opacity:0.7}}>Mon 28 Apr 14:30</span>
        </span>
      </div>

      {/* Menu bar template specimens */}
      <div style={{marginTop: 16, display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8}}>
        <div style={{padding: '20px 14px 12px', background: '#F4F4F2', borderRadius: 6, display:'flex', flexDirection:'column', alignItems:'center', gap:10, border: '0.5px solid rgba(0,0,0,0.08)'}}>
          <SojournMenuBarIcon size={22} color="#1a1a1c"/>
          <span className="mono" style={{fontSize:9, color:'rgba(0,0,0,0.6)', letterSpacing:'0.08em'}}>22PT · LIGHT</span>
        </div>
        <div style={{padding: '20px 14px 12px', background: '#0E0E0E', borderRadius: 6, display:'flex', flexDirection:'column', alignItems:'center', gap:10, border: '0.5px solid rgba(255,255,255,0.06)'}}>
          <SojournMenuBarIcon size={22} color="#f4f4f2"/>
          <span className="mono" style={{fontSize:9, color:'rgba(255,255,255,0.6)', letterSpacing:'0.08em'}}>22PT · DARK</span>
        </div>
        <div style={{padding: '20px 14px 12px', background: '#F4F4F2', borderRadius: 6, display:'flex', flexDirection:'column', alignItems:'center', gap:10, border: '0.5px solid rgba(0,0,0,0.08)'}}>
          <SojournMenuBarIcon16 size={22} color="#1a1a1c"/>
          <span className="mono" style={{fontSize:9, color:'rgba(0,0,0,0.6)', letterSpacing:'0.08em'}}>16PT · COMPACT</span>
        </div>
        <div style={{padding: '20px 14px 12px', background: 'linear-gradient(135deg, #FFE4B5, #C9A8FF)', borderRadius: 6, display:'flex', flexDirection:'column', alignItems:'center', gap:10}}>
          <SojournMenuBarIcon size={22} color="rgba(0,0,0,0.85)"/>
          <span className="mono" style={{fontSize:9, color:'rgba(0,0,0,0.7)', letterSpacing:'0.08em'}}>OVER · GLASS</span>
        </div>
      </div>

      <div style={{marginTop: 14, padding: 12, background: 'rgba(255,255,255,0.5)', borderRadius: 6, border: '0.5px solid rgba(0,0,0,0.08)'}}>
        <div className="mono" style={{fontSize: 9, color:'var(--text-tertiary)', letterSpacing:'0.08em', marginBottom: 4}}>NSImage.isTemplate = TRUE</div>
        <div style={{fontSize: 12, lineHeight: 1.45, color:'var(--text-secondary)'}}>
          Black + alpha only. The system handles light/dark/menubar-translucency
          inversion and high-contrast accessibility. Same SVG, single color.
        </div>
      </div>

      {/* Grid construction */}
      <div style={{marginTop: 22}}>
        <Eyebrow>GRID · 1024PT MASTER</Eyebrow>
        <div style={{
          marginTop: 16,
          padding: 18,
          background: '#F4F4F2',
          borderRadius: 8,
          border: '0.5px solid rgba(0,0,0,0.08)',
          display: 'flex',
          alignItems: 'center',
          gap: 18,
        }}>
          <div style={{position:'relative', width: 200, height: 200, flexShrink: 0}}>
            <IconLight size={200}/>
            {/* Overlay grid */}
            <svg width="200" height="200" viewBox="0 0 1024 1024" style={{position:'absolute', inset:0, pointerEvents:'none'}}>
              <rect x="100" y="100" width="824" height="824" fill="none" stroke="#FF3B30" strokeWidth="3" strokeDasharray="12 8" opacity="0.7"/>
              <rect x="200" y="200" width="624" height="624" fill="none" stroke="#007AFF" strokeWidth="3" strokeDasharray="12 8" opacity="0.7"/>
              <line x1="0" y1="512" x2="1024" y2="512" stroke="rgba(0,0,0,0.25)" strokeWidth="1.5" strokeDasharray="4 6"/>
              <line x1="512" y1="0" x2="512" y2="1024" stroke="rgba(0,0,0,0.25)" strokeWidth="1.5" strokeDasharray="4 6"/>
            </svg>
          </div>
          <div style={{flex:1, display:'flex', flexDirection:'column', gap:10, fontSize:12, lineHeight:1.45}}>
            <div className="row" style={{display:'flex', alignItems:'center', gap:8}}>
              <span style={{width:14, height:2, background:'#FF3B30', flexShrink:0, opacity:0.7}}></span>
              <span><b>Optical safe area</b> · 100 pt inset (Apple grid)</span>
            </div>
            <div className="row" style={{display:'flex', alignItems:'center', gap:8}}>
              <span style={{width:14, height:2, background:'#007AFF', flexShrink:0, opacity:0.7}}></span>
              <span><b>Mark frame</b> · 624 × 624 inside safe area</span>
            </div>
            <div className="row" style={{display:'flex', alignItems:'flex-start', gap:8}}>
              <span style={{width:14, height:2, background:'rgba(0,0,0,0.4)', flexShrink:0, marginTop:7}}></span>
              <span><b>Stencil cuts</b> · at 1/3 & 2/3 of frame height</span>
            </div>
            <div className="mono" style={{fontSize:10, color:'var(--text-tertiary)', letterSpacing:'0.08em', marginTop: 4}}>
              CORNER · 225PT · BIG SUR SQUIRCLE<br/>
              EXPORT · 16/32/64/128/256/512/1024
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

window.IconShowcase = IconShowcase;
