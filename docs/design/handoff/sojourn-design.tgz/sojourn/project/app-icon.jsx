// macOS app icon variants for Sojourn — Light, Dark, Tinted, Liquid Glass.
// Plus a 16pt menu bar template icon (monochrome, currentColor).
//
// Design language:
//   • The mark is a stencil "S" carved from a square frame — same as <SojournMark>
//     but redrawn for icon-grid math (1024 master, with 100pt safe-area inset
//     to match Apple's Big Sur/Sequoia/Tahoe icon grid).
//   • Light mode: lime gradient squircle with void mark.
//   • Dark mode: dark slate squircle with lime mark — inverts the figure-ground.
//   • Tinted: monochrome lime mark on a transparent dark substrate so the
//     system can pick up the user's chosen tint color.
//   • Liquid Glass: depth-stack — back plate (frosted gray), refraction layer,
//     mark layer (translucent void), specular highlight, edge bevel.
//   • Menu bar: template image — single-color (currentColor) at 16pt, with
//     2pt padding so it sits on the macOS baseline.

const { useState: useState_ICON } = React;

// ── The mark, redrawn at 1024-grid scale ─────────────────────
// Square frame at 200..824 (624×624 inside a 1024 canvas, 200pt margin).
// S glyph fills the frame with two stencil cuts at 1/3 and 2/3.
const SojournIconMark = ({ color = '#0E0E0E', frameStroke = 38, opacity = 1 }) => (
  <g opacity={opacity}>
    {/* outer square frame */}
    <rect x="200" y="200" width="624" height="624" rx="36" stroke={color} strokeWidth={frameStroke} fill="none"/>
    {/* stencil S — same proportions as small mark, scaled to 1024 grid */}
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      fill={color}
      d="
        M312 332 L312 484 L592 484 L592 540 L312 540 L312 692 L712 692 L712 540 L432 540 L432 484 L712 484 L712 332 Z
        M340 360 L684 360 L684 412 L340 412 Z
        M340 564 L684 564 L684 616 L340 616 Z
      "
    />
  </g>
);

// Standard macOS squircle path (1024-grid, ~225pt corner radius — Big Sur feel)
const SQUIRCLE_PATH = "M242 0h540c133.78 0 242 108.22 242 242v540c0 133.78-108.22 242-242 242H242C108.22 1024 0 915.78 0 782V242C0 108.22 108.22 0 242 0z";

// ── ICON: LIGHT MODE ─────────────────────────────────────────
const IconLight = ({ size = 256 }) => (
  <svg width={size} height={size} viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="il-bg" x1="0" y1="0" x2="0" y2="1024" gradientUnits="userSpaceOnUse">
        <stop offset="0" stopColor="#E0FF6B"/>
        <stop offset="1" stopColor="#A8E000"/>
      </linearGradient>
      <linearGradient id="il-shine" x1="0" y1="0" x2="0" y2="380" gradientUnits="userSpaceOnUse">
        <stop offset="0" stopColor="#FFFFFF" stopOpacity="0.40"/>
        <stop offset="1" stopColor="#FFFFFF" stopOpacity="0"/>
      </linearGradient>
      <radialGradient id="il-shadow" cx="512" cy="900" r="520" gradientUnits="userSpaceOnUse">
        <stop offset="0" stopColor="#000000" stopOpacity="0.18"/>
        <stop offset="1" stopColor="#000000" stopOpacity="0"/>
      </radialGradient>
    </defs>
    <path d={SQUIRCLE_PATH} fill="url(#il-bg)"/>
    <path d={SQUIRCLE_PATH} fill="url(#il-shadow)" opacity="0.6"/>
    <path d="M242 0h540c133.78 0 242 108.22 242 242v100C880 290 700 250 512 250S144 290 0 342V242C0 108.22 108.22 0 242 0z" fill="url(#il-shine)"/>
    <SojournIconMark color="#0E0E0E"/>
    <path d={SQUIRCLE_PATH} fill="none" stroke="rgba(0,0,0,0.16)" strokeWidth="2"/>
  </svg>
);

// ── ICON: DARK MODE ──────────────────────────────────────────
const IconDark = ({ size = 256 }) => (
  <svg width={size} height={size} viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="id-bg" x1="0" y1="0" x2="0" y2="1024" gradientUnits="userSpaceOnUse">
        <stop offset="0" stopColor="#2A2A2C"/>
        <stop offset="1" stopColor="#0E0E0E"/>
      </linearGradient>
      <linearGradient id="id-shine" x1="0" y1="0" x2="0" y2="380" gradientUnits="userSpaceOnUse">
        <stop offset="0" stopColor="#FFFFFF" stopOpacity="0.10"/>
        <stop offset="1" stopColor="#FFFFFF" stopOpacity="0"/>
      </linearGradient>
      <filter id="id-glow" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur stdDeviation="6"/>
      </filter>
    </defs>
    <path d={SQUIRCLE_PATH} fill="url(#id-bg)"/>
    <path d="M242 0h540c133.78 0 242 108.22 242 242v100C880 290 700 250 512 250S144 290 0 342V242C0 108.22 108.22 0 242 0z" fill="url(#id-shine)"/>
    {/* lime mark with subtle bloom */}
    <g filter="url(#id-glow)" opacity="0.5">
      <SojournIconMark color="#C6FF24"/>
    </g>
    <SojournIconMark color="#C6FF24"/>
    <path d={SQUIRCLE_PATH} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="2"/>
  </svg>
);

// ── ICON: TINTED (system palette) ────────────────────────────
// In Sonoma+, "tinted" icons render the user's chosen accent color. Apple
// asks for a single-tone monochrome glyph on a dark gradient. The system
// then maps the white parts to the chosen tint.
const IconTinted = ({ size = 256, tint = '#C6FF24' }) => (
  <svg width={size} height={size} viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="it-bg" x1="0" y1="0" x2="0" y2="1024" gradientUnits="userSpaceOnUse">
        <stop offset="0" stopColor="#1a1a1c"/>
        <stop offset="1" stopColor="#000000"/>
      </linearGradient>
    </defs>
    <path d={SQUIRCLE_PATH} fill="url(#it-bg)"/>
    <SojournIconMark color={tint}/>
    <path d={SQUIRCLE_PATH} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="2"/>
  </svg>
);

// ── ICON: LIQUID GLASS (macOS 26 / Tahoe) ────────────────────
// Layered glass icon. The system supplies real specular + parallax at
// runtime; this is a static visualization of the layer stack.
const IconLiquidGlass = ({ size = 256, wallpaper = 'light' }) => {
  const isDark = wallpaper === 'dark';
  return (
    <svg width={size} height={size} viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg">
      <defs>
        {/* refraction back — frosted lime/dark depending on wallpaper */}
        <linearGradient id={`lg-back-${wallpaper}`} x1="0" y1="0" x2="0" y2="1024" gradientUnits="userSpaceOnUse">
          {isDark ? (
            <>
              <stop offset="0" stopColor="rgba(255,255,255,0.12)"/>
              <stop offset="1" stopColor="rgba(255,255,255,0.04)"/>
            </>
          ) : (
            <>
              <stop offset="0" stopColor="rgba(255,255,255,0.65)"/>
              <stop offset="1" stopColor="rgba(255,255,255,0.30)"/>
            </>
          )}
        </linearGradient>
        {/* edge bevel */}
        <linearGradient id={`lg-bevel-${wallpaper}`} x1="0" y1="0" x2="0" y2="1024" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#FFFFFF" stopOpacity={isDark ? 0.25 : 0.85}/>
          <stop offset="0.04" stopColor="#FFFFFF" stopOpacity="0"/>
          <stop offset="0.96" stopColor="#FFFFFF" stopOpacity="0"/>
          <stop offset="1" stopColor="#000000" stopOpacity={isDark ? 0.45 : 0.15}/>
        </linearGradient>
        {/* specular highlight ellipse */}
        <radialGradient id={`lg-spec-${wallpaper}`} cx="320" cy="220" r="400" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#FFFFFF" stopOpacity="0.85"/>
          <stop offset="0.4" stopColor="#FFFFFF" stopOpacity="0.15"/>
          <stop offset="1" stopColor="#FFFFFF" stopOpacity="0"/>
        </radialGradient>
        {/* lime tint refraction — pulled through the glass */}
        <linearGradient id={`lg-tint-${wallpaper}`} x1="0" y1="200" x2="0" y2="824" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#C6FF24" stopOpacity="0.65"/>
          <stop offset="1" stopColor="#C6FF24" stopOpacity="0.35"/>
        </linearGradient>
        <clipPath id={`lg-clip-${wallpaper}`}>
          <path d={SQUIRCLE_PATH}/>
        </clipPath>
      </defs>

      {/* wallpaper hint behind glass — shown on the showcase only */}
      <rect width="1024" height="1024" fill={isDark ? '#0E0E0E' : '#F4F4F2'} opacity="0"/>

      {/* glass body */}
      <path d={SQUIRCLE_PATH} fill={`url(#lg-back-${wallpaper})`}/>

      {/* mark, refracted (slightly displaced shadow + lime fill) */}
      <g clipPath={`url(#lg-clip-${wallpaper})`}>
        <g transform="translate(8, 12)" opacity="0.35">
          <SojournIconMark color={isDark ? '#000000' : '#0E0E0E'}/>
        </g>
        <SojournIconMark color={`url(#lg-tint-${wallpaper})`}/>
      </g>

      {/* specular highlight */}
      <path d={SQUIRCLE_PATH} fill={`url(#lg-spec-${wallpaper})`} opacity="0.85"/>

      {/* edge bevel */}
      <path d={SQUIRCLE_PATH} fill={`url(#lg-bevel-${wallpaper})`}/>

      {/* outer hairline */}
      <path d={SQUIRCLE_PATH} fill="none" stroke={isDark ? "rgba(255,255,255,0.16)" : "rgba(0,0,0,0.18)"} strokeWidth="2"/>
    </svg>
  );
};

// ── ICON: CLEAR (glass-only, no tint) ────────────────────────
const IconClear = ({ size = 256, wallpaper = 'light' }) => {
  const isDark = wallpaper === 'dark';
  return (
    <svg width={size} height={size} viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id={`cl-back-${wallpaper}`} x1="0" y1="0" x2="0" y2="1024" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor={isDark ? "rgba(255,255,255,0.10)" : "rgba(255,255,255,0.55)"}/>
          <stop offset="1" stopColor={isDark ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.20)"}/>
        </linearGradient>
        <radialGradient id={`cl-spec-${wallpaper}`} cx="320" cy="220" r="400" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#FFFFFF" stopOpacity="0.7"/>
          <stop offset="1" stopColor="#FFFFFF" stopOpacity="0"/>
        </radialGradient>
      </defs>
      <path d={SQUIRCLE_PATH} fill={`url(#cl-back-${wallpaper})`}/>
      <SojournIconMark color={isDark ? "rgba(255,255,255,0.85)" : "rgba(0,0,0,0.55)"}/>
      <path d={SQUIRCLE_PATH} fill={`url(#cl-spec-${wallpaper})`} opacity="0.85"/>
      <path d={SQUIRCLE_PATH} fill="none" stroke={isDark ? "rgba(255,255,255,0.20)" : "rgba(0,0,0,0.20)"} strokeWidth="2"/>
    </svg>
  );
};

// ── MENU BAR TEMPLATE ICON ───────────────────────────────────
// Apple's Status Bar item is 22pt tall with a 1pt baseline padding.
// Template images use only black + alpha; system tints them.
// Drawn on a 22-grid, 18pt content area centered.
const SojournMenuBarIcon = ({ size = 22, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 22 22" xmlns="http://www.w3.org/2000/svg" fill="none">
    {/* outer frame — 1pt stroke at 22, mathematically aligned to pixel grid */}
    <rect x="2.5" y="3.5" width="17" height="15" rx="1.5" stroke={color} strokeWidth="1.4" fill="none"/>
    {/* stencil S — knocked-out solid fill */}
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      fill={color}
      d="
        M5.4 6.3 L5.4 10.2 L13.4 10.2 L13.4 11.6 L5.4 11.6 L5.4 15.7 L16.6 15.7 L16.6 11.6 L8.6 11.6 L8.6 10.2 L16.6 10.2 L16.6 6.3 Z
        M6.2 7.0 L15.8 7.0 L15.8 8.4 L6.2 8.4 Z
        M6.2 13.4 L15.8 13.4 L15.8 14.9 L6.2 14.9 Z
      "
    />
  </svg>
);

// Even smaller — 16pt hard-edged variant for high-density status bars
const SojournMenuBarIcon16 = ({ size = 16, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" fill="none">
    <rect x="2" y="2.5" width="12" height="11" rx="1" stroke={color} strokeWidth="1.2" fill="none"/>
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      fill={color}
      d="
        M4 5 L4 7.5 L10 7.5 L10 8.5 L4 8.5 L4 11 L12 11 L12 8.5 L6 8.5 L6 7.5 L12 7.5 L12 5 Z
      "
    />
  </svg>
);

window.IconLight = IconLight;
window.IconDark = IconDark;
window.IconTinted = IconTinted;
window.IconLiquidGlass = IconLiquidGlass;
window.IconClear = IconClear;
window.SojournMenuBarIcon = SojournMenuBarIcon;
window.SojournMenuBarIcon16 = SojournMenuBarIcon16;
window.SojournIconMark = SojournIconMark;
