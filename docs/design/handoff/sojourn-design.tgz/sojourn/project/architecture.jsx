// Architecture artboard — the "how Sojourn talks to your Mac" diagram.
// Renders inside an artboard at 1680×1050; matches the in-situ size.

const ArchitectureScreen = () => (
  <div style={{
    width:'100%', height:'100%', position:'relative',
    background:'var(--bzr-void)', color:'var(--txt-primary)',
    padding: '40px 56px', overflow:'hidden',
    fontFamily:'var(--f-grotesk)',
  }}>
    {/* big stencil heading */}
    <div style={{display:'flex', alignItems:'baseline', justifyContent:'space-between', marginBottom: 12}}>
      <div>
        <div className="bzr-eyebrow" style={{fontSize:11, color:'var(--bzr-lime)', letterSpacing:'0.18em', fontWeight:700}}>SOJOURN / ARCHITECTURE / A NATIVE MAC THAT WRAPS THE TOOLS YOU ALREADY TRUST</div>
        <h1 style={{fontFamily:'var(--f-stencil)', fontSize:60, fontWeight:900, letterSpacing:'-0.01em', margin:'8px 0 0', lineHeight:0.95}}>
          THE BENCH IS HONEST. <span style={{color:'var(--bzr-lime)'}}>NO LINKING.</span>
        </h1>
        <div style={{maxWidth:980, marginTop:14, fontSize:14, color:'var(--txt-secondary)', lineHeight:1.5}}>
          Sojourn is a SwiftUI app over <span className="mono lime">swift-subprocess</span>. Every backend (mpm, chezmoi, git, gitleaks, age, defaults) runs as a separate process with structured I/O. <b style={{color:'var(--bzr-lime)'}}>This is the licensing firewall</b> — GPL-3-or-later code lives at arm's length from GPL-2 mpm. JSON in, TOML out, exit codes everywhere.
        </div>
      </div>
      <div style={{textAlign:'right'}}>
        <div className="mono" style={{fontSize:10, color:'var(--txt-tertiary)', letterSpacing:'0.16em'}}>SWIFT 6.1+ · macOS 14+ · @Observable</div>
        <div className="mono lime" style={{fontSize:11, marginTop:4}}>app.bizarre.sojourn · v0.1</div>
      </div>
    </div>

    {/* the four layers */}
    <div style={{display:'grid', gridTemplateColumns:'1.1fr 1fr 1fr 1fr', gap:14, marginTop:28}}>
      {/* UI */}
      <Layer label="UI" sub="SwiftUI · NavigationSplitView · MenuBarExtra" tone="lime">
        <Block title="MainWindow" lines={['Sidebar (Carry / Sync / Hygiene)', 'Mid list', 'Detail + log pane']}/>
        <Block title="MenuBarExtra" lines={['LSUIElement', 'MenuBarExtraAccess', 'Quick upgrade']}/>
        <Block title="Sheets" lines={['Push', 'Pull', 'SecretFindings · 5s lock', 'BootstrapView']}/>
        <div className="mono" style={{fontSize:9, color:'var(--bzr-lime)', marginTop:8, letterSpacing:'0.14em'}}>READS APPSTORE · DISPATCHES INTENTS</div>
      </Layer>

      {/* STORE + JOBS */}
      <Layer label="STATE" sub="Observation framework · no TCA" tone="white">
        <Block title="AppStore" lines={['@Observable', 'managers, history, jobs', 'bootstrapState, settings']}/>
        <Block title="JobRunner" lines={['Task per Job', 'cancellable', 'pipes → LogBuffer']}/>
        <Block title="LogBuffer" lines={['ring buffer', 'AttributedString rows', 'ANSI SGR parser']}/>
        <div className="mono" style={{fontSize:9, color:'var(--txt-tertiary)', marginTop:8, letterSpacing:'0.14em'}}>SINGLE ROOT STORE · @MainActor</div>
      </Layer>

      {/* SERVICES */}
      <Layer label="SERVICES" sub="actor per CLI · structured I/O" tone="white">
        <Svc name="MPMService" cli="mpm" out="--table-format json" />
        <Svc name="ChezmoiService" cli="chezmoi" out="--format=json · status · diff" />
        <Svc name="GitService" cli="/usr/bin/git" out="--porcelain=v2 -z" />
        <Svc name="PrefService" cli="defaults" out="export/import + plutil xml1" />
        <Svc name="SecretScan" cli="gitleaks" out="dir --report-format json" warn />
        <Svc name="BrewService" cli="brew" out=".pkg installer · Authorization" />
        <div className="mono" style={{fontSize:9, color:'var(--txt-tertiary)', marginTop:6, letterSpacing:'0.14em'}}>ALL VIA swift-subprocess</div>
      </Layer>

      {/* CLI */}
      <Layer label="BACKENDS" sub="user's binaries · arm's length" tone="amber">
        <Backend bin="mpm" path="/opt/homebrew/bin/mpm" lic="GPL-2.0" pinned="6.3.0+"/>
        <Backend bin="chezmoi" path="/opt/homebrew/bin/chezmoi" lic="MIT" pinned="2.70.2+"/>
        <Backend bin="brew" path="/opt/homebrew/bin/brew" lic="BSD-2" pinned="4.4.7+"/>
        <Backend bin="git" path="/usr/bin/git" lic="GPL-2" pinned="system"/>
        <Backend bin="gitleaks" path="…/Resources/bin/" lic="MIT" pinned="bundled · re-signed"/>
        <Backend bin="age" path="…/Resources/bin/" lic="MIT" pinned="bundled · re-signed"/>
        <div className="mono" style={{fontSize:9, color:'var(--bzr-warn)', marginTop:6, letterSpacing:'0.14em'}}>LICENSING FIREWALL · NO LINKING</div>
      </Layer>
    </div>

    {/* arrows + flow lane */}
    <div style={{
      marginTop: 18, padding:'14px 18px',
      background:'rgba(198,255,36,0.04)',
      border:'0.5px solid rgba(198,255,36,0.20)',
      borderLeft:'3px solid var(--bzr-lime)',
      borderRadius:6,
      display:'flex', alignItems:'center', gap:18, flexWrap:'wrap'
    }}>
      <div className="mono lime" style={{fontSize:10, letterSpacing:'0.18em', fontWeight:700}}>EVERY SUBPROCESS IS A JOB</div>
      <span style={{color:'var(--txt-tertiary)'}}>·</span>
      <span className="mono" style={{fontSize:10, color:'var(--txt-secondary)'}}>id · start · status · line-buffered log · cancellable · 64KB pipe backpressure handled</span>
      <span style={{color:'var(--txt-tertiary)'}}>·</span>
      <span className="mono" style={{fontSize:10, color:'var(--txt-secondary)'}}>PTY-wrap for block-buffered tools (<span className="lime">script -q /dev/null</span>)</span>
      <span style={{color:'var(--txt-tertiary)'}}>·</span>
      <span className="mono lime" style={{fontSize:10}}>FAULT → user-visible alert</span>
    </div>

    {/* bottom row: persistence + scheduling + sync */}
    <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:14, marginTop:18}}>
      <BottomCard title="PERSISTENCE" sub="~/Library/Application Support/Sojourn" rows={[
        ['settings.toml',       'tool paths · cooldown overrides · machine_id'],
        ['backups/<ts>-<op>/',  'tarball before push/pull/apply · 30d GC'],
        ['deletions.db',        'SQLite · path · sha256 · reason · undo log'],
        ['logs/',               'OSLog export bundle · gitleaks-redacted'],
      ]}/>
      <BottomCard title="SCHEDULING" sub="NSBackgroundActivityScheduler" rows={[
        ['activity-id',         'app.bizarre.sojourn.refresh-outdated'],
        ['interval / tolerance','1h · 15m · QoS .utility'],
        ['App Nap',             'respected · battery-aware'],
        ['v2 opt-in',           'SMAppService.agent · LaunchAgent'],
      ]}/>
      <BottomCard title="USER REPO · YOUR REMOTE" sub="git@github.com:you/my-mac.git" rows={[
        ['packages.toml',       'mpm backup · root · TOML'],
        ['dotfiles/',           'chezmoi source dir · age-encrypted secrets'],
        ['preferences/*.plist', 'XML · per-domain · git-diffable'],
        ['.sojourn/',           'machines/ · active.toml · backups/ · version.toml'],
      ]}/>
    </div>

    {/* signature block */}
    <div style={{position:'absolute', bottom: 24, left: 56, right: 56, display:'flex', justifyContent:'space-between', alignItems:'flex-end'}}>
      <div className="mono" style={{fontSize:10, color:'var(--txt-tertiary)', letterSpacing:'0.16em'}}>
        UI NEVER CALLS Process — SERVICES NEVER LINK BACKENDS — BACKENDS NEVER SEE OUR PROCESS SPACE
      </div>
      <div style={{fontFamily:'var(--f-stencil)', fontSize:18, fontWeight:800, letterSpacing:'0.06em', color:'var(--bzr-lime)'}}>
        SOJOURN <span style={{color:'var(--txt-tertiary)'}}>×</span> BIZARRE
      </div>
    </div>
  </div>
);

const Layer = ({ label, sub, tone, children }) => (
  <div style={{
    background: tone==='lime' ? 'rgba(198,255,36,0.06)' : tone==='amber' ? 'rgba(232,163,61,0.05)' : 'rgba(255,255,255,0.02)',
    border: '0.5px solid ' + (tone==='lime' ? 'rgba(198,255,36,0.30)' : tone==='amber' ? 'rgba(232,163,61,0.25)' : 'var(--hairline)'),
    borderRadius: 8,
    padding: 14,
    display:'flex', flexDirection:'column', gap:10,
  }}>
    <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline'}}>
      <div style={{fontFamily:'var(--f-stencil)', fontSize:22, fontWeight:900, letterSpacing:'0.06em', color: tone==='lime'?'var(--bzr-lime)':tone==='amber'?'var(--bzr-warn)':'var(--txt-primary)'}}>
        {label}
      </div>
    </div>
    <div className="mono" style={{fontSize:10, color:'var(--txt-tertiary)', letterSpacing:'0.10em', marginTop:-6}}>{sub}</div>
    {children}
  </div>
);

const Block = ({ title, lines }) => (
  <div style={{
    background:'rgba(0,0,0,0.30)',
    border:'0.5px solid var(--hairline-inner)',
    borderRadius: 5,
    padding: '8px 10px',
  }}>
    <div style={{fontFamily:'var(--f-stencil)', fontSize:12, fontWeight:800, letterSpacing:'0.04em'}}>{title}</div>
    <div style={{marginTop:4, display:'flex', flexDirection:'column', gap:2}}>
      {lines.map((l,i)=>(
        <div key={i} className="mono" style={{fontSize:10, color:'var(--txt-secondary)'}}>{l}</div>
      ))}
    </div>
  </div>
);

const Svc = ({ name, cli, out, warn }) => (
  <div style={{
    background:'rgba(0,0,0,0.30)',
    border:'0.5px solid ' + (warn ? 'rgba(232,163,61,0.30)' : 'var(--hairline-inner)'),
    borderRadius: 5,
    padding: '7px 10px',
  }}>
    <div style={{display:'flex', alignItems:'center'}}>
      <span style={{fontFamily:'var(--f-stencil)', fontSize:12, fontWeight:800, letterSpacing:'0.04em', flex:1}}>{name}</span>
      <span className="mono lime" style={{fontSize:9}}>actor</span>
    </div>
    <div className="mono" style={{fontSize:10, color:'var(--txt-secondary)', marginTop:2}}>$ {cli}</div>
    <div className="mono" style={{fontSize:9, color: warn ? 'var(--bzr-warn)' : 'var(--txt-tertiary)', marginTop:1}}>{out}</div>
  </div>
);

const Backend = ({ bin, path, lic, pinned }) => (
  <div style={{
    background:'rgba(0,0,0,0.30)',
    border:'0.5px solid var(--hairline-inner)',
    borderRadius: 5,
    padding: '7px 10px',
  }}>
    <div style={{display:'flex', alignItems:'center'}}>
      <span style={{fontFamily:'var(--f-stencil)', fontSize:12, fontWeight:800, letterSpacing:'0.04em', flex:1}}>{bin}</span>
      <span className="mono" style={{fontSize:9, padding:'1px 5px', borderRadius:3, background: lic.startsWith('GPL-2')?'rgba(232,163,61,0.20)':'rgba(198,255,36,0.15)', color: lic.startsWith('GPL-2')?'var(--bzr-warn)':'var(--bzr-lime)'}}>{lic}</span>
    </div>
    <div className="mono" style={{fontSize:9, color:'var(--txt-secondary)', marginTop:2}}>{path}</div>
    <div className="mono" style={{fontSize:9, color:'var(--txt-tertiary)', marginTop:1}}>{pinned}</div>
  </div>
);

const BottomCard = ({ title, sub, rows }) => (
  <div style={{
    background:'rgba(255,255,255,0.02)',
    border:'0.5px solid var(--hairline)',
    borderRadius:6,
    padding:14,
  }}>
    <div className="mono" style={{fontSize:10, color:'var(--bzr-lime)', letterSpacing:'0.16em', fontWeight:700}}>{title}</div>
    <div className="mono" style={{fontSize:10, color:'var(--txt-tertiary)', marginTop:2}}>{sub}</div>
    <div style={{height:0.5, background:'var(--hairline-inner)', margin:'8px 0'}}></div>
    <div style={{display:'flex', flexDirection:'column', gap:5}}>
      {rows.map((r,i)=>(
        <div key={i} style={{display:'flex', fontSize:11}}>
          <span className="mono lime" style={{minWidth:140, fontSize:10}}>{r[0]}</span>
          <span style={{color:'var(--txt-secondary)', flex:1}}>{r[1]}</span>
        </div>
      ))}
    </div>
  </div>
);

window.ArchitectureScreen = ArchitectureScreen;
