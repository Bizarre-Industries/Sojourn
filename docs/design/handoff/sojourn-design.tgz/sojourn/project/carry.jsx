// Carry-first screens — these are the dominant story.
// Overview is the landing; Packages, Dotfiles, Preferences are the carry surfaces.

// === CARRY OVERVIEW (replaces generic overview as landing) ===
const CarryOverviewScreen = ({ openSheet }) => (
  <>
    <Toolbar eyebrow="CARRY / OVERVIEW / WORK-MBP · 184 PKGS · 32 DOTFILES · 18 DOMAINS" title="Carry your Mac.">
      <button className="btn btn-glass" onClick={()=>openSheet('pull')}><Icon name="pull" size={11}/> Pull</button>
      <button className="btn btn-primary" onClick={()=>openSheet('push')}><Icon name="push" size={11}/> Push 3</button>
    </Toolbar>
    <div className="detail">
      <div className="detail-inner">
        <Eyebrow>BIZARRE / SOJOURN / V0.1 / GPL-3.0-OR-LATER · GUI OVER mpm × chezmoi × defaults</Eyebrow>
        <h1 className="detail-h1">PACKAGES.<br/>DOTFILES. <span className="lime">PREFS.</span></h1>
        <div className="detail-sub">
          A native macOS app that carries your setup across machines. mpm fans out to 12 managers in parallel. chezmoi handles dotfile templating + age. defaults round-trips plists through cfprefsd. We never link GPL-2 backends — only invoke them as subprocesses with JSON/TOML output.
        </div>

        <div className="row mt-6 gap-3" style={{alignItems:'stretch', flexWrap:'wrap'}}>
          {/* PACKAGES big card */}
          <div className="card" style={{flex:'2 1 460px', padding:0, overflow:'hidden'}}>
            <div style={{padding:'14px 16px', borderBottom:'0.5px solid var(--hairline)', background:'rgba(198,255,36,0.06)'}}>
              <div className="row">
                <Icon name="package" size={14} style={{color:'var(--bzr-lime)'}}/>
                <span style={{fontFamily:'var(--f-stencil)', fontSize:18, fontWeight:800, letterSpacing:'0.04em', marginLeft:8}}>PACKAGES</span>
                <span className="right mono lime" style={{fontSize:11}}>184 · 17 OUTDATED</span>
              </div>
              <div className="mono subtle mt-2" style={{fontSize:10}}>mpm 6.3.0 · 12 MANAGERS · `--table-format json` · 90s/call · parallel fanout</div>
            </div>
            <div style={{padding:'12px 16px'}}>
              <div className="col gap-2">
                {[
                  ['A','mas',         '14',  'auto · 0d · Apple reviews'],
                  ['B','brew',        '87',  '7d · curated formulae'],
                  ['B','cargo',       '22',  '7d · crates.io'],
                  ['C','cask',        '31',  '7d · prompt · install scripts'],
                  ['D','pipx · pip',  '11',  '7d · prompt · global interpreter'],
                  ['E','npm global',  '9',   '14d · never silent · pre/postinstall'],
                ].map(r=>(
                  <div key={r[1]} className="tier-row">
                    <span className={`badge badge-tier-${r[0].toLowerCase()}`}>{r[0]}</span>
                    <span style={{fontSize:12, fontWeight:600, minWidth:90}}>{r[1]}</span>
                    <span className="mono lime" style={{fontSize:11, width:30}}>{r[2]}</span>
                    <span className="subtle" style={{fontSize:11, flex:1}}>{r[3]}</span>
                  </div>
                ))}
              </div>
              <div className="mono subtle mt-3" style={{fontSize:10}}>↻ ADVISORY-AWARE BYPASS · OSV/GHSA HIT → SKIP COOLDOWN · DAILY REFRESH</div>
            </div>
          </div>

          {/* DOTFILES */}
          <div className="card" style={{flex:'1 1 280px', padding:0, overflow:'hidden'}}>
            <div style={{padding:'14px 16px', borderBottom:'0.5px solid var(--hairline)'}}>
              <div className="row">
                <Icon name="file" size={14}/>
                <span style={{fontFamily:'var(--f-stencil)', fontSize:18, fontWeight:800, letterSpacing:'0.04em', marginLeft:8}}>DOTFILES</span>
                <span className="right mono lime" style={{fontSize:11}}>32 · 4 DRIFT</span>
              </div>
              <div className="mono subtle mt-2" style={{fontSize:10}}>chezmoi 2.70.2 · age · per-host templates</div>
            </div>
            <div style={{padding:'12px 16px'}}>
              <div className="col gap-2" style={{fontSize:11}}>
                <div className="row"><span className="dot warn"></span><span>.zshrc</span><span className="right mono subtle">+4 −1</span></div>
                <div className="row"><span className="dot warn"></span><span>.gitconfig</span><span className="right mono subtle">+1 −0</span></div>
                <div className="row"><span className="dot ok"></span><span>.config/nvim/init.lua</span><span className="right mono subtle">+47 new</span></div>
                <div className="row"><span className="dot ok"></span><span>.tmux.conf</span><span className="right mono subtle">+2 −0</span></div>
                <div className="row" style={{marginTop:6}}><span className="badge badge-mute">AGE</span><span className="mono" style={{fontSize:10}}>private_dot_ssh/encrypted_id_ed25519.age</span></div>
              </div>
            </div>
          </div>

          {/* PREFERENCES */}
          <div className="card" style={{flex:'1 1 280px', padding:0, overflow:'hidden'}}>
            <div style={{padding:'14px 16px', borderBottom:'0.5px solid var(--hairline)'}}>
              <div className="row">
                <Icon name="sliders" size={14}/>
                <span style={{fontFamily:'var(--f-stencil)', fontSize:18, fontWeight:800, letterSpacing:'0.04em', marginLeft:8}}>PREFS</span>
                <span className="right mono lime" style={{fontSize:11}}>18 · 2 DRIFT</span>
              </div>
              <div className="mono subtle mt-2" style={{fontSize:10}}>defaults export/import · plutil xml1 · cfprefsd</div>
            </div>
            <div style={{padding:'12px 16px'}}>
              <div className="col gap-2" style={{fontSize:11}}>
                <div className="row"><span className="badge badge-success" style={{fontSize:9}}>USER</span><span style={{flex:1, marginLeft:6}}>iTerm2, Dock, Finder, Raycast</span><span className="mono lime">14</span></div>
                <div className="row"><span className="badge badge-mute" style={{fontSize:9}}>APP-SUPP</span><span style={{flex:1, marginLeft:6}}>Karabiner keymaps</span><span className="mono lime">3</span></div>
                <div className="row"><span className="badge badge-tier-c" style={{fontSize:9}}>FDA</span><span style={{flex:1, marginLeft:6}}>Safari, 1Password</span><span className="mono subtle">v2</span></div>
                <div className="row"><span className="badge badge-tier-e" style={{fontSize:9}}>SYS</span><span style={{flex:1, marginLeft:6}}>loginwindow · refused</span><span className="mono subtle">—</span></div>
              </div>
              <div className="mono subtle mt-3" style={{fontSize:10}}>QUIT-AND-RELAUNCH ON IMPORT</div>
            </div>
          </div>
        </div>

        {/* THE CARRY MOTION — push/pull moment, secondary */}
        <div className="row mt-6 gap-3" style={{alignItems:'stretch'}}>
          <div className="card flex-1">
            <div className="card-eyebrow">THE CARRY MOTION</div>
            <div className="row mt-2 gap-2" style={{alignItems:'center'}}>
              <span className="badge badge-lime"><Icon name="laptop" size={10}/> work-mbp</span>
              <span className="mono lime" style={{fontSize:14}}>━━━ ↑ ━━━</span>
              <span className="badge badge-mute">origin/main</span>
              <span className="mono lime" style={{fontSize:14}}>━━━ ↓ ━━━</span>
              <span className="badge badge-mute"><Icon name="laptop" size={10}/> personal-mini</span>
            </div>
            <div className="mono subtle mt-3" style={{fontSize:10}}>
              EXPLICIT PUSH/PULL · ONE WRITER · gitleaks BEFORE COMMIT · TARBALL SNAPSHOT BEFORE PULL · 30D RETENTION
            </div>
            <div className="row mt-3 gap-2">
              <button className="btn btn-glass" onClick={()=>openSheet('pull')}><Icon name="pull" size={11}/> Pull</button>
              <button className="btn btn-primary" onClick={()=>openSheet('push')}><Icon name="push" size={11}/> Push 3 changes</button>
              <span className="right mono subtle" style={{fontSize:10}}>LAST PUSH 2H · a3f9c2e · clean</span>
            </div>
          </div>
          <div className="card" style={{width:300}}>
            <div className="card-eyebrow">SCHEDULER · NSBackgroundActivityScheduler</div>
            <div className="row mt-2"><span className="dot lime"></span><span style={{fontSize:12, fontWeight:600}}>app.bizarre.sojourn.refresh-outdated</span></div>
            <div className="mono subtle mt-2" style={{fontSize:10}}>1H INTERVAL · 15M TOLERANCE · QoS .utility · APP NAP-AWARE · AC-ONLY OPT</div>
            <div className="progress-track mt-3"><div className="progress-fill" style={{width:'74%'}}></div></div>
            <div className="row mt-2"><span className="mono subtle" style={{fontSize:10}}>NEXT</span><span className="right mono lime" style={{fontSize:11}}>14m</span></div>
          </div>
        </div>

        <div className="callout mt-6">
          <div className="callout-mark">★</div>
          <div className="callout-body">
            <div className="callout-title">YOU ALREADY KNOW. CATCH THE STARS.</div>
            <div className="callout-text">Three commands separate "fresh Mac" from "your Mac." Sojourn handles two automatically and prompts for the third. The bench is honest — every push gitleaks-scans, every pull snapshots, every destructive op writes a tarball before touching the working tree.</div>
          </div>
        </div>
      </div>
    </div>
  </>
);

window.CarryOverviewScreen = CarryOverviewScreen;
