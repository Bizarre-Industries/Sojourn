// Chrome — macOS Window, Sidebar, Toolbar, MenuBar
const { useState, useEffect, useRef } = React;

// === Window ===
const MacWindow = ({ title, children, sheet }) => (
  <div className="mac-window lg-window">
    <div className="titlebar">
      <div className="traffic">
        <span className="red"></span><span className="yellow"></span><span className="green"></span>
      </div>
      <div className="titlebar-title">
        <SojournMark size={13} color="var(--bzr-lime)"/>
        {title || "Sojourn"}
      </div>
      <div className="titlebar-trailing">
        <div className="tb-btn"><Icon name="search" size={13}/></div>
        <div className="tb-btn"><Icon name="sliders" size={13}/></div>
      </div>
    </div>
    <div className="window-body">{children}</div>
    {sheet && <div className="sheet-host">{sheet}</div>}
  </div>
);

// === Sidebar ===
const SidebarRow = ({ icon, label, count, dot, selected, onClick }) => (
  <div className={`sb-row ${selected ? 'selected' : ''}`} onClick={onClick}>
    <span className="sb-icon"><Icon name={icon} size={15}/></span>
    <span>{label}</span>
    {dot ? <span className={`sb-dot ${dot}`}></span> :
     count != null ? <span className="sb-count">{count}</span> : null}
  </div>
);

const Sidebar = ({ active, onSelect }) => (
  <div className="sidebar">
    <div className="sb-section">Carry</div>
    <SidebarRow icon="rocket" label="Overview" selected={active==='overview'} onClick={()=>onSelect('overview')} />
    <SidebarRow icon="package" label="Packages" count={184} dot="warn" selected={active==='packages'} onClick={()=>onSelect('packages')} />
    <SidebarRow icon="file" label="Dotfiles" count={32} selected={active==='dotfiles'} onClick={()=>onSelect('dotfiles')} />
    <SidebarRow icon="sliders" label="Preferences" count={18} selected={active==='preferences'} onClick={()=>onSelect('preferences')} />

    <div className="sb-section">Sync</div>
    <SidebarRow icon="laptop" label="Machines" count={3} selected={active==='machines'} onClick={()=>onSelect('machines')} />
    <SidebarRow icon="history" label="History" count={47} selected={active==='history'} onClick={()=>onSelect('history')} />
    <SidebarRow icon="git" label="Conflicts" selected={active==='conflicts'} onClick={()=>onSelect('conflicts')} />
    <SidebarRow icon="branch" label="Onboard Mac" selected={active==='onboard'} onClick={()=>onSelect('onboard')} />

    <div className="sb-section">Hygiene</div>
    <SidebarRow icon="shield" label="Secrets" selected={active==='secrets'} onClick={()=>onSelect('secrets')} />
    <SidebarRow icon="trash" label="Cleanup" count={12} dot="warn" selected={active==='cleanup'} onClick={()=>onSelect('cleanup')} />

    <div className="sb-section">App</div>
    <SidebarRow icon="activity" label="Diagnostics" selected={active==='diagnostics'} onClick={()=>onSelect('diagnostics')} />
    <SidebarRow icon="settings" label="Settings" selected={active==='settings'} onClick={()=>onSelect('settings')} />

    <div className="sb-machine">
      <div className="sb-machine-name">
        <span className="dot lime"></span>
        work-mbp
      </div>
      <div className="sb-machine-meta">ACTIVE WRITER · 2h AGO</div>
      <div className="sb-machine-meta" style={{color: 'rgba(198,255,36,0.65)'}}>↑ a3f9c2e</div>
    </div>
  </div>
);

// === Toolbar ===
const Toolbar = ({ eyebrow, title, search, children }) => (
  <div className="toolbar">
    <div style={{display:'flex', flexDirection:'column', gap:2}}>
      {eyebrow && <div className="toolbar-eyebrow">{eyebrow}</div>}
      <div className="toolbar-title">{title}</div>
    </div>
    {search !== false && (
      <div className="toolbar-search" style={{marginLeft: 20}}>
        <Icon name="search" size={11}/>
        <input placeholder="Search..." defaultValue=""/>
        <span className="mono" style={{fontSize: 10, color: 'var(--txt-tertiary)'}}>⌘F</span>
      </div>
    )}
    <div className="toolbar-right">{children}</div>
  </div>
);

// === Eyebrow ===
const Eyebrow = ({ children }) => (
  <div className="eyebrow">
    <span className="star">✦</span>
    {children}
  </div>
);

window.MacWindow = MacWindow;
window.Sidebar = Sidebar;
window.SidebarRow = SidebarRow;
window.Toolbar = Toolbar;
window.Eyebrow = Eyebrow;
