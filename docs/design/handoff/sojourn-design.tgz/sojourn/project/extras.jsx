// Extra screens — features pulled from docs we hadn't surfaced yet
// Onboard new machine (age recipient + Device Flow), Conflicts gallery (6 shapes),
// Bootstrap probe matrix, Diagnostics, Tool paths probe, Job runner detail.

// === ONBOARDING NEW MACHINE — age recipient + remote setup ===
const OnboardScreen = () => (
  <>
    <Toolbar eyebrow="SYNC / ONBOARD / .sojourn/machines/&lt;id&gt;.toml" title="Onboard new machine">
      <button className="btn btn-glass"><Icon name="laptop" size={11}/> 4 / 7</button>
      <button className="btn btn-primary"><Icon name="check" size={11}/> Continue</button>
    </Toolbar>
    <div className="detail">
      <div className="detail-inner">
        <Eyebrow>WORK-MBP IS WRITER · NEW MACHINE WILL JOIN AS READER</Eyebrow>
        <h1 className="detail-h1" style={{fontSize:30}}>NEW MAC, OLD CONFIG.</h1>
        <div className="detail-sub">Sojourn generates the local age identity, prints its public recipient, and walks you through adding it to the repo so the previous Mac re-encrypts on next push. v1 keeps one writer at a time — multi-recipient is a v2 feature, but adding readers works today.</div>

        <div className="row mt-6 gap-3" style={{alignItems:'stretch'}}>
          <div className="card flex-1">
            <div className="card-eyebrow">REMOTE · BYO IS DEFAULT</div>
            <div className="col gap-3" style={{fontSize:12}}>
              <input className="input mono" defaultValue="git@github.com:you/my-mac.git"/>
              <div className="row gap-2">
                <span className="badge badge-success">REACHABLE</span>
                <span className="badge badge-mute">SSH · git-credential-osxkeychain</span>
                <span className="right subtle mono" style={{fontSize:10}}>FETCH 142ms</span>
              </div>
              <div style={{height:0.5, background:'var(--hairline)', margin:'4px 0'}}></div>
              <div className="row gap-2">
                <span className="badge badge-mute">OR</span>
                <span style={{fontSize:11}}>Sign in with GitHub</span>
                <span className="right">
                  <button className="btn btn-glass"><Icon name="branch" size={11}/> Device flow</button>
                </span>
              </div>
              <div className="mono subtle" style={{fontSize:10}}>CLIENT_ID ONLY · NO SECRETS EMBEDDED · KEYCHAIN-STORED TOKEN</div>
            </div>
          </div>
          <div className="card" style={{width:340}}>
            <div className="card-eyebrow">AGE · SECRETS ENCRYPTION</div>
            <div className="col gap-3" style={{fontSize:12}}>
              <div className="mono subtle" style={{fontSize:10}}>CHEZMOI AGE-KEYGEN · MIT · BUNDLED</div>
              <div className="code" style={{fontSize:10}}>
<span className="c">// generated locally · never committed</span>{'\n'}
<span className="lime">~/.config/chezmoi/key.txt</span>{'\n\n'}
<span className="c">// share this public key with the writer</span>{'\n'}
<span className="warn">age1qzr...l7kq</span>
              </div>
              <button className="btn btn-glass"><Icon name="copy" size={11}/> Copy recipient</button>
              <div className="mono subtle" style={{fontSize:9}}>WRITER WILL RE-ENCRYPT TO BOTH ON NEXT PUSH</div>
            </div>
          </div>
        </div>

        <h2 className="detail-h2 mt-6">Steps</h2>
        <div className="card" style={{padding:0}}>
          {[
            ['1','PROBE',          'Found brew, mpm, chezmoi, git, age',         'done'],
            ['2','REMOTE',         'git@github.com:you/my-mac.git · clone ok',  'done'],
            ['3','MACHINE ID',     'mini-home.local · 8d2a-... · stored',        'done'],
            ['4','AGE IDENTITY',   'Generated · public recipient ready to share','active'],
            ['5','WRITER ADDS',    'Old Mac re-encrypts on next push',           'pending'],
            ['6','PULL',           'mpm restore + chezmoi apply + defaults import','pending'],
            ['7','READY',          'Reader joined fleet',                         'pending'],
          ].map(s=>(
            <div key={s[0]} className="row" style={{padding:'10px 14px', borderBottom: s[0]!=='7' ? '0.5px solid var(--hairline-inner)':'none'}}>
              <span className="mono" style={{
                width:22, height:22, borderRadius:4,
                background: s[3]==='done'?'var(--bzr-lime)':s[3]==='active'?'rgba(198,255,36,0.20)':'rgba(255,255,255,0.04)',
                color: s[3]==='done'?'var(--bzr-void)':s[3]==='active'?'var(--bzr-lime)':'var(--txt-tertiary)',
                display:'inline-flex',alignItems:'center',justifyContent:'center',fontWeight:700,fontSize:11
              }}>{s[3]==='done'?'✓':s[0]}</span>
              <span style={{fontFamily:'var(--f-stencil)', fontSize:13, fontWeight:700, letterSpacing:'0.05em', minWidth:130, marginLeft:8}}>{s[1]}</span>
              <span style={{fontSize:12, flex:1, color: s[3]==='pending'?'var(--txt-tertiary)':'var(--txt-primary)'}}>{s[2]}</span>
              {s[3]==='active' && <span className="dot lime"></span>}
            </div>
          ))}
        </div>

        <div className="callout callout-warn mt-6">
          <div className="callout-mark">!</div>
          <div className="callout-body">
            <div className="callout-title">COOPERATIVE WRITER LOCK · NOT ENFORCED</div>
            <div className="callout-text">.sojourn/active.toml is a hint, not a fence. Git has no locking. We catch the 95% case of a forgotten pull. v2 adds three-way merge for text and per-file timestamps for last-writer-wins.</div>
          </div>
        </div>
      </div>
    </div>
  </>
);

// === CONFLICTS — 6 shapes per docs/CONFLICTS.md ===
const ConflictsScreen = () => (
  <>
    <Toolbar eyebrow="SYNC / CONFLICTS / 6 shapes · pull resolves before push" title="Conflict resolution">
      <button className="btn btn-glass"><Icon name="snapshot" size={11}/> Restore snapshot</button>
    </Toolbar>
    <div className="detail">
      <div className="detail-inner">
        <Eyebrow>CONFLICTS / SHAPES 1–6 / kind == .textEdit | .packagesToml | .chezmoiTemplate | .plist | .rename | .delete</Eyebrow>
        <h1 className="detail-h1" style={{fontSize:30}}>SIX SHAPES, ONE BENCH.</h1>
        <div className="detail-sub">Pull surfaces every conflict shape with kept ancestor + local + remote in memory. Snapshot is written before any working-tree mutation. We never auto-merge text dotfiles or Go templates.</div>

        <div className="row mt-6 gap-3" style={{flexWrap:'wrap'}}>
          {[
            { k:'1', t:'TEXT EDIT',          c:'.zshrc edited on both Macs',            r:'Keep local · Keep remote · Manual merge' },
            { k:'2', t:'PACKAGES.TOML',       c:'mpm install/remove diverged',           r:'Merge per-manager (grouped UI)' },
            { k:'3', t:'CHEZMOI TEMPLATE',    c:'dot_gitconfig.tmpl conditional clash',  r:'Always surfaces · cannot auto-merge Go templates' },
            { k:'4', t:'PLIST',               c:'iterm2 same key, different values',     r:'Keyed diff · per-key pick' },
            { k:'5', t:'RENAME × EDIT',       c:'.tmux.conf renamed + edited',           r:'User picks final path · git rename hint' },
            { k:'6', t:'DELETE × EDIT',       c:'chezmoi forget vs continued edit',      r:'Default: keep edit · explicit override' },
          ].map(s=>(
            <div key={s.k} className="card" style={{flex:'1 1 320px', minWidth:300, padding:'14px 16px'}}>
              <div className="row">
                <span className="badge badge-tier-c">SHAPE {s.k}</span>
                <span style={{fontFamily:'var(--f-stencil)', fontSize:14, fontWeight:800, letterSpacing:'0.04em', marginLeft:8}}>{s.t}</span>
              </div>
              <div className="subtle mt-2" style={{fontSize:11}}>{s.c}</div>
              <div className="mono lime mt-2" style={{fontSize:10}}>{s.r}</div>
            </div>
          ))}
        </div>

        <h2 className="detail-h2 mt-6">Snapshot guarantee</h2>
        <div className="card mono" style={{fontSize:11}}>
~/Library/Application Support/Sojourn/backups/<span className="lime">2026-04-28T14-30-sync.pull/</span>{'\n'}
{'  '}├── packages.toml.before{'\n'}
{'  '}├── dotfiles.tar{'\n'}
{'  '}├── preferences/com.googlecode.iterm2.plist.before{'\n'}
{'  '}└── meta.json    <span className="c">// machine, op, git_head, ts</span>{'\n\n'}
<span className="subtle">RETENTION 30D · BackupsDirectory.gc() runs on app launch</span>
        </div>
      </div>
    </div>
  </>
);

// === DIAGNOSTICS ===
const DiagnosticsScreen = () => (
  <>
    <Toolbar eyebrow="APP / DIAGNOSTICS / OSLog · subsystem app.bizarre.sojourn" title="Diagnostics">
      <button className="btn btn-primary"><Icon name="download" size={11}/> Export bundle</button>
    </Toolbar>
    <div className="detail">
      <div className="detail-inner">
        <Eyebrow>OSLOG-FIRST · CRASH REPORTS STAY LOCAL · NO TELEMETRY</Eyebrow>
        <h1 className="detail-h1" style={{fontSize:30}}>OBSERVABILITY.</h1>
        <div className="detail-sub">Six categories. <span className="mono lime">.fault</span> triggers a user-visible alert. Diagnostics bundle is the last 24h of OSLog plus AppStore.history, redacted via gitleaks-like patterns before write.</div>

        <h2 className="detail-h2 mt-6">Categories</h2>
        <div className="row mt-2 gap-2" style={{flexWrap:'wrap'}}>
          {[
            ['sync','142','last 24h'],
            ['subprocess','3,481','line-buffered'],
            ['bootstrap','12','probe + install'],
            ['secrets','7','gitleaks runs'],
            ['cleanup','4','trash actions'],
            ['ui','61','interaction'],
          ].map(([n,c,m])=>(
            <div key={n} className="card" style={{flex:'1 1 180px', padding:'12px 14px'}}>
              <div className="card-eyebrow" style={{margin:0}}>{n}</div>
              <div className="row mt-2"><span className="mono lime" style={{fontSize:18, fontWeight:700}}>{c}</span><span className="right subtle mono" style={{fontSize:10}}>{m}</span></div>
            </div>
          ))}
        </div>

        <h2 className="detail-h2 mt-6">Live tail · subprocess</h2>
        <div className="log" style={{maxHeight:240}}>
<span className="ts">14:30:01</span> <span className="dim">[sync.info]</span> SyncCoordinator.push begin · 3 candidates{'\n'}
<span className="ts">14:30:01</span> <span className="dim">[subprocess.debug]</span> /usr/bin/git status --porcelain=v2 --branch -z{'\n'}
<span className="ts">14:30:02</span> <span className="dim">[secrets.info]</span> gitleaks dir --staged --no-git --report-format json{'\n'}
<span className="ts">14:30:03</span> <span className="ok">[secrets.info]</span> 0 findings · 2 allowlisted · 47 files{'\n'}
<span className="ts">14:30:03</span> <span className="dim">[subprocess.debug]</span> /usr/bin/tar -czf backups/2026-04-28T14-30-pre-push.tgz dotfiles preferences{'\n'}
<span className="ts">14:30:05</span> <span className="dim">[subprocess.debug]</span> /usr/bin/git commit -s -m "install ripgrep, fd, eza · iterm2 prefs"{'\n'}
<span className="ts">14:30:05</span> <span className="dim">[subprocess.debug]</span> /usr/bin/git push origin main{'\n'}
<span className="ts">14:30:07</span> <span className="ok">[sync.info]</span> push ok · a3f9c2e → origin/main{'\n'}
<span className="ts">14:30:07</span> <span className="warn">[ui.error]</span> AppleScript quit timed out for com.googlecode.iterm2 (5s){'\n'}
        </div>

        <div className="row mt-4 gap-3">
          <div className="card flex-1">
            <div className="card-eyebrow">REDACTION · pre-export</div>
            <div className="mono subtle" style={{fontSize:11}}>Same gitleaks rules as commit-time. Provider keys (AWS/GitHub PAT/OpenAI/Stripe/Anthropic/Slack) blanked to <span className="lime">***</span> before bundle write.</div>
          </div>
          <div className="card" style={{width:280}}>
            <div className="card-eyebrow">CRASH REPORTS</div>
            <div className="mono subtle" style={{fontSize:11}}>macOS submits to Apple. Sojourn never collects them. No server exists.</div>
          </div>
        </div>
      </div>
    </div>
  </>
);

// === SECRET FINDINGS MODAL — high-confidence 5s lockout ===
const SecretFindingsSheet = ({ onClose }) => {
  const [secs, setSecs] = useState(3);
  return (
    <div className="sheet" style={{borderTop:'2px solid var(--bzr-warn)'}}>
      <div className="sheet-head" style={{background:'rgba(232,163,61,0.08)'}}>
        <Eyebrow>HYGIENE / SECRETS / GITLEAKS · HIGH-CONFIDENCE PROVIDER KEY</Eyebrow>
        <h2 className="stencil" style={{fontSize:24, fontWeight:800, marginTop:6, letterSpacing:'0.04em', color:'var(--bzr-warn)'}}>READ THIS BEFORE YOU BYPASS.</h2>
        <div className="subtle mt-2" style={{fontSize:12}}>Two findings classified <span className="mono warn">high</span>. Bypass is locked for 5 seconds — this is on purpose.</div>
      </div>
      <div className="sheet-body">
        <div className="card" style={{padding:0}}>
          {[
            ['github-pat',  'dotfiles/dot_zshrc.tmpl', 'L 78',  'ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', 'GITHUB PAT'],
            ['aws-access',  'preferences/com.aws.cli.plist', 'AccessKey', 'AKIA****************', 'AWS ACCESS KEY ID'],
          ].map((r,i)=>(
            <div key={i} style={{padding:'12px 14px', borderBottom: i<1?'0.5px solid var(--hairline-inner)':'none'}}>
              <div className="row">
                <span className="badge badge-tier-e">HIGH</span>
                <span style={{fontFamily:'var(--f-stencil)', fontSize:13, fontWeight:800, letterSpacing:'0.04em', marginLeft:8}}>{r[4]}</span>
                <span className="right mono subtle" style={{fontSize:10}}>rule: {r[0]}</span>
              </div>
              <div className="mono mt-2" style={{fontSize:11}}>{r[1]} · <span className="subtle">{r[2]}</span></div>
              <div className="mono lime mt-2" style={{fontSize:11, background:'rgba(0,0,0,0.30)', padding:'4px 8px', borderRadius:4, border:'0.5px solid var(--hairline-inner)'}}>{r[3]}</div>
            </div>
          ))}
        </div>

        <div className="row mt-4 gap-2">
          <span className="badge badge-mute">RULES · 142</span>
          <span className="badge badge-mute">FILES · 47 SCANNED</span>
          <span className="right mono subtle" style={{fontSize:10}}>BUNDLED · gitleaks 8.30.1 · MIT</span>
        </div>

        <div className="callout callout-danger mt-4">
          <div className="callout-mark">!</div>
          <div className="callout-body">
            <div className="callout-title">XZ-CLASS THREATS NOT BLOCKED BY THIS</div>
            <div className="callout-text">Multi-year maintainer infiltration doesn't surface in your diff. Cooldown blocks short-window attacks (axios 1.14.1, Shai-Hulud, Solana web3.js). gitleaks blocks accidental commits of live keys. Two different defenses.</div>
          </div>
        </div>
      </div>
      <div className="sheet-foot">
        <button className="btn btn-ghost" onClick={onClose}>Cancel commit</button>
        <button className="btn btn-glass">Add to allowlist</button>
        <button className="btn btn-danger" style={{opacity:0.5}} disabled>
          <Icon name="x" size={11}/> Commit anyway · {secs}s
        </button>
      </div>
    </div>
  );
};

// === TOOL PATHS PROBE PANEL (used inline in Bootstrap & Settings) ===
const ToolMatrix = () => (
  <div className="card mono" style={{fontSize:11}}>
    {[
      ['xcode-select', '/usr/bin/xcode-select', 'CLT 16.2', 'ok'],
      ['git',          '/usr/bin/git',          '2.42.1 · system', 'ok'],
      ['brew',         '/opt/homebrew/bin/brew','4.4.7 · Apple-Silicon', 'ok'],
      ['mpm',          '/opt/homebrew/bin/mpm', '6.3.0 · brew install', 'ok'],
      ['chezmoi',      '/opt/homebrew/bin/chezmoi','2.70.2 · brew', 'ok'],
      ['gitleaks',     '…/Resources/bin/gitleaks','8.30.1 · bundled · MIT', 'lime'],
      ['age',          '…/Resources/bin/age',   '1.2.0 · bundled · MIT', 'lime'],
      ['npm',          '~/.npm-global/bin/npm', '— · on-demand · brew install node', 'subtle'],
      ['pnpm',         '—',                     '— · v2 deferred · not via mpm', 'subtle'],
    ].map((r,i)=>(
      <div key={r[0]} className="row" style={{padding:'5px 0', borderBottom: i<8 ? '0.5px dashed var(--hairline)' : 'none'}}>
        <span style={{flex:1}}>{r[0]}</span>
        <span className={r[3]==='lime'?'lime':r[3]==='subtle'?'subtle':''}>{r[1]}</span>
        <span className="subtle" style={{marginLeft:14, fontSize:10, width:230, textAlign:'right'}}>{r[2]}</span>
      </div>
    ))}
    <div className="mono subtle mt-3" style={{fontSize:10}}>HARDCODED CANDIDATES · NO `which` · APP-CONTEXT $PATH IS LAUNCHSERVICES-MINIMAL</div>
  </div>
);

window.OnboardScreen = OnboardScreen;
window.ConflictsScreen = ConflictsScreen;
window.DiagnosticsScreen = DiagnosticsScreen;
window.SecretFindingsSheet = SecretFindingsSheet;
window.ToolMatrix = ToolMatrix;
