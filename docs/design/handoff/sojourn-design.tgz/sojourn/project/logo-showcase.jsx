// Logo showcase artboard — shows the new Sojourn mark in context
// (app icon, mark scales, monochrome, in-product placements)

const LogoShowcase = () => (
  <div style={{
    width: '100%',
    height: '100%',
    background: 'var(--bg-primary)',
    color: 'var(--text-primary)',
    display: 'grid',
    gridTemplateColumns: '1.1fr 1fr',
    gridTemplateRows: 'auto 1fr',
    fontFamily: 'var(--f-sans)',
  }}>
    {/* Top strip — eyebrow + the headline lockup */}
    <div style={{
      gridColumn: '1 / -1',
      padding: '36px 48px 24px',
      borderBottom: '0.5px solid var(--hairline)',
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 40,
    }}>
      <div>
        <Eyebrow>BIZARRE / SOJOURN / IDENTITY MARK</Eyebrow>
        <div style={{
          fontFamily: 'var(--f-stencil)',
          fontWeight: 800,
          fontSize: 78,
          lineHeight: 0.92,
          letterSpacing: '0.01em',
          marginTop: 14,
        }}>
          A FRAME.<br/>
          <span className="lime">A PATH</span> THROUGH IT.
        </div>
        <div style={{maxWidth: 540, marginTop: 18, color: 'var(--text-secondary)', fontSize: 14, lineHeight: 1.5}}>
          The mark is a stencil S carved from a square frame — two horizontal cuts keep it
          legible at 12 px (menu bar) and lets the negative space read as a path between two
          machines. No suitcase. No swirl. Just the verb.
        </div>
      </div>
      {/* Hero app icon */}
      <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:16, flexShrink:0}}>
        <div style={{
          width: 200, height: 200,
          filter: 'drop-shadow(0 24px 48px rgba(198,255,36,0.18)) drop-shadow(0 8px 16px rgba(0,0,0,0.5))',
        }}>
          <SojournAppIcon size={200}/>
        </div>
        <div className="mono" style={{fontSize:10, color:'var(--text-tertiary)', letterSpacing:'0.08em'}}>
          APP ICON · 1024PT MASTER
        </div>
      </div>
    </div>

    {/* Left — scale ladder & monochrome variants */}
    <div style={{padding: '32px 48px', borderRight: '0.5px solid var(--hairline)', overflow: 'hidden'}}>
      <Eyebrow>SCALE LADDER</Eyebrow>
      <div style={{
        marginTop: 20,
        display: 'flex',
        alignItems: 'flex-end',
        gap: 36,
        padding: '32px 28px',
        background: 'rgba(20,20,22,0.4)',
        border: '0.5px solid var(--hairline)',
        borderRadius: 6,
      }}>
        {[12, 16, 24, 40, 64, 96].map(sz => (
          <div key={sz} style={{display:'flex', flexDirection:'column', alignItems:'center', gap:10}}>
            <SojournMark size={sz} color="var(--bzr-lime)"/>
            <span className="mono" style={{fontSize:9, color:'var(--text-tertiary)', letterSpacing:'0.08em'}}>{sz}PX</span>
          </div>
        ))}
      </div>

      <div style={{marginTop: 32}}><Eyebrow>MONOCHROME · INVERTED · OUTLINE</Eyebrow></div>
      <div style={{
        marginTop: 20,
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: 12,
      }}>
        <div style={{padding: 28, background:'#0E0E0E', border: '0.5px solid var(--hairline)', borderRadius: 6, display:'flex', flexDirection:'column', alignItems:'center', gap:14}}>
          <SojournMark size={64} color="var(--bzr-lime)"/>
          <span className="mono" style={{fontSize:9, color:'var(--text-tertiary)', letterSpacing:'0.08em'}}>LIME / VOID</span>
        </div>
        <div style={{padding: 28, background:'var(--bzr-lime)', borderRadius: 6, display:'flex', flexDirection:'column', alignItems:'center', gap:14}}>
          <SojournMark size={64} color="#0E0E0E"/>
          <span className="mono" style={{fontSize:9, color:'#0E0E0E', letterSpacing:'0.08em', opacity:0.7}}>VOID / LIME</span>
        </div>
        <div style={{padding: 28, background:'#F4F4F2', borderRadius: 6, display:'flex', flexDirection:'column', alignItems:'center', gap:14}}>
          <SojournMark size={64} color="#0E0E0E"/>
          <span className="mono" style={{fontSize:9, color:'#0E0E0E', letterSpacing:'0.08em', opacity:0.6}}>VOID / BONE</span>
        </div>
      </div>
    </div>

    {/* Right — wordmark, in-product placements */}
    <div style={{padding: '32px 48px', overflow: 'hidden'}}>
      <Eyebrow>WORDMARK · LOCKUP</Eyebrow>
      <div style={{
        marginTop: 20,
        padding: '32px 28px',
        background: 'rgba(20,20,22,0.4)',
        border: '0.5px solid var(--hairline)',
        borderRadius: 6,
        display: 'flex',
        flexDirection: 'column',
        gap: 22,
      }}>
        <SojournWordmark height={48} color="var(--bzr-lime)"/>
        <SojournWordmark height={28} color="var(--text-primary)"/>
        <SojournWordmark height={16} color="var(--text-secondary)"/>
      </div>

      <div style={{marginTop: 32}}><Eyebrow>IN-PRODUCT PLACEMENTS</Eyebrow></div>
      <div style={{marginTop: 20, display: 'flex', flexDirection: 'column', gap: 14}}>
        {/* Menu bar mock */}
        <div>
          <div className="mono" style={{fontSize:9, color:'var(--text-tertiary)', letterSpacing:'0.08em', marginBottom:8}}>MENU BAR · 12PX</div>
          <div style={{
            background: 'rgba(40,40,42,0.92)',
            backdropFilter: 'blur(20px)',
            borderRadius: 6,
            padding: '6px 12px',
            display: 'flex',
            alignItems: 'center',
            gap: 14,
            fontSize: 11,
            border: '0.5px solid rgba(255,255,255,0.08)',
          }}>
            <SojournMark size={12} color="var(--text-primary)"/>
            <span style={{fontWeight: 600}}>Sojourn</span>
            <span style={{color: 'var(--text-secondary)'}}>File</span>
            <span style={{color: 'var(--text-secondary)'}}>Edit</span>
            <span style={{color: 'var(--text-secondary)'}}>Sync</span>
            <span style={{marginLeft: 'auto', display:'inline-flex', alignItems:'center', gap:5, color:'var(--bzr-lime)'}}>
              <SojournMark size={11} color="var(--bzr-lime)"/>
              <span className="mono" style={{fontSize:9, letterSpacing:'0.05em'}}>↑ 3</span>
            </span>
          </div>
        </div>
        {/* Title bar mock */}
        <div>
          <div className="mono" style={{fontSize:9, color:'var(--text-tertiary)', letterSpacing:'0.08em', marginBottom:8}}>WINDOW TITLE BAR · 13PX</div>
          <div style={{
            background: 'linear-gradient(180deg, #2a2a2c 0%, #1f1f21 100%)',
            border: '0.5px solid rgba(255,255,255,0.08)',
            borderRadius: '6px 6px 0 0',
            padding: '8px 14px',
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            fontSize: 12,
          }}>
            <div style={{display:'flex', gap:6}}>
              <span style={{width:11, height:11, borderRadius:'50%', background:'#FF5F57', display:'inline-block'}}></span>
              <span style={{width:11, height:11, borderRadius:'50%', background:'#FEBC2E', display:'inline-block'}}></span>
              <span style={{width:11, height:11, borderRadius:'50%', background:'#28C840', display:'inline-block'}}></span>
            </div>
            <div style={{flex:1, display:'flex', alignItems:'center', justifyContent:'center', gap:7, color:'var(--text-secondary)', fontWeight:500}}>
              <SojournMark size={13} color="var(--bzr-lime)"/>
              <span>Sojourn</span>
            </div>
            <div style={{width:62}}></div>
          </div>
        </div>
        {/* Footer wordmark */}
        <div>
          <div className="mono" style={{fontSize:9, color:'var(--text-tertiary)', letterSpacing:'0.08em', marginBottom:8}}>SPLASH · BOOTSTRAP · 14PX</div>
          <div style={{
            background: 'rgba(20,20,22,0.6)',
            border: '0.5px solid var(--hairline)',
            borderRadius: 6,
            padding: '24px 22px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}>
            <SojournWordmark height={14} color="var(--text-primary)"/>
            <span className="mono" style={{fontSize: 9, color:'var(--text-tertiary)', letterSpacing:'0.08em'}}>v0.1 · BIZARRE INDUSTRIES</span>
          </div>
        </div>
      </div>
    </div>
  </div>
);

window.LogoShowcase = LogoShowcase;
