// Power surfaces, part 1 — JobInspector, ScheduleInspector, AgeKeysScreen, ChezmoiTemplatesScreen, GitleaksRulesScreen
// All render inside the standard MacWindow → content area, like other screens.

// ============================================================
// 1) JOB INSPECTOR — every subprocess as a structured row
// ============================================================
const JobInspectorScreen = () => {
  const jobs = [
    { id:'j-9f2c', verb:'pull', state:'running',   pid:34218, runtime:'00:00:42', cmd:'git', args:['fetch','--prune','origin'], lines:842, exit:null,  who:'auto · scheduler' },
    { id:'j-9f2b', verb:'scan', state:'running',   pid:34219, runtime:'00:00:11', cmd:'gitleaks', args:['dir','--report-format','json','/var/folders/…/staging.t81n'], lines:127, exit:null, who:'pre-push hook' },
    { id:'j-9f29', verb:'list', state:'success',   pid:34104, runtime:'00:00:08', cmd:'mpm', args:['--table-format','json','outdated'], lines:312, exit:0, who:'manual · ⌘R' },
    { id:'j-9f24', verb:'apply',state:'success',   pid:34087, runtime:'00:00:04', cmd:'chezmoi', args:['apply','--dry-run','-v'], lines:54, exit:0, who:'manual' },
    { id:'j-9f1a', verb:'sign', state:'failed',    pid:33912, runtime:'00:00:02', cmd:'git', args:['commit','-S','-m','snapshot 2026-04-26 14:21'], lines:14, exit:128, who:'push sheet' },
    { id:'j-9f17', verb:'export',state:'cancelled',pid:33890, runtime:'00:00:21', cmd:'defaults', args:['export','com.googlecode.iterm2','-'], lines:9, exit:null, who:'user · ⎋' },
    { id:'j-9efe', verb:'sync', state:'success',   pid:33402, runtime:'00:00:14', cmd:'brew', args:['outdated','--json=v2','--formula'], lines:178, exit:0, who:'auto · 1h tick' },
  ];
  const [sel, setSel] = useState('j-9f2c');
  const job = jobs.find(j => j.id === sel) || jobs[0];

  return (
    <>
      <Toolbar eyebrow="APP / JOBS / JobRunner · @MainActor" title="Job inspector">
        <div className="lg-segmented"><div className="active">All</div><div>Running 2</div><div>Failed 1</div></div>
        <button className="btn btn-glass"><Icon name="x" size={11}/> Cancel selected</button>
        <button className="btn btn-glass"><Icon name="trash" size={11}/> Clear completed</button>
      </Toolbar>
      <div className="content-body">
        <div className="midlist" style={{width: 320}}>
          <div className="ml-header"><span>JOBS · LAST 24H</span><span className="lime" style={{marginLeft:'auto'}}>{jobs.length}</span></div>
          {jobs.map(j => {
            const dotCls = j.state==='running'?'lime':j.state==='failed'?'danger':j.state==='cancelled'?'mute':'ok';
            return (
              <div key={j.id} className={`ml-row ${sel===j.id?'selected':''}`} onClick={()=>setSel(j.id)}>
                <div className="ml-row-icon" style={{
                  background: j.state==='running'?'rgba(198,255,36,0.18)' : j.state==='failed'?'rgba(240,82,91,0.20)' : 'rgba(255,255,255,0.06)',
                  color: j.state==='running'?'var(--bzr-lime)':j.state==='failed'?'var(--bzr-danger)':'var(--txt-secondary)',
                  fontFamily: 'var(--f-mono)', fontSize: 10
                }}>{j.cmd.slice(0,2)}</div>
                <div className="ml-row-body">
                  <div className="ml-row-title">
                    <span className="mono" style={{fontSize: 11, marginRight: 6, color:'var(--txt-tertiary)'}}>{j.id}</span>
                    {j.cmd} {j.verb}
                  </div>
                  <div className="ml-row-meta">
                    <span className={`dot ${dotCls}`}></span>
                    <span>{j.state}</span>
                    <span className="sep">·</span>
                    <span>{j.runtime}</span>
                    <span className="sep">·</span>
                    <span>{j.lines} ln</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="detail">
          <div className="detail-inner">
            <Eyebrow>JOB · {job.id} · PID {job.pid} · {job.who.toUpperCase()}</Eyebrow>
            <h1 className="detail-h1" style={{fontSize: 30}}>$ {job.cmd} {job.verb}</h1>
            <div className="row mt-3 gap-2">
              {job.state==='running'  && <span className="badge badge-lime">● RUNNING</span>}
              {job.state==='success'  && <span className="badge badge-success">EXIT 0</span>}
              {job.state==='failed'   && <span className="badge" style={{background:'rgba(240,82,91,0.20)', color:'#ff8189'}}>EXIT {job.exit}</span>}
              {job.state==='cancelled'&& <span className="badge badge-mute">CANCELLED</span>}
              <span className="badge badge-mute">runtime {job.runtime}</span>
              <span className="badge badge-mute">{job.lines} log lines</span>
              <span className="badge badge-mute">stdout 64KB pipe</span>
              <span className="right">
                {job.state==='running' && <button className="btn btn-glass"><Icon name="x" size={11}/> Cancel · SIGINT then SIGTERM</button>}
                <button className="btn btn-glass"><Icon name="copy" size={11}/> Copy cmdline</button>
                <button className="btn btn-glass"><Icon name="upload" size={11}/> Export bundle</button>
              </span>
            </div>

            <div className="row mt-4 gap-3" style={{alignItems:'stretch'}}>
              <div className="card flex-1">
                <div className="card-eyebrow">STRUCTURED INVOCATION</div>
                <div className="code">
<span className="c">// resolved by ToolPathResolver — never $PATH at runtime</span>{'\n'}
<span className="lime">cmd</span>     <span className="op">=</span> <span className="s">"{`/opt/homebrew/bin/${job.cmd}`}".replace("/git","/git")</span>{'\n'}
<span className="lime">args</span>    <span className="op">=</span> [{job.args.map(a => `"${a}"`).join(', ')}]{'\n'}
<span className="lime">cwd</span>     <span className="op">=</span> <span className="s">"~/.local/share/sojourn/repo"</span>{'\n'}
<span className="lime">env</span>     <span className="op">=</span> {`{ PATH: "/usr/bin:/bin", HOME, LANG: "en_US.UTF-8" }`}{'\n'}
<span className="lime">stdin</span>   <span className="op">=</span> <span className="dim">/dev/null</span>{'\n'}
<span className="lime">timeout</span> <span className="op">=</span> 30s · <span className="warn">renewed by output</span>{'\n'}
<span className="lime">qos</span>     <span className="op">=</span> <span className="s">.utility</span>{'\n'}
                </div>
              </div>
              <div className="card" style={{width: 320}}>
                <div className="card-eyebrow">PROCESS HEALTH</div>
                <div className="col gap-2" style={{fontSize:12}}>
                  <Stat label="PID"          value={job.pid}/>
                  <Stat label="parent"       value="Sojourn (501)"/>
                  <Stat label="user"         value="zoe (501)"/>
                  <Stat label="rss"          value="14.2 MB"/>
                  <Stat label="cpu (avg)"    value="3.8%"/>
                  <Stat label="stdout/sec"   value="42 lines"/>
                  <Stat label="stderr"       value="0 bytes"/>
                  <Stat label="last activity"value="0.4s ago"/>
                </div>
              </div>
            </div>

            <h2 className="detail-h2 mt-6">Live log · ANSI parsed · ring buffer 8 KB rows</h2>
            <div className="card" style={{padding: 0}}>
              <div className="row" style={{padding:'8px 12px', borderBottom:'0.5px solid var(--hairline-inner)', fontSize:11}}>
                <span className="mono subtle">FILTER:</span>
                <span className="badge badge-lime">stdout</span>
                <span className="badge badge-mute">stderr</span>
                <span className="badge badge-mute">level ≥ info</span>
                <span className="right mono subtle" style={{fontSize:10}}>↑/↓ JUMP · ⌘F SEARCH · ⌘C COPY · ⌘E EXPORT (gitleaks-redacted)</span>
              </div>
              <div className="log" style={{borderRadius:0, border:'none', maxHeight: 280, fontSize: 11.5}}>
<span className="ts">14:23:18.014</span> <span className="dim">$</span> /usr/bin/git fetch --prune origin{'\n'}
<span className="ts">14:23:18.022</span> <span className="dim">→</span> exec(7 argv, env=4){'\n'}
<span className="ts">14:23:18.319</span> <span className="dim">stderr</span> <span className="warn">remote: Enumerating objects: 47, done.</span>{'\n'}
<span className="ts">14:23:18.502</span> <span className="dim">stderr</span> <span className="warn">remote: Counting objects: 100% (47/47), done.</span>{'\n'}
<span className="ts">14:23:18.671</span> <span className="dim">stderr</span> <span className="warn">remote: Total 32 (delta 18), reused 0 (delta 0)</span>{'\n'}
<span className="ts">14:23:19.018</span> <span className="ok">✓</span> Unpacking objects: 100% (32/32){'\n'}
<span className="ts">14:23:19.219</span> <span className="lime">→</span> From github.com:zoekat/my-mac{'\n'}
<span className="ts">14:23:19.220</span> <span className="lime">→</span>   3a2f1c..b94e2a  main → origin/main{'\n'}
<span className="ts">14:23:19.221</span> <span className="lime">→</span>   * [new branch] personal → origin/personal{'\n'}
<span className="ts">14:23:19.224</span> <span className="dim">$</span> /usr/bin/git rev-list --left-right --count HEAD...origin/main{'\n'}
<span className="ts">14:23:19.341</span> <span className="ok">✓</span> 0 ahead · 4 behind{'\n'}
<span className="ts">14:23:19.342</span> <span className="lime">━</span> running 00:00:42 · waiting for chezmoi diff{'\n'}
              </div>
            </div>

            <h2 className="detail-h2 mt-5">Outcome plan</h2>
            <div className="row gap-2" style={{flexWrap:'wrap'}}>
              <span className="badge badge-mute">on exit 0 → emit JobOutcome.success(stdout)</span>
              <span className="badge badge-mute">on exit ≠ 0 → JobOutcome.failure(exit, stderr) · alert if user-initiated</span>
              <span className="badge badge-mute">on cancel → SIGINT → 250ms grace → SIGTERM</span>
              <span className="badge badge-mute">on timeout → cancel chain · log "tool stalled"</span>
              <span className="badge badge-tier-c">advisory: PTY-wrap if stdout stalls 3s</span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

const Stat = ({ label, value }) => (
  <div className="row" style={{borderBottom:'0.5px dashed var(--hairline-inner)', padding:'3px 0'}}>
    <span className="mono subtle" style={{fontSize: 10, letterSpacing:'0.10em', flex:1}}>{label.toUpperCase()}</span>
    <span className="mono lime" style={{fontSize: 11}}>{value}</span>
  </div>
);

// ============================================================
// 2) SCHEDULE INSPECTOR — NSBackgroundActivityScheduler
// ============================================================
const ScheduleInspectorScreen = () => (
  <>
    <Toolbar eyebrow="APP / SCHEDULING / NSBackgroundActivityScheduler" title="Schedule">
      <div className="lg-segmented"><div className="active">Activities</div><div>History</div></div>
      <button className="btn btn-glass"><Icon name="play" size={11}/> Run all now</button>
      <button className="btn btn-glass"><Icon name="pause" size={11}/> Pause when on battery</button>
    </Toolbar>
    <div className="content-body">
      <div className="midlist" style={{width: 340}}>
        <div className="ml-header"><span>SCHEDULED ACTIVITIES · 5</span></div>
        {[
          ['app.bizarre.sojourn.refresh-outdated', '1h ± 15m', 'in 38m',  'utility',     'idle'],
          ['app.bizarre.sojourn.git-fetch',         '6h ± 30m', 'in 4h 12m','utility',    'idle'],
          ['app.bizarre.sojourn.gitleaks-fleet',    '24h ± 2h', 'in 18h',  'background',  'skipped · battery'],
          ['app.bizarre.sojourn.deletions-gc',      '7d ± 12h', 'in 5d 9h','background',  'idle'],
          ['app.bizarre.sojourn.backups-prune',     '24h ± 2h', 'in 22h',  'background',  'idle'],
        ].map((r, i) => (
          <div key={i} className={`ml-row ${i===0?'selected':''}`}>
            <div className="ml-row-icon" style={{background: i===2?'rgba(232,163,61,0.18)':'rgba(255,255,255,0.06)', color: i===2?'#ffb84a':'var(--txt-primary)'}}>
              <Icon name={i===2?'pause':'sync'} size={13}/>
            </div>
            <div className="ml-row-body">
              <div className="ml-row-title">{r[0].split('.').pop()}</div>
              <div className="ml-row-meta">
                <span>{r[1]}</span>
                <span className="sep">·</span>
                <span>next {r[2]}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="detail">
        <div className="detail-inner">
          <Eyebrow>REFRESH-OUTDATED · QOS UTILITY · APP NAP RESPECTED</Eyebrow>
          <h1 className="detail-h1" style={{fontSize: 30}}>REFRESH OUTDATED.</h1>
          <div className="detail-sub">Polls all 12 mpm-supported managers, refreshes the JSON API caches, fires the menu-bar dot if anything new appears past its cooldown. Never blocks the UI.</div>

          <div className="row mt-4 gap-3" style={{alignItems:'stretch'}}>
            <div className="card flex-1">
              <div className="card-eyebrow">SCHEDULER CONFIG · settings.toml</div>
              <div className="code">
<span className="c">// Apple recommends ≥ 10 minutes for non-battery-degrading tasks.</span>{'\n'}
[scheduler.<span className="lime">refresh_outdated</span>]{'\n'}
identifier      <span className="op">=</span> <span className="s">"app.bizarre.sojourn.refresh-outdated"</span>{'\n'}
interval        <span className="op">=</span> <span className="n">3600</span>      <span className="c">// 1 hour</span>{'\n'}
tolerance       <span className="op">=</span> <span className="n">900</span>       <span className="c">// ±15 minutes</span>{'\n'}
qos             <span className="op">=</span> <span className="s">"utility"</span>{'\n'}
repeats         <span className="op">=</span> <span className="lime">true</span>{'\n'}
requires_power  <span className="op">=</span> <span className="warn">false</span>      <span className="c">// runs on battery (cheap)</span>{'\n'}
requires_net    <span className="op">=</span> <span className="lime">true</span>{'\n'}
respects_app_nap<span className="op">=</span> <span className="lime">true</span>      <span className="c">// HARD requirement</span>{'\n'}
              </div>
            </div>

            <div className="card" style={{width: 340}}>
              <div className="card-eyebrow">NEXT-RUN PREDICTION</div>
              <div style={{position:'relative', padding:'12px 0'}}>
                <div style={{height:6, background:'rgba(255,255,255,0.06)', borderRadius:3, position:'relative'}}>
                  <div style={{position:'absolute', left:0, width:'68%', height:6, background:'var(--bzr-lime)', borderRadius:3}}></div>
                  <div style={{position:'absolute', left:'53%', width:'30%', height:6, background:'rgba(198,255,36,0.25)', borderRadius:3, top:0}}></div>
                </div>
                <div style={{display:'flex', justifyContent:'space-between', marginTop:6, fontSize:10}} className="mono subtle">
                  <span>ran 22m ago</span>
                  <span className="lime">target 1h</span>
                  <span>tolerance 1h 15m</span>
                </div>
              </div>
              <div className="col gap-2" style={{fontSize:12, marginTop: 8}}>
                <Stat label="last run"     value="13:41 · 14s"/>
                <Stat label="next earliest"value="14:26 (38m)"/>
                <Stat label="next latest"  value="14:56 (1h 8m)"/>
                <Stat label="App Nap"      value="awake"/>
                <Stat label="on battery"   value="0% drain budget used"/>
              </div>
            </div>
          </div>

          <h2 className="detail-h2 mt-6">Recent runs · why &amp; how long</h2>
          <table className="bzr-table">
            <thead>
              <tr><th>When</th><th>State</th><th>Duration</th><th>Trigger / outcome</th><th></th></tr>
            </thead>
            <tbody>
              <tr><td className="mono">14:01:22</td><td><span className="badge badge-success">RAN</span></td><td className="col-meta">14.2s</td><td>fetched 8 mgr · 12 outdated · 2 newly past cooldown</td><td className="col-meta">battery 87%</td></tr>
              <tr><td className="mono">13:02:11</td><td><span className="badge badge-mute">SKIPPED</span></td><td className="col-meta">—</td><td>App Nap suspended · system idle &gt; 30 min</td><td className="col-meta">lid closed</td></tr>
              <tr><td className="mono">12:00:47</td><td><span className="badge badge-success">RAN</span></td><td className="col-meta">11.9s</td><td>fetched 8 mgr · no new outdated</td><td className="col-meta">power</td></tr>
              <tr><td className="mono">11:14:33</td><td><span className="badge" style={{background:'rgba(232,163,61,0.20)',color:'#ffb84a'}}>DEFERRED</span></td><td className="col-meta">—</td><td>requires_net=true · network unreachable (Wi-Fi off)</td><td className="col-meta">retry +5m</td></tr>
              <tr><td className="mono">10:00:01</td><td><span className="badge badge-success">RAN</span></td><td className="col-meta">9.7s</td><td>scheduler awoke at end of tolerance window</td><td className="col-meta">power</td></tr>
            </tbody>
          </table>

          <div className="callout mt-5">
            <div className="callout-mark">!</div>
            <div className="callout-body">
              <div className="callout-title">v2 · OPTIONAL LAUNCH AGENT</div>
              <div className="callout-text">
                For users who want fetches to fire even when Sojourn isn't running, opt in to a <span className="mono">SMAppService.agent</span>-managed LaunchAgent. Strictly opt-in; uninstalled cleanly via the same toggle. Requires re-signing &amp; notarising; v0.1 ships scheduler-only.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </>
);

// ============================================================
// 3) AGE KEYS — recipients, identity, encrypted file index
// ============================================================
const AgeKeysScreen = () => (
  <>
    <Toolbar eyebrow="HYGIENE / SECRETS / age 1.2.0 · X25519" title="age recipients & identity">
      <div className="lg-segmented"><div className="active">Recipients</div><div>Identity</div><div>Encrypted files</div></div>
      <button className="btn btn-glass"><Icon name="plus" size={11}/> Add recipient</button>
      <button className="btn btn-glass"><Icon name="key" size={11}/> Rotate identity</button>
    </Toolbar>
    <div className="content-body">
      <div className="midlist" style={{width: 320}}>
        <div className="ml-header"><span>RECIPIENTS · 4</span><span className="lime" style={{marginLeft:'auto'}}>3 active</span></div>
        {[
          ['work-mbp',     'this Mac', 'X25519', 'age1q2…7m4n', 'active', 'key'],
          ['personal-mini','onboarded 2026-04-12', 'X25519', 'age1f8…rk2c', 'active', 'laptop'],
          ['ci-runner',    'onboarded 2026-03-30', 'X25519', 'age14p…9w1d', 'active', 'server'],
          ['old-imac',     'revoked 2026-04-03', 'X25519', 'age1m9…0xv7', 'revoked', 'x'],
        ].map((r, i) => (
          <div key={i} className={`ml-row ${i===0?'selected':''}`}>
            <div className="ml-row-icon" style={{
              background: r[4]==='revoked'?'rgba(240,82,91,0.18)':i===0?'rgba(198,255,36,0.18)':'rgba(255,255,255,0.06)',
              color: r[4]==='revoked'?'#ff8189':i===0?'var(--bzr-lime)':'var(--txt-primary)'
            }}>
              <Icon name={r[5]} size={13}/>
            </div>
            <div className="ml-row-body">
              <div className="ml-row-title">{r[0]} {i===0 && <span className="badge badge-lime" style={{fontSize:9, padding:'1px 5px', marginLeft:4}}>THIS MAC</span>}</div>
              <div className="ml-row-meta">
                <span className="mono" style={{fontSize:10}}>{r[3]}</span>
                <span className="sep">·</span>
                <span>{r[4]}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="detail">
        <div className="detail-inner">
          <Eyebrow>WORK-MBP · X25519 · ENCRYPTED IN KEYCHAIN · ACCESSIBLEAFTERFIRSTUNLOCK</Eyebrow>
          <h1 className="detail-h1" style={{fontSize: 30}}>WORK-MBP · ACTIVE RECIPIENT</h1>
          <div className="detail-sub">Identity created 2026-04-09 during bootstrap. Keychain item is bound to this user, this Mac, and survives reboots but not user removal.</div>

          <div className="row mt-4 gap-3" style={{alignItems:'stretch'}}>
            <div className="card flex-1">
              <div className="card-eyebrow">PUBLIC RECIPIENT · committed to repo</div>
              <div className="code" style={{fontSize: 11.5}}>
<span className="c"># .chezmoi.toml.tmpl ─ written on bootstrap, baked from .sojourn/recipients/</span>{'\n\n'}
[<span className="lime">edit</span>]{'\n'}
command <span className="op">=</span> <span className="s">"nvim"</span>{'\n\n'}
[<span className="lime">data</span>]{'\n'}
hostname <span className="op">=</span> <span className="s">"work-mbp"</span>{'\n\n'}
[<span className="lime">data.age</span>]{'\n'}
recipients <span className="op">=</span> [{'\n'}
  <span className="s">"age1q2hxy7yvfjxd9pf09qlk5e3kl5p6wm6z7w8m4n"</span>,  <span className="c">// work-mbp</span>{'\n'}
  <span className="s">"age1f8w90rk5q3xzv8jc3kkq4t9lmrq2sfx3rjs7rk2c"</span>,  <span className="c">// personal-mini</span>{'\n'}
  <span className="s">"age14p3kl9mxc8h4rq2sn7xpz5qwt0wv3lmkwk9w1d"</span>,    <span className="c">// ci-runner</span>{'\n'}
]{'\n\n'}
<span className="c"># age age never sees the private key. encryption fans-out to all recipients.</span>{'\n'}
<span className="c"># revoked: age1m9..0xv7 — re-encrypt all .age files after removal (one-click).</span>{'\n'}
              </div>
            </div>

            <div className="card" style={{width: 340}}>
              <div className="card-eyebrow">PRIVATE IDENTITY · this Mac only</div>
              <div className="col gap-2" style={{fontSize:12}}>
                <Stat label="kind"      value="X25519"/>
                <Stat label="created"   value="2026-04-09 09:11"/>
                <Stat label="storage"   value="Keychain"/>
                <Stat label="ACL"       value="Sojourn.app only"/>
                <Stat label="exportable"value="false"/>
                <Stat label="rotated"   value="never"/>
              </div>
              <div className="row mt-3 gap-2">
                <button className="btn btn-glass" style={{flex:1}}><Icon name="key" size={11}/> Rotate</button>
                <button className="btn btn-glass" style={{flex:1}}><Icon name="upload" size={11}/> Export to file (one-time)</button>
              </div>
              <div className="mono subtle mt-3" style={{fontSize:10}}>
                ROTATION RE-ENCRYPTS EVERY .age FILE WITH THE NEW IDENTITY + ALL ACTIVE RECIPIENTS, COMMITS, AND PUSHES.
              </div>
            </div>
          </div>

          <h2 className="detail-h2 mt-6">Encrypted files · 7 · indexed from chezmoi source state</h2>
          <table className="bzr-table">
            <thead>
              <tr><th>Path</th><th>Source</th><th>Bytes</th><th>Last modified</th><th>Recipients</th><th></th></tr>
            </thead>
            <tbody>
              <tr><td className="col-pkg">.aws/credentials</td><td className="col-meta">private_aws/encrypted_credentials.age</td><td className="col-meta">1.2 KB</td><td className="col-meta">14:08 today</td><td className="col-meta">3 of 3</td><td><span className="badge badge-success">OK</span></td></tr>
              <tr><td className="col-pkg">.config/gh/hosts.yml</td><td className="col-meta">private_dot_config/private_gh/encrypted_hosts.yml.age</td><td className="col-meta">412 B</td><td className="col-meta">2026-04-21</td><td className="col-meta">3 of 3</td><td><span className="badge badge-success">OK</span></td></tr>
              <tr><td className="col-pkg">.ssh/config.work</td><td className="col-meta">private_dot_ssh/encrypted_config.work.age</td><td className="col-meta">2.1 KB</td><td className="col-meta">2026-04-19</td><td className="col-meta">2 of 3</td><td><span className="badge badge-tier-c">RE-ENCRYPT</span></td></tr>
              <tr><td className="col-pkg">.npmrc</td><td className="col-meta">encrypted_dot_npmrc.age</td><td className="col-meta">189 B</td><td className="col-meta">2026-04-15</td><td className="col-meta">3 of 3</td><td><span className="badge badge-success">OK</span></td></tr>
            </tbody>
          </table>
          <div className="mono subtle mt-3" style={{fontSize: 10}}>
            ↻ INDEX BUILT BY <span className="lime">chezmoi managed --include=encrypted</span> · 23 ms · 7 results
          </div>
        </div>
      </div>
    </div>
  </>
);

// ============================================================
// 4) CHEZMOI TEMPLATES — data, ignore patterns
// ============================================================
const ChezmoiTemplatesScreen = () => (
  <>
    <Toolbar eyebrow="CARRY / DOTFILES / chezmoi 2.70.2 / templates" title="Templates & data">
      <div className="lg-segmented"><div>Tree</div><div>Diff</div><div className="active">Templates</div></div>
      <button className="btn btn-glass"><Icon name="terminal" size={11}/> chezmoi data</button>
      <button className="btn btn-primary"><Icon name="check" size={11}/> Save & re-render</button>
    </Toolbar>
    <div className="content-body">
      <div className="midlist" style={{width: 320}}>
        <div className="ml-header"><span>TEMPLATES · 11</span></div>
        {[
          ['dot_zshrc.tmpl',                 'host gates · 4 ifs'],
          ['dot_gitconfig.tmpl',             'name/email per host'],
          ['dot_config/nvim/init.lua.tmpl',  'OS-aware paths'],
          ['dot_config/wezterm/wezterm.lua.tmpl','font size per machine'],
          ['private_dot_aws/credentials.age','encrypted · static'],
          ['executable_dot_local/bin/sj-helper','perm 0755'],
          ['create_dot_hushlogin',           'create-once'],
          ['symlink_dot_config/k9s',         'symlink target'],
          ['.chezmoiignore',                 '12 patterns'],
          ['.chezmoiexternal.toml',          '3 externals'],
          ['.chezmoidata/colors.toml',       'shared palette'],
        ].map((r, i) => (
          <div key={i} className={`ml-row ${i===0?'selected':''}`}>
            <div className="ml-row-icon">{r[0].slice(0,1).toUpperCase()}</div>
            <div className="ml-row-body">
              <div className="ml-row-title">{r[0]}</div>
              <div className="ml-row-meta">{r[1]}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="detail">
        <div className="detail-inner">
          <Eyebrow>DOT_ZSHRC.TMPL · 4 PER-HOST GATES · 2 EXTERNAL DATA REFS</Eyebrow>
          <h1 className="detail-h1" style={{fontSize: 30}}>DOT_ZSHRC.TMPL</h1>

          <div className="row mt-4 gap-3" style={{alignItems:'stretch'}}>
            <div className="card flex-1">
              <div className="card-eyebrow">TEMPLATE · source</div>
              <div className="code" style={{fontSize: 11.5}}>
<span className="c"># aliases</span>{'\n'}
alias ll<span className="op">=</span><span className="s">'eza -lah'</span>{'\n\n'}
<span className="c"># work-only AWS profile, expanded by chezmoi at apply-time</span>{'\n'}
<span className="lime">{`{{- if eq .chezmoi.hostname "work-mbp" }}`}</span>{'\n'}
export AWS_PROFILE<span className="op">=</span><span className="s">"acme-prod"</span>{'\n'}
export VAULT_ADDR<span className="op">=</span><span className="s">"https://vault.acme.internal"</span>{'\n'}
<span className="lime">{`{{- end }}`}</span>{'\n\n'}
<span className="c"># palette (shared data file)</span>{'\n'}
export FZF_DEFAULT_OPTS<span className="op">=</span><span className="s">"--color=bg+:</span><span className="lime">{`{{ .colors.bg_alt }}`}</span><span className="s">,fg+:</span><span className="lime">{`{{ .colors.fg }}`}</span><span className="s">"</span>{'\n\n'}
<span className="lime">{`{{- if .features.aws_vault }}`}</span>{'\n'}
eval <span className="s">"$(aws-vault completion zsh)"</span>{'\n'}
<span className="lime">{`{{- end }}`}</span>{'\n'}
              </div>
            </div>

            <div className="card" style={{width: 360}}>
              <div className="card-eyebrow">DATA · chezmoi data --format=json (live)</div>
              <div className="code" style={{fontSize: 11}}>
{`{`}{'\n'}
  <span className="lime">"chezmoi"</span>: {`{`}{'\n'}
    <span className="lime">"hostname"</span>: <span className="s">"work-mbp"</span>,{'\n'}
    <span className="lime">"username"</span>: <span className="s">"zoe"</span>,{'\n'}
    <span className="lime">"os"</span>:       <span className="s">"darwin"</span>,{'\n'}
    <span className="lime">"arch"</span>:     <span className="s">"arm64"</span>{'\n'}
  {`},`}{'\n'}
  <span className="lime">"colors"</span>: {`{`}{'\n'}
    <span className="lime">"bg"</span>:     <span className="s">"#0E0E0E"</span>,{'\n'}
    <span className="lime">"bg_alt"</span>: <span className="s">"#1A1A1A"</span>,{'\n'}
    <span className="lime">"fg"</span>:     <span className="s">"#E4E4E4"</span>{'\n'}
  {`},`}{'\n'}
  <span className="lime">"features"</span>: {`{`}{'\n'}
    <span className="lime">"aws_vault"</span>: <span className="lime">true</span>,{'\n'}
    <span className="lime">"docker"</span>:    <span className="warn">false</span>{'\n'}
  {`}`}{'\n'}
{`}`}
              </div>
              <div className="row mt-3 gap-2">
                <button className="btn btn-glass" style={{flex:1}}><Icon name="edit" size={11}/> Edit data</button>
                <button className="btn btn-glass" style={{flex:1}}><Icon name="sync" size={11}/> Re-render diff</button>
              </div>
            </div>
          </div>

          <h2 className="detail-h2 mt-6">.chezmoiignore · per-machine exclusions</h2>
          <div className="card">
            <div className="code" style={{fontSize: 11.5}}>
<span className="c"># things never tracked anywhere</span>{'\n'}
.DS_Store{'\n'}
*.swp{'\n\n'}
<span className="c"># personal-mini doesn't have AWS work creds</span>{'\n'}
<span className="lime">{`{{- if ne .chezmoi.hostname "work-mbp" }}`}</span>{'\n'}
.aws/credentials{'\n'}
.config/aws-vault/{'\n'}
<span className="lime">{`{{- end }}`}</span>{'\n\n'}
<span className="c"># ci-runner is headless — no GUI configs</span>{'\n'}
<span className="lime">{`{{- if eq .chezmoi.hostname "ci-runner" }}`}</span>{'\n'}
.config/karabiner/{'\n'}
.config/wezterm/{'\n'}
.hammerspoon/{'\n'}
<span className="lime">{`{{- end }}`}</span>{'\n'}
            </div>
          </div>

          <h2 className="detail-h2 mt-5">Sojourn calls these chezmoi commands · cheatsheet</h2>
          <table className="bzr-table">
            <thead>
              <tr><th>Command</th><th>When</th><th>Notes</th></tr>
            </thead>
            <tbody>
              <tr><td className="mono">chezmoi status</td><td>every refresh tick</td><td className="col-meta">cheap · 32ms · returns one char + path</td></tr>
              <tr><td className="mono">chezmoi diff</td><td>opening Dotfiles</td><td className="col-meta">colorized via PTY-wrap (script -q)</td></tr>
              <tr><td className="mono">chezmoi apply --dry-run -v</td><td>before real apply</td><td className="col-meta">always shown for review · never auto</td></tr>
              <tr><td className="mono">chezmoi managed --include=...</td><td>building file list</td><td className="col-meta">--format=json · indexed</td></tr>
              <tr><td className="mono">chezmoi data --format=json</td><td>templates panel</td><td className="col-meta">cached 5s · invalidated on edit</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </>
);

// ============================================================
// 5) GITLEAKS RULES — custom rules, allowlist, redaction preview
// ============================================================
const GitleaksRulesScreen = () => (
  <>
    <Toolbar eyebrow="HYGIENE / SECRETS / gitleaks 8.30.1 — bundled · re-signed" title="Rules & allowlist">
      <div className="lg-segmented"><div className="active">Rules</div><div>Allowlist</div><div>Redaction</div></div>
      <button className="btn btn-glass"><Icon name="plus" size={11}/> Add rule</button>
      <button className="btn btn-primary"><Icon name="play" size={11}/> Test config on staging</button>
    </Toolbar>
    <div className="content-body">
      <div className="midlist" style={{width: 320}}>
        <div className="ml-header"><span>RULES · 121</span><span className="lime" style={{marginLeft:'auto'}}>+ 4 user</span></div>
        {[
          ['aws-access-key-id',         'builtin','high'],
          ['aws-secret-access-key',     'builtin','high'],
          ['github-pat',                'builtin','high'],
          ['stripe-live-key',           'builtin','high'],
          ['slack-webhook',             'builtin','medium'],
          ['acme-internal-token',       'user',   'high'],
          ['acme-vault-namespace',      'user',   'medium'],
          ['gcp-service-account',       'user',   'high'],
          ['ssh-private-key-blob',      'user',   'high'],
          ['generic-high-entropy',      'builtin','low · gated'],
        ].map((r, i) => (
          <div key={i} className={`ml-row ${i===5?'selected':''}`}>
            <div className="ml-row-icon" style={{
              background: r[1]==='user'?'rgba(198,255,36,0.18)':'rgba(255,255,255,0.06)',
              color: r[1]==='user'?'var(--bzr-lime)':'var(--txt-primary)'
            }}>{r[1]==='user'?'U':'B'}</div>
            <div className="ml-row-body">
              <div className="ml-row-title">{r[0]}</div>
              <div className="ml-row-meta">
                <span>{r[1]}</span>
                <span className="sep">·</span>
                <span className={r[2].startsWith('high')?'warn':''}>{r[2]}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="detail">
        <div className="detail-inner">
          <Eyebrow>USER RULE · ACME-INTERNAL-TOKEN · ENABLED · HIGH SEVERITY</Eyebrow>
          <h1 className="detail-h1" style={{fontSize: 30}}>ACME-INTERNAL-TOKEN</h1>
          <div className="detail-sub">User rule, layered on top of gitleaks builtins via <span className="mono lime">.gitleaks.toml</span> in the user's repo. High severity = 5-second bypass lockout in the push sheet.</div>

          <div className="row mt-4 gap-3" style={{alignItems:'stretch'}}>
            <div className="card flex-1">
              <div className="card-eyebrow">RULE · gitleaks toml</div>
              <div className="code" style={{fontSize: 11.5}}>
[[<span className="lime">rules</span>]]{'\n'}
id          <span className="op">=</span> <span className="s">"acme-internal-token"</span>{'\n'}
description <span className="op">=</span> <span className="s">"ACME internal API tokens (acme_pat_*)"</span>{'\n'}
regex       <span className="op">=</span> <span className="s">{`'''(?i)acme_pat_[a-z0-9]{32,40}'''`}</span>{'\n'}
keywords    <span className="op">=</span> [<span className="s">"acme_pat_"</span>]{'\n'}
severity    <span className="op">=</span> <span className="s">"high"</span>     <span className="c">// → 5s bypass lockout</span>{'\n'}
entropy     <span className="op">=</span> <span className="n">3.5</span>{'\n\n'}
[<span className="lime">rules.allowlist</span>]{'\n'}
description <span className="op">=</span> <span className="s">"docs use a redacted example"</span>{'\n'}
paths       <span className="op">=</span> [<span className="s">{`'''docs/.+\\\\.md$'''`}</span>]{'\n'}
regexes     <span className="op">=</span> [<span className="s">{`'''acme_pat_xxxxxxxx'''`}</span>]{'\n'}
              </div>
              <div className="mono subtle mt-3" style={{fontSize: 10}}>
                COMPILED IN 1.4 MS · MATCHED 0 TIMES IN STAGING (47 FILES, 12 KB)
              </div>
            </div>

            <div className="card" style={{width: 320}}>
              <div className="card-eyebrow">REDACTION PREVIEW · log export</div>
              <div className="code" style={{fontSize: 11}}>
<span className="c">// raw: matches stay in chez-encrypted bundles only</span>{'\n'}
acme_pat_<span className="warn">a8f2k…3lm9z</span>{'\n\n'}
<span className="c">// exported (Diagnostics): replaced before disk write</span>{'\n'}
acme_pat_<span className="lime">[REDACTED:32]</span>{'\n\n'}
<span className="c">// shown in UI: middle-mask, never copyable raw</span>{'\n'}
acme_pat_a8f2…3lm9z{'\n\n'}
<span className="c">// in clipboard: blocked unless user confirms</span>{'\n'}
<span className="warn">⚠ paste from secret findings is held in transient pasteboard</span>{'\n'}
              </div>
            </div>
          </div>

          <h2 className="detail-h2 mt-6">Allowlist · 6 entries · per-path & per-regex</h2>
          <table className="bzr-table">
            <thead>
              <tr><th>Scope</th><th>Pattern</th><th>Reason</th><th>Added</th><th></th></tr>
            </thead>
            <tbody>
              <tr><td className="col-meta">path</td><td className="mono">test/fixtures/**</td><td>known-fake creds in unit tests</td><td className="col-meta">2026-04-12</td><td><span className="badge badge-success">ACTIVE</span></td></tr>
              <tr><td className="col-meta">path</td><td className="mono">docs/**.md</td><td>documentation uses xxxxxxxx examples</td><td className="col-meta">2026-04-12</td><td><span className="badge badge-success">ACTIVE</span></td></tr>
              <tr><td className="col-meta">regex</td><td className="mono">EXAMPLEKEY[0-9]+</td><td>placeholder used by README</td><td className="col-meta">2026-04-15</td><td><span className="badge badge-success">ACTIVE</span></td></tr>
              <tr><td className="col-meta">commit</td><td className="mono">3a2f1c8e</td><td>historical legit-looking constant in a quote</td><td className="col-meta">2026-04-22</td><td><span className="badge badge-tier-c">EXPIRES 7D</span></td></tr>
            </tbody>
          </table>

          <div className="callout mt-5">
            <div className="callout-mark">!</div>
            <div className="callout-body">
              <div className="callout-title">ALLOWLIST IS NEVER A SHRUG</div>
              <div className="callout-text">
                Every entry has a reason and an audit row. Commit-scoped allows expire (default 7 days) so they don't permanently mask new findings on the same commit. The push sheet shows allowed-but-suppressed counts so you can never silently grow the allowlist.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </>
);

window.JobInspectorScreen = JobInspectorScreen;
window.ScheduleInspectorScreen = ScheduleInspectorScreen;
window.AgeKeysScreen = AgeKeysScreen;
window.ChezmoiTemplatesScreen = ChezmoiTemplatesScreen;
window.GitleaksRulesScreen = GitleaksRulesScreen;
