// Power surfaces, part 2 — Authorization, ManagerDetail (Cargo), Backups, DefaultsDiscover, RepoSetup

// ============================================================
// 6) AUTHORIZATION & PERMISSIONS — TCC, FDA, brew sudo flow
// ============================================================
const AuthorizationScreen = () => (
  <>
    <Toolbar eyebrow="APP / PERMISSIONS / TCC · Authorization · FDA" title="Authorization & permissions">
      <div className="lg-segmented"><div className="active">State</div><div>Required by feature</div></div>
      <button className="btn btn-glass"><Icon name="settings" size={11}/> Open System Settings · Privacy</button>
    </Toolbar>
    <div className="content-body">
      <div className="midlist" style={{width: 320}}>
        <div className="ml-header"><span>PERMISSIONS · 6</span></div>
        {[
          ['Full Disk Access',     'granted',  'shield', 'reads ~/Library/Preferences without sandbox'],
          ['Network',              'granted',  'globe',  'git fetch/push, brew API, age recipients'],
          ['Apple Events · iTerm', 'granted',  'terminal','quit-and-relaunch on plist import'],
          ['Apple Events · Dock',  'prompt',   'terminal','plist import for com.apple.dock'],
          ['Authorization · Brew', 'on-demand','key',    'pkg install needs admin · per-call'],
          ['Notifications',        'granted',  'bell',   'job done · gitleaks finding · pull conflict'],
        ].map((r, i) => (
          <div key={i} className={`ml-row ${i===0?'selected':''}`}>
            <div className="ml-row-icon" style={{
              background: r[1]==='granted'?'rgba(63,185,80,0.18)' : r[1]==='prompt'?'rgba(232,163,61,0.20)':'rgba(91,159,255,0.18)',
              color: r[1]==='granted'?'#6ce67c': r[1]==='prompt'?'#ffb84a':'#7fb3ff'
            }}>
              <Icon name={r[2]} size={13}/>
            </div>
            <div className="ml-row-body">
              <div className="ml-row-title">{r[0]}</div>
              <div className="ml-row-meta"><span>{r[1]}</span><span className="sep">·</span><span style={{maxWidth: 160, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap'}}>{r[3]}</span></div>
            </div>
          </div>
        ))}
      </div>

      <div className="detail">
        <div className="detail-inner">
          <Eyebrow>FULL DISK ACCESS · GRANTED 2026-04-09 · TCC.DB</Eyebrow>
          <h1 className="detail-h1" style={{fontSize: 30}}>FDA · THE CANARY.</h1>
          <div className="detail-sub">FDA is the only way Sojourn can reliably read every app's plist without sandbox detours. Bootstrap probes a known TCC-protected path and waits for grant. We never touch <span className="mono">/Library/Application Support/com.apple.TCC</span> directly.</div>

          <div className="row mt-4 gap-3" style={{alignItems:'stretch'}}>
            <div className="card flex-1">
              <div className="card-eyebrow">CANARY PROBE · how we know</div>
              <div className="code">
<span className="c">// FDAProbe.swift — runs on launch + before any plist read</span>{'\n'}
<span className="lime">func</span> probe() <span className="op">-&gt;</span> FDAState {'{'}{'\n'}
  <span className="lime">let</span> path <span className="op">=</span> <span className="s">"~/Library/Mail/V10/MailData/Accounts.plist"</span>{'\n'}
  <span className="lime">let</span> result <span className="op">=</span> Process.run(<span className="s">"/bin/cat"</span>, [path]){'\n'}
  <span className="lime">switch</span> result.exit {'{'}{'\n'}
    <span className="lime">case</span> 0:           <span className="lime">return</span> .granted{'\n'}
    <span className="lime">case</span> 1 <span className="lime">where</span> stderr.contains(<span className="s">"Operation not permitted"</span>):{'\n'}
      <span className="lime">return</span> .denied{'\n'}
    <span className="lime">case</span> 1: <span className="lime">return</span> .pathMissing  <span className="c">// no Mail account · ambiguous</span>{'\n'}
    <span className="lime">default</span>: <span className="lime">return</span> .unknown{'\n'}
  {'}'}{'\n'}
{'}'}
              </div>
              <div className="mono subtle mt-3" style={{fontSize: 10}}>
                ↻ LAST PROBE · 14:23:01 · GRANTED · 11 MS
              </div>
            </div>

            <div className="card" style={{width: 320}}>
              <div className="card-eyebrow">WHAT FDA UNLOCKS</div>
              <div className="col gap-2" style={{fontSize: 12}}>
                <div className="row gap-2"><span className="dot ok"></span><span>Read every app's plist</span></div>
                <div className="row gap-2"><span className="dot ok"></span><span>Watch ~/Library/Preferences for Discover</span></div>
                <div className="row gap-2"><span className="dot ok"></span><span>Read browser-managed defaults</span></div>
                <div className="row gap-2"><span className="dot warn"></span><span>Does not bypass cfprefsd</span></div>
                <div className="row gap-2"><span className="dot warn"></span><span>Does not allow writing other apps' plists</span></div>
              </div>
              <div className="mono subtle mt-4" style={{fontSize: 10}}>
                IF DENIED, PREFERENCES TAB SHOWS A SOFT BANNER &amp; OFFERS TO OPEN SYSTEM SETTINGS · NEVER NAGS.
              </div>
            </div>
          </div>

          <h2 className="detail-h2 mt-6">brew · admin authorization (per-call)</h2>
          <div className="card">
            <div className="card-eyebrow">AUTHORIZATION.FRAMEWORK FLOW</div>
            <div className="code" style={{fontSize: 11.5}}>
<span className="c">// brew.cask installs of .pkg payloads need admin to write /Applications</span>{'\n'}
<span className="c">// Sojourn never stores admin creds. Each install gets one prompt, scoped to one operation.</span>{'\n\n'}
<span className="lime">1.</span> AuthorizationCreate(<span className="s">"system.privilege.admin"</span>) <span className="op">→</span> AuthorizationRef{'\n'}
<span className="lime">2.</span> AuthorizationCopyRights(.interactionAllowed | .extendRights){'\n'}
<span className="lime">3.</span> system shows the macOS-native "Sojourn wants to make changes" sheet · TouchID first{'\n'}
<span className="lime">4.</span> Process.run(<span className="s">"/usr/bin/security"</span>, [<span className="s">"authorize"</span>, ...]){'\n'}
<span className="lime">5.</span> brew.cask runs · sudo step delegated to Authorization · scoped 5 minutes{'\n'}
<span className="lime">6.</span> AuthorizationFree() <span className="op">→</span> handle dropped &lt; 50ms after exit{'\n'}
            </div>
          </div>

          <div className="callout mt-5">
            <div className="callout-mark">!</div>
            <div className="callout-body">
              <div className="callout-title">WE NEVER TOUCH TCC.DB</div>
              <div className="callout-text">Tampering with <span className="mono">~/Library/Application Support/com.apple.TCC/TCC.db</span> trips System Integrity Protection and gets your app blacklisted. Sojourn drives TCC the legitimate way: we trigger the prompt by attempting the protected operation, and we read state by re-trying the canary.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </>
);

// ============================================================
// 7) MANAGER DETAIL — Cargo as the template
// ============================================================
const ManagerDetailScreen = () => (
  <>
    <Toolbar eyebrow="CARRY / PACKAGES / cargo · ~/.cargo/bin · 1.84.0" title="Cargo · 22 packages">
      <div className="lg-segmented"><div className="active">Installed</div><div>Outdated</div><div>Drift</div></div>
      <button className="btn btn-glass"><Icon name="terminal" size={11}/> Open in shell</button>
      <button className="btn btn-primary"><Icon name="check" size={11}/> Upgrade 3 advisory</button>
    </Toolbar>
    <div className="content-body">
      <div className="midlist" style={{width: 280}}>
        <div className="ml-header"><span>22 INSTALLED</span></div>
        {[
          ['cargo-watch', '8.4.1', 'advisory · GHSA-x7pq-9j5q'],
          ['cargo-edit',  '0.12.2', null],
          ['ripgrep',     '14.1.1', 'outdated'],
          ['fd',          '10.2.1', 'outdated'],
          ['eza',         '0.18.24', 'outdated'],
          ['zoxide',      '0.9.6', 'cooldown 4d'],
          ['bottom',      '0.10.2', null],
          ['just',        '1.34.0', null],
          ['tokei',       '12.1.2', null],
          ['hyperfine',   '1.18.0', null],
        ].map((r, i) => (
          <div key={i} className={`ml-row ${i===0?'selected':''}`}>
            <div className="ml-row-icon" style={{fontFamily:'var(--f-mono)', fontSize: 9}}>{r[0].slice(0,2)}</div>
            <div className="ml-row-body">
              <div className="ml-row-title">{r[0]}</div>
              <div className="ml-row-meta">
                <span className="mono" style={{fontSize:10}}>{r[1]}</span>
                {r[2] && <><span className="sep">·</span><span className={r[2].startsWith('advisory')?'warn':''}>{r[2]}</span></>}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="detail">
        <div className="detail-inner">
          <Eyebrow>CARGO-WATCH · 8.4.1 → 8.5.3 · ADVISORY GHSA-X7PQ-9J5Q</Eyebrow>
          <h1 className="detail-h1" style={{fontSize: 30}}>CARGO-WATCH · ADVISORY UPGRADE</h1>
          <div className="detail-sub">Cooldown for tier B is 7 days. This package landed yesterday but has a public security advisory — Sojourn can bypass cooldown and upgrade now.</div>

          <div className="row mt-3 gap-2">
            <span className="badge badge-tier-b">TIER B · cargo</span>
            <span className="badge" style={{background:'rgba(232,163,61,0.20)',color:'#ffb84a'}}>ADVISORY · MEDIUM</span>
            <span className="badge badge-mute">cooldown bypass eligible</span>
            <span className="right">
              <button className="btn btn-ghost"><Icon name="x" size={11}/> Skip this round</button>
              <button className="btn btn-glass"><Icon name="upload" size={11}/> Pin · 8.4.1</button>
              <button className="btn btn-primary"><Icon name="check" size={11}/> Upgrade now (advisory bypass)</button>
            </span>
          </div>

          <h2 className="detail-h2 mt-5">Advisory · OSV / GHSA</h2>
          <div className="card">
            <div className="card-eyebrow">GHSA-X7PQ-9J5Q · cargo-watch</div>
            <div className="col gap-2 mt-2" style={{fontSize: 12.5, color:'var(--txt-secondary)'}}>
              <div className="row"><span className="mono subtle" style={{minWidth:120, fontSize:10}}>SEVERITY</span><span className="warn">MEDIUM (5.4)</span></div>
              <div className="row"><span className="mono subtle" style={{minWidth:120, fontSize:10}}>SUMMARY</span><span>Symlink-following bug in shell-mode causes file watch to escape working tree</span></div>
              <div className="row"><span className="mono subtle" style={{minWidth:120, fontSize:10}}>FIXED IN</span><span className="lime">8.5.0+</span></div>
              <div className="row"><span className="mono subtle" style={{minWidth:120, fontSize:10}}>PUBLISHED</span><span>2026-04-23</span></div>
              <div className="row"><span className="mono subtle" style={{minWidth:120, fontSize:10}}>CACHED</span><span>OSV API · 11 hours ago</span></div>
            </div>
          </div>

          <h2 className="detail-h2 mt-5">Raw mpm output</h2>
          <div className="card">
            <div className="card-eyebrow">$ mpm --table-format json --manager cargo outdated</div>
            <div className="code" style={{fontSize: 11}}>
{`{`}{'\n'}
  <span className="lime">"manager"</span>: <span className="s">"cargo"</span>,{'\n'}
  <span className="lime">"packages"</span>: [{'\n'}
    {`{`} <span className="lime">"name"</span>: <span className="s">"cargo-watch"</span>,{'\n'}
      <span className="lime">"installed"</span>: <span className="s">"8.4.1"</span>, <span className="lime">"latest"</span>: <span className="s">"8.5.3"</span>,{'\n'}
      <span className="lime">"source"</span>: <span className="s">"crates.io"</span>,{'\n'}
      <span className="lime">"advisory"</span>: {`{`} <span className="lime">"id"</span>: <span className="s">"GHSA-x7pq-9j5q"</span>, <span className="lime">"severity"</span>: <span className="s">"medium"</span> {`}`} {`},`}{'\n'}
    {`{`} <span className="lime">"name"</span>: <span className="s">"ripgrep"</span>,{'\n'}
      <span className="lime">"installed"</span>: <span className="s">"14.1.1"</span>, <span className="lime">"latest"</span>: <span className="s">"14.1.4"</span>,{'\n'}
      <span className="lime">"source"</span>: <span className="s">"crates.io"</span> {`},`}{'\n'}
    ...{'\n'}
  ]{'\n'}
{`}`}
            </div>
          </div>

          <div className="row mt-5 gap-3">
            <div className="card flex-1">
              <div className="card-eyebrow">UPGRADE PLAN</div>
              <div className="code" style={{fontSize: 11}}>
<span className="dim">$</span> /Users/zoe/.cargo/bin/cargo install --locked cargo-watch@^8.5.3 --force{'\n'}
<span className="dim">$</span> mpm --manager cargo --ignore-failure upgrade cargo-watch{'\n\n'}
<span className="c">// rolls back if any of:</span>{'\n'}
  - <span className="warn">cargo install</span> fails (compile error){'\n'}
  - new binary at <span className="mono">~/.cargo/bin/cargo-watch</span> reports &lt; 8.5.3 on --version{'\n'}
  - exit ≠ 0 with --ignore-failure honored only for non-fatals{'\n'}
              </div>
            </div>
            <div className="card" style={{width: 280}}>
              <div className="card-eyebrow">PIN BEHAVIOUR · packages.toml</div>
              <div className="code" style={{fontSize: 11}}>
[<span className="lime">cargo</span>]{'\n'}
cargo-watch <span className="op">=</span> <span className="s">"^8.5.3"</span>  <span className="c">// caret</span>{'\n'}
cargo-edit  <span className="op">=</span> <span className="s">"*"</span>       <span className="c">// any</span>{'\n'}
ripgrep     <span className="op">=</span> <span className="s">"=14.1.1"</span> <span className="c">// pinned</span>{'\n'}
              </div>
              <div className="mono subtle mt-3" style={{fontSize: 10}}>
                PIN PROPAGATES TO ALL MACHINES ON NEXT PUSH.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </>
);

// ============================================================
// 8) BACKUPS — every push/pull/apply leaves a tarball
// ============================================================
const BackupsScreen = () => (
  <>
    <Toolbar eyebrow="APP / SAFETY / ~/Library/Application Support/Sojourn/backups" title="Backups">
      <div className="lg-segmented"><div className="active">All</div><div>Push</div><div>Pull</div><div>Apply</div></div>
      <button className="btn btn-glass"><Icon name="trash" size={11}/> GC older than 30d</button>
      <button className="btn btn-glass"><Icon name="upload" size={11}/> Export selected</button>
    </Toolbar>
    <div className="content-body">
      <div className="midlist" style={{width: 340}}>
        <div className="ml-header"><span>BACKUPS · 47 · 184 MB</span></div>
        {[
          ['2026-04-26 14:22:18', 'pull', '3 files restored', '12.4 MB', true],
          ['2026-04-26 14:21:02', 'push', 'pre-push snapshot', '11.8 MB', false],
          ['2026-04-26 09:14:55', 'apply','chezmoi apply', '4.2 MB',  false],
          ['2026-04-25 18:32:11', 'push', 'pre-push snapshot', '11.8 MB', false],
          ['2026-04-24 11:18:40', 'pull', '5 files restored', '11.7 MB', false],
          ['2026-04-23 09:44:12', 'apply','dry-run aborted', '0 MB',  false],
          ['2026-04-22 16:01:55', 'push', 'pre-push snapshot', '11.5 MB', false],
        ].map((r, i) => (
          <div key={i} className={`ml-row ${i===0?'selected':''}`}>
            <div className="ml-row-icon" style={{
              background: r[1]==='pull'?'rgba(91,159,255,0.18)':r[1]==='push'?'rgba(198,255,36,0.18)':'rgba(232,163,61,0.20)',
              color: r[1]==='pull'?'#7fb3ff':r[1]==='push'?'var(--bzr-lime)':'#ffb84a',
              fontFamily:'var(--f-stencil)', fontSize: 9, fontWeight: 800, letterSpacing:'0.06em'
            }}>{r[1].toUpperCase()}</div>
            <div className="ml-row-body">
              <div className="ml-row-title">
                {r[0]} {r[4] && <span className="badge badge-lime" style={{fontSize: 9, padding:'1px 5px', marginLeft: 4}}>RESTORED</span>}
              </div>
              <div className="ml-row-meta">
                <span>{r[2]}</span>
                <span className="sep">·</span>
                <span>{r[3]}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="detail">
        <div className="detail-inner">
          <Eyebrow>BACKUPS / 2026-04-26 14:22:18-PULL · TARBALL · 12.4 MB</Eyebrow>
          <h1 className="detail-h1" style={{fontSize: 30}}>PULL · 14:22 TODAY</h1>
          <div className="detail-sub">3 dotfiles changed and packages.toml drifted. The full pre-pull working tree is preserved — restore the whole snapshot or cherry-pick a single path.</div>

          <div className="row mt-3 gap-2">
            <span className="badge badge-tier-b">restored 14:24:02</span>
            <span className="badge badge-mute">contains 247 paths</span>
            <span className="badge badge-mute">12.4 MB · zstd</span>
            <span className="badge badge-mute">retention · 30d default · 4d remaining</span>
            <span className="right">
              <button className="btn btn-glass"><Icon name="terminal" size={11}/> Show in Finder</button>
              <button className="btn btn-glass"><Icon name="sync" size={11}/> Diff vs current</button>
              <button className="btn btn-primary"><Icon name="rotate-ccw" size={11}/> Restore again</button>
            </span>
          </div>

          <h2 className="detail-h2 mt-5">Tarball contents · top of tree</h2>
          <div className="code" style={{fontSize: 11}}>
backups/2026-04-26-14-22-18-pull/{'\n'}
├── manifest.toml             <span className="c">// op, hashes, who, why</span>{'\n'}
├── packages.toml             <span className="c">// pre-pull · 184 entries</span>{'\n'}
├── dotfiles.tar.zst          <span className="c">// chezmoi source dir snapshot</span>{'\n'}
├── preferences/{'\n'}
│   ├── com.googlecode.iterm2.plist{'\n'}
│   ├── com.apple.dock.plist{'\n'}
│   └── ... 16 more{'\n'}
├── .sojourn/{'\n'}
│   ├── machines/work-mbp.toml{'\n'}
│   └── active.toml{'\n'}
├── git-head.txt              <span className="c">// 3a2f1c..</span>{'\n'}
└── deletions-since.ndjson    <span className="c">// 0 entries</span>{'\n'}
          </div>

          <h2 className="detail-h2 mt-5">manifest.toml · tamper-evident</h2>
          <div className="code" style={{fontSize: 11}}>
[<span className="lime">backup</span>]{'\n'}
op            <span className="op">=</span> <span className="s">"pull"</span>{'\n'}
created_at    <span className="op">=</span> <span className="s">"2026-04-26T14:22:18Z"</span>{'\n'}
machine       <span className="op">=</span> <span className="s">"work-mbp"</span>{'\n'}
sojourn_ver   <span className="op">=</span> <span className="s">"0.1.4 (build 218)"</span>{'\n'}
total_bytes   <span className="op">=</span> <span className="n">12_399_182</span>{'\n'}
tarball_sha256<span className="op">=</span> <span className="s">"d8a1…42ec"</span>  <span className="c">// re-checked on restore</span>{'\n\n'}
[<span className="lime">git</span>]{'\n'}
head_before   <span className="op">=</span> <span className="s">"3a2f1c8"</span>{'\n'}
head_after    <span className="op">=</span> <span className="s">"b94e2af"</span>{'\n'}
fast_forward  <span className="op">=</span> <span className="lime">true</span>{'\n\n'}
[<span className="lime">touched</span>]{'\n'}
dotfiles      <span className="op">=</span> [<span className="s">".zshrc"</span>, <span className="s">".gitconfig"</span>, <span className="s">".tmux.conf"</span>]{'\n'}
preferences   <span className="op">=</span> [<span className="s">"com.googlecode.iterm2"</span>]{'\n'}
packages      <span className="op">=</span> [<span className="s">"brew/+ghostty"</span>]{'\n'}
          </div>

          <div className="callout mt-5">
            <div className="callout-mark">!</div>
            <div className="callout-body">
              <div className="callout-title">RESTORE IS A NEW BACKUP</div>
              <div className="callout-text">When you click Restore, Sojourn first snapshots the *current* working tree (so you can undo the undo) and only then untar's the chosen backup. Both tarballs link to the same op-id in <span className="mono">deletions.db</span>.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </>
);

// ============================================================
// 9) DEFAULTS DISCOVER — record session, watch ~/Library/Preferences
// ============================================================
const DefaultsDiscoverScreen = () => (
  <>
    <Toolbar eyebrow="CARRY / PREFERENCES / DISCOVER · cfprefsd watcher" title="Discover preference changes">
      <div className="lg-segmented"><div>Tracked</div><div className="active">Discover</div></div>
      <button className="btn btn-glass"><Icon name="x" size={11}/> Stop session</button>
      <button className="btn btn-primary"><Icon name="check" size={11}/> Track 3 selected</button>
    </Toolbar>
    <div className="content-body">
      <div className="midlist" style={{width: 320}}>
        <div className="ml-header"><span>SESSION · 00:14:32</span><span className="lime" style={{marginLeft:'auto'}}>● REC</span></div>
        {[
          ['com.apple.dock',           14, 'recently changed', true],
          ['com.googlecode.iterm2',     7, 'recently changed', true],
          ['com.tinyspeck.slackmacgap', 4, 'recently changed', false],
          ['com.spotify.client',        3, 'recently changed', false],
          ['com.figma.Desktop',         2, 'recently changed', false],
          ['org.mozilla.firefox',       1, 'recently changed', false],
        ].map((r, i) => (
          <div key={i} className={`ml-row ${i===0?'selected':''}`}>
            <div className="ml-row-icon" style={{
              background: r[3]?'rgba(198,255,36,0.18)':'rgba(255,255,255,0.06)',
              color: r[3]?'var(--bzr-lime)':'var(--txt-primary)'
            }}>{r[3]?'✓':'+'}</div>
            <div className="ml-row-body">
              <div className="ml-row-title">{r[0]}</div>
              <div className="ml-row-meta">
                <span>{r[1]} keys changed</span>
                <span className="sep">·</span>
                <span>{r[2]}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="detail">
        <div className="detail-inner">
          <Eyebrow>RECORDING SINCE 14:09 · 31 PLIST WRITES SEEN · 6 DOMAINS NEW</Eyebrow>
          <h1 className="detail-h1" style={{fontSize: 30}}>DISCOVER MODE</h1>
          <div className="detail-sub">A live <span className="mono">DispatchSourceFileSystemObject</span> on <span className="mono">~/Library/Preferences/</span>. While recording, change a setting in any app — Sojourn shows you exactly which keys cfprefsd updated, and offers to track them.</div>

          <div className="row mt-4 gap-3" style={{alignItems:'stretch'}}>
            <div className="card flex-1">
              <div className="card-eyebrow">com.apple.dock · 14 KEYS CHANGED</div>
              <div className="code" style={{fontSize: 11.5}}>
<span className="c"># diff between 14:09:01 and 14:24:18 · plutil -convert xml1 + diff</span>{'\n\n'}
<span className="lime">~ orientation</span>           <span className="op">=</span> <span className="s">"left"</span>      <span className="c">(was "bottom")</span>{'\n'}
<span className="lime">~ tilesize</span>              <span className="op">=</span> <span className="n">42</span>           <span className="c">(was 48)</span>{'\n'}
<span className="lime">~ magnification</span>         <span className="op">=</span> <span className="lime">false</span>        <span className="c">(was true)</span>{'\n'}
<span className="lime">+ persistent-apps[6]</span>    <span className="op">=</span> <span className="s">"Linear.app"</span>{'\n'}
<span className="lime">+ persistent-apps[7]</span>    <span className="op">=</span> <span className="s">"Notion.app"</span>{'\n'}
<span className="warn">~ mod-count</span>             <span className="op">=</span> <span className="n">1182</span>         <span className="c">(noisy · won't track)</span>{'\n'}
<span className="warn">~ mod-state</span>             <span className="op">=</span> <span className="s">"&lt;binary&gt;"</span>   <span className="c">(noisy · won't track)</span>{'\n'}
              </div>
              <div className="mono subtle mt-3" style={{fontSize: 10}}>
                NOISY KEYS DETECTED VIA HEURISTIC · 3+ FLIPS/SECOND OR &gt; 64 KB BINARY · STRIPPED FROM EXPORT.
              </div>
            </div>

            <div className="card" style={{width: 320}}>
              <div className="card-eyebrow">PREVIEW EXPORT · com.apple.dock</div>
              <div className="code" style={{fontSize: 11}}>
<span className="c">// dock.plist (xml1) · 11 keys after noise filter</span>{'\n'}
<span className="lime">orientation</span>     <span className="op">=</span> <span className="s">"left"</span>{'\n'}
<span className="lime">tilesize</span>        <span className="op">=</span> <span className="n">42</span>{'\n'}
<span className="lime">magnification</span>   <span className="op">=</span> <span className="lime">false</span>{'\n'}
<span className="lime">show-recents</span>    <span className="op">=</span> <span className="warn">false</span>{'\n'}
<span className="lime">autohide</span>        <span className="op">=</span> <span className="lime">true</span>{'\n'}
<span className="lime">autohide-delay</span>  <span className="op">=</span> <span className="n">0</span>{'\n'}
<span className="lime">persistent-apps</span> <span className="op">=</span> [...8]{'\n'}
              </div>
              <div className="row mt-3 gap-2">
                <button className="btn btn-glass" style={{flex:1}}><Icon name="upload" size={11}/> Track domain</button>
                <button className="btn btn-glass" style={{flex:1}}><Icon name="x" size={11}/> Ignore</button>
              </div>
            </div>
          </div>

          <h2 className="detail-h2 mt-6">Quit-and-relaunch plan</h2>
          <table className="bzr-table">
            <thead>
              <tr><th>Domain</th><th>App running?</th><th>Plan</th></tr>
            </thead>
            <tbody>
              <tr><td className="mono">com.apple.dock</td><td className="col-meta">Dock (system)</td><td>killall Dock after import · cfprefsd-safe</td></tr>
              <tr><td className="mono">com.googlecode.iterm2</td><td className="col-meta">running</td><td>AppleScript · "tell iTerm2 to quit" · then defaults import · then relaunch</td></tr>
              <tr><td className="mono">com.tinyspeck.slackmacgap</td><td className="col-meta">running</td><td>AppleScript quit · prompts user if mid-call</td></tr>
            </tbody>
          </table>

          <div className="callout mt-5">
            <div className="callout-mark">!</div>
            <div className="callout-body">
              <div className="callout-title">cfprefsd RACES YOU — QUIT FIRST.</div>
              <div className="callout-text">If a target app is running while Sojourn calls <span className="mono">defaults import</span>, cfprefsd's atomic rename can win and your import is silently lost. Discover honors a per-app "running" flag and asks before quitting.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </>
);

// ============================================================
// 10) REPO SETUP — pick remote, GPG, commit format
// ============================================================
const RepoSetupScreen = () => (
  <>
    <Toolbar eyebrow="APP / SETUP / REMOTE" title="Repo setup">
      <button className="btn btn-glass"><Icon name="terminal" size={11}/> Test connection</button>
      <button className="btn btn-primary"><Icon name="check" size={11}/> Save</button>
    </Toolbar>
    <div className="content-body" style={{display:'block', overflow:'auto'}}>
      <div className="detail">
        <div className="detail-inner" style={{maxWidth: 880}}>
          <Eyebrow>BIZARRE / SOJOURN / V0.1 · GIT REMOTE</Eyebrow>
          <h1 className="detail-h1">YOUR REPO · YOUR REMOTE.</h1>
          <div className="detail-sub">Sojourn doesn't host anything. Point it at any git remote you control — GitHub, GitLab, self-hosted Forgejo, a USB drive, your dev box. Authentication is whatever already works in your shell.</div>

          <h2 className="detail-h2 mt-6">1 · Remote URL</h2>
          <div className="card">
            <div className="row gap-2" style={{alignItems:'center'}}>
              <div className="lg-segmented"><div className="active">SSH</div><div>HTTPS · token</div><div>Path</div></div>
              <span className="right mono subtle" style={{fontSize: 10}}>VALIDATED 14:24:01 · git ls-remote · 230ms</span>
            </div>
            <div className="card" style={{marginTop: 10, padding: '10px 12px', background:'rgba(0,0,0,0.30)'}}>
              <span className="mono lime" style={{fontSize: 13}}>git@github.com:zoekat/my-mac.git</span>
            </div>
            <div className="row mt-3 gap-2" style={{fontSize: 11}}>
              <span className="badge badge-success">SSH key · ~/.ssh/id_ed25519</span>
              <span className="badge badge-success">known_hosts pin · github.com</span>
              <span className="badge badge-mute">private · default branch <span className="lime">main</span></span>
              <span className="badge badge-mute">last fetch · 22m ago</span>
            </div>
          </div>

          <h2 className="detail-h2 mt-6">2 · Identity for commits</h2>
          <div className="row gap-3" style={{alignItems:'stretch'}}>
            <div className="card flex-1">
              <div className="card-eyebrow">USER · per-machine override allowed</div>
              <div className="code">
[<span className="lime">user</span>]{'\n'}
name  <span className="op">=</span> <span className="s">"Zoe Katsumi"</span>{'\n'}
email <span className="op">=</span> <span className="s">"zoe@bizarre.app"</span>  <span className="c">// also work-mbp specific</span>{'\n'}
              </div>
            </div>
            <div className="card flex-1">
              <div className="card-eyebrow">SIGNING · GPG / SSH / 1Password agent</div>
              <div className="col gap-2" style={{fontSize: 12}}>
                <div className="row gap-2"><span className="dot ok"></span><span>SSH signing · key ED25519 256 bit · 1Password agent</span></div>
                <div className="row gap-2"><span className="dot ok"></span><span>commit.gpgsign · true</span></div>
                <div className="row gap-2"><span className="dot ok"></span><span>tag.gpgsign · true</span></div>
                <div className="row gap-2"><span className="dot ok"></span><span>SSH allowed-signers committed to repo</span></div>
              </div>
              <div className="mono subtle mt-3" style={{fontSize: 10}}>
                FAILED SIGNATURES BLOCK PUSH · NEVER AUTO-FALLBACK TO UNSIGNED.
              </div>
            </div>
          </div>

          <h2 className="detail-h2 mt-6">3 · Commit message template</h2>
          <div className="row gap-3" style={{alignItems:'stretch'}}>
            <div className="card flex-1">
              <div className="card-eyebrow">TEMPLATE · used by every Sojourn-authored commit</div>
              <div className="code">
[<span className="lime">subject</span>] {'{'}{`{ op }`}{'}'} on {'{'}{`{ machine }`}{'}'}{'\n\n'}
[<span className="lime">body</span>]{'\n'}
{'{'}{`{ summary }`}{'}'}{'\n\n'}
{'{'}{`{ table_of_changes }`}{'}'}{'\n\n'}
[<span className="lime">trailers</span>]{'\n'}
Sojourn-Op-ID: {'{'}{`{ op_id }`}{'}'}{'\n'}
Sojourn-Backup: {'{'}{`{ backup_path }`}{'}'}{'\n'}
Signed-off-by: {'{'}{`{ user }`}{'}'}{'\n'}
              </div>
            </div>
            <div className="card flex-1" style={{maxWidth: 380}}>
              <div className="card-eyebrow">PREVIEW · what your remote will see</div>
              <div className="code">
[<span className="lime">push</span>] dotfiles+packages on work-mbp{'\n\n'}
3 dotfiles modified, 1 package added.{'\n\n'}
+ brew/ghostty       1.1.2{'\n'}
~ dotfiles/.zshrc    +4 -1{'\n'}
~ dotfiles/.tmux.conf+2 -2{'\n'}
~ dotfiles/.gitconfig+1 -0{'\n\n'}
Sojourn-Op-ID: 9f2c-04261422{'\n'}
Sojourn-Backup: backups/…14-22-18-push{'\n'}
Signed-off-by: Zoe Katsumi &lt;zoe@bizarre.app&gt;{'\n'}
              </div>
            </div>
          </div>

          <h2 className="detail-h2 mt-6">4 · Branch &amp; conflict policy</h2>
          <div className="row gap-3" style={{alignItems:'stretch'}}>
            <div className="card flex-1">
              <div className="card-eyebrow">BRANCH</div>
              <div className="col gap-2" style={{fontSize: 12}}>
                <div className="row"><span style={{flex:1}}>Default branch</span><span className="mono lime">main</span></div>
                <div className="row"><span style={{flex:1}}>Push strategy</span><span className="mono">linear-only · fast-forward</span></div>
                <div className="row"><span style={{flex:1}}>Force push</span><span className="mono warn">never</span></div>
                <div className="row"><span style={{flex:1}}>Auto-rebase on pull</span><span className="mono">false · prefer interactive</span></div>
              </div>
            </div>
            <div className="card flex-1">
              <div className="card-eyebrow">CONFLICTS · all six shapes</div>
              <div className="col gap-2" style={{fontSize: 12}}>
                <div className="row gap-2"><span className="dot warn"></span><span>both edited file · 3-way merge UI</span></div>
                <div className="row gap-2"><span className="dot warn"></span><span>both added file · pick one or both with rename</span></div>
                <div className="row gap-2"><span className="dot warn"></span><span>delete vs edit · keep deleted or restore</span></div>
                <div className="row gap-2"><span className="dot warn"></span><span>plist key collision · per-key 3-way</span></div>
                <div className="row gap-2"><span className="dot warn"></span><span>packages.toml drift · per-manager merge</span></div>
                <div className="row gap-2"><span className="dot warn"></span><span>writer claim · only one machine writes at a time</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </>
);

window.AuthorizationScreen = AuthorizationScreen;
window.ManagerDetailScreen = ManagerDetailScreen;
window.BackupsScreen = BackupsScreen;
window.DefaultsDiscoverScreen = DefaultsDiscoverScreen;
window.RepoSetupScreen = RepoSetupScreen;
