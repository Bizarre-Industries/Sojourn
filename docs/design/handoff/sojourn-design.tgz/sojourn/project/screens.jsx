// Screens — full Sojourn UI

// === OVERVIEW ===
const OverviewScreen = ({ openSheet }) => (
  <>
    <Toolbar eyebrow="SOJOURN / OVERVIEW / WORK-MBP" title="Carry your Mac.">
      <button className="btn btn-glass" onClick={()=>openSheet('pull')}>
        <Icon name="pull" size={11}/> Pull
      </button>
      <button className="btn btn-primary" onClick={()=>openSheet('push')}>
        <Icon name="push" size={11}/> Push 3 changes
      </button>
    </Toolbar>
    <div className="detail">
      <div className="detail-inner">
        <Eyebrow>BIZARRE / SOJOURN / V0.1 / APR 2026</Eyebrow>
        <h1 className="detail-h1">YOU ALREADY KNOW.<br/>CATCH THE STARS.</h1>
        <div className="detail-sub">
          184 packages, 32 dotfiles, 18 preference domains pinned to your remote. Every push is git-backed and rollback-safe. Every pull snapshots first. The bench is honest.
        </div>

        <div className="stat-strip">
          <div className="stat">
            <div className="stat-label">Last Push</div>
            <div className="stat-value">2<span className="unit">hours</span></div>
            <div className="stat-meta">a3f9c2e · clean</div>
          </div>
          <div className="stat">
            <div className="stat-label">Drift</div>
            <div className="stat-value lime">3<span className="unit">files</span></div>
            <div className="stat-meta">.zshrc · packages.toml · iterm2</div>
          </div>
          <div className="stat">
            <div className="stat-label">Outdated</div>
            <div className="stat-value warn">17<span className="unit">pkgs</span></div>
            <div className="stat-meta">12 in cooldown · 5 ready</div>
          </div>
          <div className="stat">
            <div className="stat-label">Cruft</div>
            <div className="stat-value danger">12<span className="unit">orphans</span></div>
            <div className="stat-meta">2.4GB recoverable</div>
          </div>
        </div>

        <div className="row mt-6 gap-3" style={{alignItems:'stretch'}}>
          <div className="card flex-1">
            <div className="card-eyebrow">RECENT ACTIVITY / HEAD~5</div>
            <div className="col gap-2">
              {[
                ['a3f9c2e', '2h', 'push', 'mpm install ripgrep, fd, eza', 'work-mbp'],
                ['7b1de44', '1d', 'pull', 'sync from personal-mini', 'work-mbp'],
                ['c08fa12', '2d', 'push', 'iterm2 prefs · zshrc edit', 'personal-mini'],
                ['ee31a09', '3d', 'apply', 'chezmoi apply --force after pull', 'work-mbp'],
                ['114b8f0', '4d', 'cleanup', 'trashed 8 dotfile orphans', 'work-mbp'],
              ].map(([sha, t, kind, msg, m]) => (
                <div key={sha} className="row" style={{padding:'4px 0', borderBottom:'0.5px solid var(--hairline-inner)'}}>
                  <span className="mono" style={{fontSize:10, color:'var(--bzr-lime)', width:60}}>{sha}</span>
                  <span className="badge badge-mute" style={{minWidth:60, justifyContent:'center'}}>{kind}</span>
                  <span style={{fontSize:12, flex:1}}>{msg}</span>
                  <span className="mono subtle" style={{fontSize:10}}>{m}</span>
                  <span className="mono subtle" style={{fontSize:10, width:24, textAlign:'right'}}>{t}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="card" style={{width: 280}}>
            <div className="card-eyebrow">SCHEDULER / DAILY 09:00</div>
            <div className="col gap-3">
              <div className="row">
                <span className="dot lime"></span>
                <span style={{fontSize:12, fontWeight:600}}>NSBackgroundActivityScheduler</span>
              </div>
              <div className="mono subtle" style={{fontSize:10}}>NEXT REFRESH IN 6H 14M</div>
              <div className="progress-track"><div className="progress-fill" style={{width:'74%'}}></div></div>
              <div className="tier-row">
                <span className="badge badge-tier-a">A</span>
                <span style={{fontSize:11}}>Mac App Store</span>
                <span className="right mono subtle" style={{fontSize:10}}>0d · auto</span>
              </div>
              <div className="tier-row">
                <span className="badge badge-tier-b">B</span>
                <span style={{fontSize:11}}>brew · cargo</span>
                <span className="right mono subtle" style={{fontSize:10}}>7d · auto</span>
              </div>
              <div className="tier-row">
                <span className="badge badge-tier-d">D</span>
                <span style={{fontSize:11}}>pip · pipx · gem</span>
                <span className="right mono subtle" style={{fontSize:10}}>7d · prompt</span>
              </div>
              <div className="tier-row">
                <span className="badge badge-tier-e">E</span>
                <span style={{fontSize:11}}>npm global</span>
                <span className="right mono subtle" style={{fontSize:10}}>14d · prompt</span>
              </div>
            </div>
          </div>
        </div>

        <div className="callout mt-6">
          <div className="callout-mark">★</div>
          <div className="callout-body">
            <div className="callout-title">CATCH THE STARS</div>
            <div className="callout-text">Every broken prototype is tuition. Hit Push when you're ready — gitleaks scans first, snapshots before, rollback is one click. Do it because you can.</div>
          </div>
        </div>
      </div>
    </div>
  </>
);

// === PACKAGES ===
const PackagesScreen = () => {
  const [selectedMgr, setMgr] = useState('brew');
  const managers = [
    { id: 'brew',     name: 'Homebrew',      pkgs: 87, out: 12, tier: 'B', sub: 'formulae' },
    { id: 'cask',     name: 'Cask',          pkgs: 31, out: 4,  tier: 'C', sub: 'gui apps' },
    { id: 'mas',      name: 'Mac App Store', pkgs: 14, out: 1,  tier: 'A', sub: 'mas-cli' },
    { id: 'cargo',    name: 'Cargo',         pkgs: 22, out: 0,  tier: 'B', sub: 'rust' },
    { id: 'pipx',     name: 'pipx',          pkgs: 11, out: 0,  tier: 'D', sub: 'python tools' },
    { id: 'npm',      name: 'npm (global)',  pkgs: 9,  out: 0,  tier: 'E', sub: 'pnpm n/a' },
    { id: 'gem',      name: 'gem',           pkgs: 6,  out: 0,  tier: 'D', sub: 'ruby' },
    { id: 'composer', name: 'composer',      pkgs: 4,  out: 0,  tier: 'D', sub: 'php' },
  ];
  const outdatedRows = [
    ['ripgrep',     '14.1.1', '14.1.4', 'brew',  'B', 'eligible',  '7d ✓'],
    ['fd',          '10.2.1', '10.3.0', 'brew',  'B', 'eligible',  '8d ✓'],
    ['eza',         '0.18.24','0.19.1', 'brew',  'B', 'eligible',  '12d ✓'],
    ['zoxide',      '0.9.6',  '0.9.8',  'brew',  'B', 'cooldown',  '3d / 7d'],
    ['ghostty',     '1.0.4',  '1.1.2',  'cask',  'C', 'prompt',    '9d · runs script'],
    ['Raycast',     '1.84.5', '1.85.1', 'cask',  'C', 'prompt',    '5d / 7d'],
    ['1Password 7', '7.9.11', '7.10.0', 'mas',   'A', 'auto',      '0d · ready'],
    ['typescript',  '5.4.2',  '5.6.3',  'npm',   'E', 'prompt',    '21d ✓ · advisory'],
    ['mypy',        '1.8.0',  '1.11.2', 'pipx',  'D', 'prompt',    '14d ✓'],
    ['cargo-watch', '8.4.1',  '8.5.3',  'cargo', 'B', 'eligible',  '11d ✓'],
  ];

  return (
    <>
      <Toolbar eyebrow="CARRY / PACKAGES / mpm 6.3.0" title="Packages">
        <div className="lg-segmented">
          <div className="active">All</div><div>Outdated</div><div>Drift</div>
        </div>
        <button className="btn btn-glass"><Icon name="sync" size={11}/> Refresh</button>
        <button className="btn btn-primary"><Icon name="check" size={11}/> Upgrade 5 safe</button>
      </Toolbar>
      <div className="content-body">
        <div className="midlist">
          <div className="ml-header"><span>MANAGERS</span><span style={{marginLeft:'auto'}} className="lime">{managers.length}</span></div>
          {managers.map(m => (
            <div key={m.id}
              className={`ml-row ${selectedMgr===m.id ? 'selected' : ''}`}
              onClick={()=>setMgr(m.id)}>
              <div className="ml-row-icon">{m.id.slice(0,2)}</div>
              <div className="ml-row-body">
                <div className="ml-row-title">
                  {m.name}
                  {m.out > 0 && <span className="dot warn"></span>}
                </div>
                <div className="ml-row-meta">
                  <span>{m.pkgs} pkg</span>
                  <span className="sep">·</span>
                  <span>{m.out > 0 ? `${m.out} outdated` : 'up to date'}</span>
                  <span className="sep">·</span>
                  <span>tier {m.tier}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="detail">
          <div className="detail-inner">
            <Eyebrow>HOMEBREW · /OPT/HOMEBREW/BIN/BREW · 4.4.7</Eyebrow>
            <h1 className="detail-h1" style={{fontSize: 30}}>HOMEBREW · 87 PACKAGES</h1>
            <div className="detail-sub">12 outdated, 5 past cooldown, 7 still aging. Tier B — 7-day default. Advisory bypass active for OSV/GHSA findings.</div>

            <div className="row mt-4 gap-2">
              <span className="badge badge-tier-b">TIER B · 7D AUTO</span>
              <span className="badge badge-mute"><span className="dot ok"></span> JSON API · 7d cache</span>
              <span className="badge badge-mute">5 eligible now</span>
              <span className="right mono subtle" style={{fontSize:10}}>LAST OUTDATED CHECK · 2H AGO</span>
            </div>

            <h2 className="detail-h2 mt-6">Outdated · cross-manager view</h2>
            <table className="bzr-table">
              <thead>
                <tr><th>Package</th><th>Installed</th><th></th><th>Latest</th><th>Mgr</th><th>Tier</th><th>Cooldown</th><th></th></tr>
              </thead>
              <tbody>
                {outdatedRows.map((r, i) => (
                  <tr key={i}>
                    <td className="col-pkg">{r[0]}</td>
                    <td className="col-ver-old">{r[1]}</td>
                    <td className="col-meta">→</td>
                    <td className="col-ver-new">{r[2]}</td>
                    <td className="col-meta">{r[3]}</td>
                    <td><span className={`badge badge-tier-${r[4].toLowerCase()}`}>{r[4]}</span></td>
                    <td className="col-meta">{r[6]}</td>
                    <td>
                      {r[5]==='eligible' && <span className="badge badge-success">READY</span>}
                      {r[5]==='cooldown' && <span className="badge badge-mute">AGING</span>}
                      {r[5]==='prompt'   && <span className="badge badge-tier-c">PROMPT</span>}
                      {r[5]==='auto'     && <span className="badge badge-lime">AUTO</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="row mt-4 gap-3" style={{alignItems:'stretch'}}>
              <div className="card flex-1">
                <div className="card-eyebrow">PER-MACHINE GATING / packages.toml</div>
                <div className="code">
{`[brew]
ripgrep = "*"
fd = "*"
eza = "*"

[brew.only.`}<span className="s">"work-mbp"</span>{`]
docker = "*"
slack = "*"

[brew.exclude.`}<span className="s">"personal-mini"</span>{`]
postgres@16 = "*"`}
                </div>
              </div>
              <div className="card" style={{width: 280}}>
                <div className="card-eyebrow">STREAMING JOB · brew outdated</div>
                <div className="log">
<span className="ts">14:22:01</span> <span className="dim">$</span> brew outdated --json{'\n'}
<span className="ts">14:22:02</span> <span className="dim">→</span> warming JSON API cache{'\n'}
<span className="ts">14:22:04</span> <span className="ok">✓</span> 87 formulae checked{'\n'}
<span className="ts">14:22:04</span> <span className="lime">→</span> 12 outdated{'\n'}
<span className="ts">14:22:05</span> <span className="dim">$</span> mpm --table-format json outdated{'\n'}
<span className="ts">14:22:09</span> <span className="warn">⚠</span> pip: search not implemented{'\n'}
<span className="ts">14:22:11</span> <span className="ok">✓</span> aggregated 8 managers{'\n'}
<span className="ts">14:22:11</span> <span className="lime">━</span> 17 outdated total{'\n'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

// === DOTFILES ===
const DotfilesScreen = () => (
  <>
    <Toolbar eyebrow="CARRY / DOTFILES / chezmoi 2.70.2" title="Dotfiles">
      <div className="lg-segmented">
        <div>Tree</div><div className="active">Diff</div><div>Templates</div>
      </div>
      <button className="btn btn-glass"><Icon name="terminal" size={11}/> chezmoi status</button>
      <button className="btn btn-primary"><Icon name="check" size={11}/> Apply 4 changes</button>
    </Toolbar>
    <div className="content-body">
      <div className="midlist">
        <div className="ml-header"><span>MANAGED · 32</span></div>
        {[
          ['M', '.zshrc',          'modified', '4 lines'],
          ['M', '.gitconfig',      'modified', '1 line'],
          ['A', '.config/nvim/init.lua', 'added', '+47 −0'],
          ['M', '.tmux.conf',      'modified', '2 lines'],
          [' ', '.config/starship.toml', 'clean', null],
          [' ', '.config/wezterm/wezterm.lua', 'clean', null],
          [' ', '.aws/config',     'encrypted', 'age'],
          [' ', '.config/git/ignore', 'clean', null],
          [' ', '.npmrc',          'template', '{{.host}}'],
          [' ', '.config/karabiner/', 'clean', '12 files'],
        ].map((r, i) => (
          <div key={i} className={`ml-row ${i===0?'selected':''}`}>
            <div className="ml-row-icon" style={{
              background: r[0]==='M'?'rgba(232,163,61,0.20)': r[0]==='A'?'rgba(63,185,80,0.20)':'rgba(255,255,255,0.06)',
              color: r[0]==='M'?'#ffb84a':r[0]==='A'?'#6ce67c':'var(--txt-secondary)'
            }}>{r[0].trim() || '·'}</div>
            <div className="ml-row-body">
              <div className="ml-row-title">{r[1]}</div>
              <div className="ml-row-meta">
                <span>{r[2]}</span>
                {r[3] && <><span className="sep">·</span><span>{r[3]}</span></>}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="detail">
        <div className="detail-inner">
          <Eyebrow>~/.ZSHRC · MODIFIED · OWNER ZSH (BREW)</Eyebrow>
          <h1 className="detail-h1" style={{fontSize: 30}}>.ZSHRC</h1>
          <div className="row mt-3 gap-2">
            <span className="badge badge-tier-c">MODIFIED</span>
            <span className="badge badge-mute">SOURCE · dot_zshrc.tmpl</span>
            <span className="badge badge-mute">+4 −1</span>
            <span className="right">
              <button className="btn btn-ghost"><Icon name="x" size={11}/> Discard</button>
              <button className="btn btn-glass"><Icon name="terminal" size={11}/> Open editor</button>
            </span>
          </div>

          <h2 className="detail-h2">Diff · working tree → source</h2>
          <div className="diff">
            <div className="diff-hunk mono">@@ -42,7 +42,10 @@ # path additions</div>
            <div className="diff-line diff-ctx mono"><span className="ln">42</span>export PATH="$HOME/.local/bin:$PATH"</div>
            <div className="diff-line diff-ctx mono"><span className="ln">43</span>export PATH="$HOME/.cargo/bin:$PATH"</div>
            <div className="diff-line diff-rem mono"><span className="ln">44</span>export EDITOR=vim</div>
            <div className="diff-line diff-add mono"><span className="ln">44</span>export EDITOR=nvim</div>
            <div className="diff-line diff-add mono"><span className="ln">45</span>export VISUAL=nvim</div>
            <div className="diff-line diff-add mono"><span className="ln">46</span>{`{{- if eq .chezmoi.hostname "work-mbp" }}`}</div>
            <div className="diff-line diff-add mono"><span className="ln">47</span>export AWS_PROFILE=acme-prod</div>
            <div className="diff-line diff-add mono"><span className="ln">48</span>{`{{- end }}`}</div>
            <div className="diff-line diff-ctx mono"><span className="ln">49</span></div>
            <div className="diff-line diff-ctx mono"><span className="ln">50</span># aliases</div>
          </div>

          <div className="row mt-4 gap-3">
            <div className="card flex-1">
              <div className="card-eyebrow">PER-MACHINE OVERRIDE</div>
              <div className="col gap-2" style={{fontSize:12}}>
                <div className="row"><span style={{flex:1}}>Apply this block on:</span></div>
                <div className="row gap-2">
                  <span className="badge badge-lime">work-mbp</span>
                  <span className="badge badge-mute">+ personal-mini</span>
                  <span className="badge badge-mute">+ ci-runner</span>
                </div>
                <div className="mono subtle mt-2" style={{fontSize:10}}>
                  EXPANDS TO: <span className="lime">{`{{ if eq .chezmoi.hostname "work-mbp" }}…{{ end }}`}</span>
                </div>
              </div>
            </div>
            <div className="card" style={{width: 240}}>
              <div className="card-eyebrow">OWNERSHIP REGISTRY</div>
              <div className="col gap-2" style={{fontSize:12}}>
                <div className="row gap-2"><span className="dot ok"></span><span>tool · zsh</span></div>
                <div className="row gap-2"><span className="dot ok"></span><span>source · brew</span></div>
                <div className="row gap-2"><span className="dot ok"></span><span>installed</span></div>
                <div className="mono subtle" style={{fontSize:10}}>FROM data/dotfile_owners.toml</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </>
);

// === PREFERENCES ===
const PreferencesScreen = () => (
  <>
    <Toolbar eyebrow="CARRY / PREFERENCES / defaults · plutil" title="App preferences">
      <div className="lg-segmented"><div className="active">Tracked</div><div>Discover</div></div>
      <button className="btn btn-glass"><Icon name="plus" size={11}/> Add domain</button>
      <button className="btn btn-primary"><Icon name="upload" size={11}/> Export 18 domains</button>
    </Toolbar>
    <div className="content-body">
      <div className="midlist">
        <div className="ml-header"><span>DOMAINS · 18</span></div>
        {[
          ['iTerm2',          'com.googlecode.iterm2',     'unsandboxed', 'M', 'XML'],
          ['Dock',            'com.apple.dock',            'unsandboxed', 'M', 'XML'],
          ['Finder',          'com.apple.finder',          'unsandboxed', ' ', 'XML'],
          ['Raycast',         'com.raycast.macos',         'unsandboxed', ' ', 'XML'],
          ['Rectangle',       'com.knollsoft.Rectangle',   'unsandboxed', ' ', 'XML'],
          ['Karabiner',       'org.pqrs.Karabiner-Elements', 'app-supp',  'M', 'JSON'],
          ['1Password 7',     'com.agilebits.onepassword4','sandboxed',  ' ', 'FDA'],
          ['Safari',          'com.apple.Safari',          'sandboxed',  ' ', 'FDA'],
          ['TextEdit',        'com.apple.TextEdit',        'unsandboxed', ' ', 'XML'],
          ['Terminal',        'com.apple.Terminal',        'unsandboxed', ' ', 'XML'],
        ].map((r, i) => (
          <div key={i} className={`ml-row ${i===0?'selected':''}`}>
            <div className="ml-row-icon" style={{
              background: r[3]==='M' ? 'rgba(232,163,61,0.20)' : 'rgba(255,255,255,0.06)',
              color: r[3]==='M' ? '#ffb84a' : 'var(--txt-secondary)'
            }}>{r[0].slice(0,2)}</div>
            <div className="ml-row-body">
              <div className="ml-row-title">{r[0]}</div>
              <div className="ml-row-meta mono" style={{fontSize:10}}>
                <span>{r[1]}</span>
              </div>
            </div>
            {r[2]==='sandboxed' && <Icon name="lock" size={11} style={{color:'var(--bzr-warn)'}}/>}
          </div>
        ))}
      </div>

      <div className="detail">
        <div className="detail-inner">
          <Eyebrow>com.googlecode.iterm2 · UNSANDBOXED · LAYER 1</Eyebrow>
          <h1 className="detail-h1" style={{fontSize: 30}}>iTerm2</h1>
          <div className="row mt-3 gap-2">
            <span className="badge badge-success">UNSANDBOXED · NO FDA</span>
            <span className="badge badge-tier-c">MODIFIED</span>
            <span className="badge badge-mute">XML · 47KB</span>
            <span className="badge badge-mute">214 KEYS</span>
          </div>
          <div className="detail-sub mt-3">
            Round-tripped through cfprefsd via <span className="mono lime">defaults export</span> + <span className="mono lime">defaults import</span>. Stored as XML so git diffs are legible. iTerm2 will be quit-and-relaunched on import.
          </div>

          <h2 className="detail-h2 mt-6">Plist diff (since last export)</h2>
          <div className="code">
<span className="c">// 7 keys changed since 2026-04-26 14:22</span>{'\n\n'}
{`PrefsCustomFolder            `}<span className="op">=</span> <span className="s">"~/.config/iterm2"</span>{'\n'}
<span className="lime">+ NewBookmarks[0].Working Directory</span> <span className="op">=</span> <span className="s">"~/code/sojourn"</span>{'\n'}
<span className="lime">+ NewBookmarks[0].Custom Window Title</span> <span className="op">=</span> <span className="s">"sojourn ✦"</span>{'\n'}
<span className="lime">~ Normal Font</span>                <span className="op">=</span> <span className="s">"JetBrainsMono-Regular 13"</span>{'\n'}
<span className="warn">~ Cursor Type</span>                <span className="op">=</span> <span className="n">2</span> <span className="c">(was 1)</span>{'\n'}
<span className="warn">~ Use Bold Font</span>              <span className="op">=</span> <span className="n">1</span> <span className="c">(was 0)</span>{'\n'}
<span className="lime">+ Window Style</span>               <span className="op">=</span> <span className="n">2</span> <span className="c">(no titlebar)</span>{'\n'}
<span className="err">− Theme Path</span>                 <span className="op">=</span> <span className="s">"~/Downloads/old-theme.json"</span>
          </div>

          <div className="callout callout-warn mt-6">
            <div className="callout-mark">!</div>
            <div className="callout-body">
              <div className="callout-title">QUIT-AND-RELAUNCH ON IMPORT</div>
              <div className="callout-text">
                cfprefsd rewrites plists via atomic rename. If iTerm2 is running when Sojourn calls <span className="mono">defaults import</span>, your in-flight changes win. Sojourn will AppleScript-quit it on apply, write the plist, then relaunch.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </>
);

// === HISTORY ===
const HistoryScreen = () => (
  <>
    <Toolbar eyebrow="SYNC / HISTORY / git log --pretty" title="History">
      <div className="lg-segmented">
        <div className="active">Commits</div><div>Snapshots</div><div>Conflicts</div>
      </div>
      <button className="btn btn-glass"><Icon name="branch" size={11}/> origin/main</button>
    </Toolbar>
    <div className="detail">
      <div className="detail-inner">
        <Eyebrow>WORK-MBP ↔ origin · git@github.com:you/my-mac.git</Eyebrow>
        <h1 className="detail-h1" style={{fontSize: 30}}>47 COMMITS · 12 SNAPSHOTS</h1>
        <div className="detail-sub">Pre-op tarballs retained 30 days. Every push is gitleaks-scanned. Every pull writes a snapshot before touching the working tree. Roll back without leaving the app.</div>

        <div className="card mt-6" style={{padding: 0}}>
          <div className="row" style={{padding: '12px 16px', borderBottom: '0.5px solid var(--hairline)'}}>
            <div className="card-eyebrow" style={{margin: 0}}>TIMELINE · HEAD ← origin/main</div>
            <span className="right mono subtle" style={{fontSize:10}}>RETENTION · 30D</span>
          </div>
          <div style={{position: 'relative', padding: '12px 16px 16px'}}>
            <div style={{position: 'absolute', left: 30, top: 24, bottom: 24, width: 1, background: 'var(--hairline-strong)'}}></div>
            {[
              ['a3f9c2e', '2h ago', 'PUSH', 'mpm install ripgrep, fd, eza', 'work-mbp', '+24 −2', null, 'lime'],
              ['7b1de44', '1d ago', 'PULL', 'sync from personal-mini · 6 changes', 'work-mbp', '+183 −47', 'snap_2026-04-27T08-12.tgz', 'lime'],
              ['c08fa12', '2d ago', 'PUSH', 'iterm2 prefs · zshrc edit', 'personal-mini', '+12 −4', null, null],
              ['ee31a09', '3d ago', 'APPLY', 'chezmoi apply --force after pull', 'work-mbp', '4 files', 'snap_2026-04-25T19-02.tgz', null],
              ['114b8f0', '4d ago', 'CLEAN', 'trashed 8 dotfile orphans', 'work-mbp', '−2.4GB', 'deletions.db row#341', null],
              ['82de019', '5d ago', 'CONFLICT', 'resolved · keep local .zshrc', 'work-mbp', null, null, 'warn'],
              ['44ab821', '6d ago', 'PUSH', 'cargo update + Raycast prefs', 'personal-mini', '+9 −9', null, null],
            ].map((r, i) => (
              <div key={i} className="row" style={{padding: '10px 0', position: 'relative', alignItems: 'flex-start'}}>
                <div style={{
                  width: 13, height: 13, borderRadius: '50%',
                  background: r[7]==='lime' ? 'var(--bzr-lime)' : r[7]==='warn' ? 'var(--bzr-warn)' : 'var(--bzr-void-3)',
                  marginLeft: 9,
                  boxShadow: r[7]==='lime' ? '0 0 8px var(--bzr-lime), 0 0 0 3px var(--bzr-void)' : '0 0 0 3px var(--bzr-void)',
                  border: '1px solid ' + (r[7]==='lime' ? 'var(--bzr-lime)' : r[7]==='warn' ? 'var(--bzr-warn)' : 'var(--hairline-strong)'),
                  marginTop: 2, flexShrink: 0,
                }}></div>
                <div style={{marginLeft: 14, flex: 1}}>
                  <div className="row gap-2">
                    <span className="mono lime" style={{fontSize: 11, fontWeight: 600}}>{r[0]}</span>
                    <span className={`badge ${r[2]==='CONFLICT'?'badge-tier-c':r[2]==='PUSH'?'badge-lime':'badge-mute'}`}>{r[2]}</span>
                    <span style={{fontSize: 12, fontWeight: 600}}>{r[3]}</span>
                    <span className="right mono subtle" style={{fontSize: 10}}>{r[1]}</span>
                  </div>
                  <div className="row gap-2 mt-2 mono" style={{fontSize: 10, color: 'var(--txt-tertiary)'}}>
                    <span><Icon name="laptop" size={10}/> {r[4]}</span>
                    {r[5] && <><span className="sep">·</span><span>{r[5]}</span></>}
                    {r[6] && <><span className="sep">·</span><span className="lime"><Icon name="snapshot" size={10}/> {r[6]}</span></>}
                    <span className="right">
                      <button className="btn btn-ghost" style={{padding: '0 6px', fontSize: 10}}>↶ Roll back</button>
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </>
);

// === MACHINES ===
const MachinesScreen = () => (
  <>
    <Toolbar eyebrow="SYNC / MACHINES / .sojourn/machines/*.toml" title="Machines">
      <button className="btn btn-glass"><Icon name="plus" size={11}/> Onboard new</button>
    </Toolbar>
    <div className="detail">
      <div className="detail-inner">
        <Eyebrow>3 MACHINES · 1 ACTIVE WRITER · COOPERATIVE LOCK</Eyebrow>
        <h1 className="detail-h1" style={{fontSize: 30}}>YOUR FLEET</h1>
        <div className="detail-sub">One active writer at a time. Pull before push. The lock is a hint git doesn't enforce — it catches the 95% case of a forgotten pull. Per-machine overrides via <span className="mono lime">{`{{ if eq .chezmoi.hostname "..." }}`}</span> are generated by the form.</div>

        <div className="row mt-6 gap-3" style={{flexWrap:'wrap'}}>
          {[
            { name: 'work-mbp',       host: 'mbp16-acme.local',     model: 'MacBook Pro 16" · M3 Max', os: '14.5 Sonoma', last: '2h ago', writer: true,  pkgs: 184, role: 'PRIMARY' },
            { name: 'personal-mini',  host: 'mini-home.local',      model: 'Mac mini · M4',           os: '15.1 Sequoia', last: '2d ago', writer: false, pkgs: 142, role: 'PERSONAL' },
            { name: 'ci-runner',      host: 'gh-runner-arm-04',     model: 'M2 in a closet',          os: '14.2 Sonoma', last: '6h ago', writer: false, pkgs: 67,  role: 'EPHEMERAL' },
          ].map(m => (
            <div key={m.name} className="card" style={{flex: '1 1 320px', minWidth: 320, padding: 0, overflow: 'hidden'}}>
              <div style={{
                padding: '14px 16px',
                background: m.writer ? 'rgba(198,255,36,0.10)' : 'rgba(255,255,255,0.02)',
                borderBottom: '0.5px solid ' + (m.writer ? 'rgba(198,255,36,0.30)' : 'var(--hairline)')
              }}>
                <div className="row">
                  <span className={`dot ${m.writer ? 'lime' : 'ok'}`}></span>
                  <span style={{fontFamily: 'var(--f-stencil)', fontSize: 18, fontWeight: 800, letterSpacing: '0.04em'}}>{m.name.toUpperCase()}</span>
                  <span className="right mono subtle" style={{fontSize: 9, letterSpacing: '0.16em'}}>{m.role}</span>
                </div>
                <div className="mono subtle mt-2" style={{fontSize: 10}}>{m.host}</div>
              </div>
              <div style={{padding: '14px 16px'}}>
                <div className="col gap-2" style={{fontSize: 12}}>
                  <div className="row"><span className="subtle" style={{width: 80}}>Model</span><span>{m.model}</span></div>
                  <div className="row"><span className="subtle" style={{width: 80}}>OS</span><span>{m.os}</span></div>
                  <div className="row"><span className="subtle" style={{width: 80}}>Packages</span><span className="mono lime">{m.pkgs}</span></div>
                  <div className="row"><span className="subtle" style={{width: 80}}>Last sync</span><span>{m.last}</span></div>
                  <div className="row mt-2"><span className="subtle" style={{width: 80}}>Writer</span>
                    {m.writer
                      ? <span className="badge badge-lime"><Icon name="lock" size={9}/> ACTIVE</span>
                      : <span className="badge badge-mute">Take lock</span>}
                  </div>
                </div>
                <div className="mt-4 row gap-2">
                  <button className="btn btn-glass flex-1"><Icon name="terminal" size={11}/> Open in iTerm</button>
                  {m.writer && <button className="btn btn-ghost"><Icon name="settings" size={11}/></button>}
                </div>
              </div>
            </div>
          ))}
        </div>

        <h2 className="detail-h2 mt-8">Repo · <span className="mono lime" style={{fontSize: 13}}>git@github.com:you/my-mac.git</span></h2>
        <div className="card">
          <div className="code">
<span className="c">my-mac/</span>{'\n'}
{`├── packages.toml                 `}<span className="c">// mpm backup output</span>{'\n'}
{`├── dotfiles/                     `}<span className="c">// chezmoi source dir</span>{'\n'}
{`│   ├── dot_zshrc.tmpl`}{'\n'}
{`│   ├── dot_gitconfig.tmpl`}{'\n'}
{`│   └── private_dot_ssh/encrypted_id_ed25519.age`}{'\n'}
{`├── preferences/                  `}<span className="c">// XML plist per domain</span>{'\n'}
{`│   ├── com.googlecode.iterm2.plist`}{'\n'}
{`│   └── com.apple.dock.plist`}{'\n'}
{`└── .sojourn/`}{'\n'}
{`    ├── machines/work-mbp.toml`}{'\n'}
{`    ├── `}<span className="lime">active.toml</span>{`               `}<span className="c">// writer = "work-mbp"</span>{'\n'}
{`    ├── version.toml`}{'\n'}
{`    └── backups/                  `}<span className="c">// pre-op snapshots, 30d</span>
          </div>
        </div>
      </div>
    </div>
  </>
);

// === CLEANUP ===
const CleanupScreen = () => (
  <>
    <Toolbar eyebrow="HYGIENE / CLEANUP / no auto-delete · trash always" title="Cleanup">
      <div className="lg-segmented"><div className="active">Dotfiles</div><div>~/Library</div><div>Caches</div></div>
      <button className="btn btn-danger"><Icon name="trash" size={11}/> Move 4 to Trash</button>
    </Toolbar>
    <div className="detail">
      <div className="detail-inner">
        <Eyebrow>HYGIENE / DOTFILE ORPHANS / RECONCILED AGAINST TOOL INVENTORY</Eyebrow>
        <h1 className="detail-h1" style={{fontSize: 30}}>12 ORPHANS · 2.4GB</h1>
        <div className="detail-sub">Reconciled against <span className="mono lime">brew list</span>, <span className="mono lime">pipx list</span>, <span className="mono lime">$PATH</span> probes, and <span className="mono lime">data/dotfile_owners.toml</span>. Shell history grep, last-used xattrs, and parent-dir mtime gate the call. Never auto-delete. Always Trash.</div>

        <div className="callout callout-danger mt-6">
          <div className="callout-mark">!</div>
          <div className="callout-body">
            <div className="callout-title">APFS atime is not trustworthy</div>
            <div className="callout-text">Default mount is non-strict atime. Quick Look ticks it. Spotlight ticks it. We use it as a tiebreaker only. Read the docs if you care.</div>
          </div>
        </div>

        <h2 className="detail-h2 mt-6">Orphan candidates</h2>
        <table className="bzr-table">
          <thead>
            <tr><th></th><th>Path</th><th>Size</th><th>Owner (missing)</th><th>Class</th><th>Last touched</th><th>Action</th></tr>
          </thead>
          <tbody>
            <tr>
              <td><input type="checkbox" defaultChecked/></td>
              <td className="col-pkg">~/.rbenv/</td>
              <td className="col-meta">412 MB</td>
              <td className="col-meta">rbenv (brew · uninstalled 2025-12-04)</td>
              <td><span className="badge badge-success">SAFE</span></td>
              <td className="col-meta">142 days</td>
              <td><span className="badge badge-mute">TRASH</span></td>
            </tr>
            <tr>
              <td><input type="checkbox" defaultChecked/></td>
              <td className="col-pkg">~/.nvm/</td>
              <td className="col-meta">1.1 GB</td>
              <td className="col-meta">nvm (curl · uninstalled)</td>
              <td><span className="badge badge-success">SAFE</span></td>
              <td className="col-meta">98 days</td>
              <td><span className="badge badge-mute">TRASH</span></td>
            </tr>
            <tr>
              <td><input type="checkbox" defaultChecked/></td>
              <td className="col-pkg">~/.config/old-fish/</td>
              <td className="col-meta">8.4 MB</td>
              <td className="col-meta">fish shell (not in brew · zsh active)</td>
              <td><span className="badge badge-tier-c">REVIEW</span></td>
              <td className="col-meta">211 days</td>
              <td><span className="badge badge-mute">TRASH</span></td>
            </tr>
            <tr>
              <td><input type="checkbox" defaultChecked/></td>
              <td className="col-pkg">~/Library/Application Support/Atom/</td>
              <td className="col-meta">887 MB</td>
              <td className="col-meta">com.github.atom (no bundle ID found)</td>
              <td><span className="badge badge-tier-c">REVIEW</span></td>
              <td className="col-meta">3 years</td>
              <td><span className="badge badge-mute">TRASH</span></td>
            </tr>
            <tr>
              <td><input type="checkbox"/></td>
              <td className="col-pkg">~/.docker/</td>
              <td className="col-meta">3.2 MB</td>
              <td className="col-meta">Docker (cask · still installed)</td>
              <td><span className="badge badge-mute">KEEP</span></td>
              <td className="col-meta">2 days</td>
              <td className="col-meta">—</td>
            </tr>
            <tr>
              <td><input type="checkbox"/></td>
              <td className="col-pkg">~/.zsh_sessions/</td>
              <td className="col-meta">21 MB</td>
              <td className="col-meta">zsh (system · active)</td>
              <td><span className="badge badge-tier-e">RISKY</span></td>
              <td className="col-meta">2 hours</td>
              <td className="col-meta">—</td>
            </tr>
            <tr>
              <td><input type="checkbox"/></td>
              <td className="col-pkg">~/Library/LaunchAgents/com.heroku.cli.plist</td>
              <td className="col-meta">2 KB</td>
              <td className="col-meta">heroku (brew · uninstalled)</td>
              <td><span className="badge badge-tier-e">RISKY</span></td>
              <td className="col-meta">62 days</td>
              <td className="col-meta">prompt</td>
            </tr>
          </tbody>
        </table>

        <div className="mono subtle mt-4" style={{fontSize: 10}}>
          ↻ DELETIONS LOGGED TO ~/Library/Application Support/Sojourn/deletions.db · 10 MOST RECENT UNDOABLE
        </div>
      </div>
    </div>
  </>
);

// === SETTINGS ===
const SettingsScreen = () => (
  <>
    <Toolbar eyebrow="APP / SETTINGS / persisted in App Support" title="Settings"/>
    <div className="detail">
      <div className="detail-inner" style={{maxWidth: 760}}>
        <Eyebrow>SOJOURN / V0.1 / GPL-3.0-OR-LATER</Eyebrow>

        <h2 className="detail-h2 mt-3">Schedule</h2>
        <div className="card">
          <div className="row" style={{padding: '4px 0'}}>
            <div style={{flex:1}}>
              <div style={{fontSize: 13, fontWeight: 600}}>Daily refresh</div>
              <div className="subtle mt-2" style={{fontSize: 11}}>NSBackgroundActivityScheduler · respects App Nap, thermal, AC-only</div>
            </div>
            <div className="toggle on"></div>
          </div>
          <div style={{height: 0.5, background: 'var(--hairline)', margin: '12px 0'}}></div>
          <div className="row" style={{padding: '4px 0'}}>
            <div style={{flex:1}}>
              <div style={{fontSize: 13, fontWeight: 600}}>Background LaunchAgent (continue when quit)</div>
              <div className="subtle mt-2" style={{fontSize: 11}}>SMAppService.agent · opt-in · v2 deferred for some users</div>
            </div>
            <div className="toggle"></div>
          </div>
        </div>

        <h2 className="detail-h2 mt-6">Cooldown</h2>
        <div className="card">
          {[
            ['A · Mac App Store', 0, 'auto'],
            ['B · Homebrew formulae · Cargo', 7, 'auto'],
            ['C · Casks · pinned project deps', 7, 'prompt'],
            ['D · Global pip · pipx · gem', 7, 'prompt'],
            ['E · Global npm', 14, 'never silent'],
          ].map((t, i) => (
            <div key={i} className="row" style={{padding: '6px 0', borderBottom: i<4 ? '0.5px dashed var(--hairline)' : 'none'}}>
              <span className={`badge badge-tier-${'abcde'[i]}`}>{'abcde'[i].toUpperCase()}</span>
              <span style={{fontSize: 12, flex: 1, marginLeft: 8}}>{t[0]}</span>
              <input className="input mono" defaultValue={t[1]} style={{width: 64, textAlign: 'center'}}/>
              <span className="subtle mono" style={{fontSize: 10, width: 100, textAlign: 'right'}}>days · {t[2]}</span>
            </div>
          ))}
          <div className="callout callout-warn mt-4">
            <div className="callout-mark">!</div>
            <div className="callout-body">
              <div className="callout-title">XZ-CLASS THREATS NOT BLOCKED</div>
              <div className="callout-text">Multi-year maintainer infiltration (CVE-2024-3094) doesn't show up on a 7-day window. Cooldown blocks short-exposure attacks: Shai-Hulud, axios 1.14.1, Solana web3.js. Don't pretend otherwise.</div>
            </div>
          </div>
        </div>

        <h2 className="detail-h2 mt-6">Tool locations</h2>
        <div className="card mono" style={{fontSize: 11}}>
          <div className="row" style={{padding: '5px 0', borderBottom: '0.5px dashed var(--hairline)'}}>
            <span style={{flex: 1}}>brew</span>
            <span className="lime">/opt/homebrew/bin/brew</span>
            <span className="subtle" style={{marginLeft: 14, fontSize: 10}}>4.4.7</span>
          </div>
          <div className="row" style={{padding: '5px 0', borderBottom: '0.5px dashed var(--hairline)'}}>
            <span style={{flex: 1}}>mpm</span>
            <span className="lime">/opt/homebrew/bin/mpm</span>
            <span className="subtle" style={{marginLeft: 14, fontSize: 10}}>6.3.0</span>
          </div>
          <div className="row" style={{padding: '5px 0', borderBottom: '0.5px dashed var(--hairline)'}}>
            <span style={{flex: 1}}>chezmoi</span>
            <span className="lime">/opt/homebrew/bin/chezmoi</span>
            <span className="subtle" style={{marginLeft: 14, fontSize: 10}}>2.70.2</span>
          </div>
          <div className="row" style={{padding: '5px 0', borderBottom: '0.5px dashed var(--hairline)'}}>
            <span style={{flex: 1}}>git</span>
            <span className="lime">/usr/bin/git</span>
            <span className="subtle" style={{marginLeft: 14, fontSize: 10}}>2.42 (xcode)</span>
          </div>
          <div className="row" style={{padding: '5px 0', borderBottom: '0.5px dashed var(--hairline)'}}>
            <span style={{flex: 1}}>gitleaks</span>
            <span className="lime">…/Sojourn.app/Contents/Resources/bin/gitleaks</span>
            <span className="subtle" style={{marginLeft: 14, fontSize: 10}}>8.30.1 · bundled</span>
          </div>
          <div className="row" style={{padding: '5px 0'}}>
            <span style={{flex: 1}}>age</span>
            <span className="lime">…/Sojourn.app/Contents/Resources/bin/age</span>
            <span className="subtle" style={{marginLeft: 14, fontSize: 10}}>1.2.0 · bundled</span>
          </div>
        </div>

        <h2 className="detail-h2 mt-6">Diagnostics</h2>
        <div className="card row gap-3">
          <div style={{flex: 1}}>
            <div style={{fontSize: 13, fontWeight: 600}}>Export diagnostics bundle</div>
            <div className="subtle mt-2" style={{fontSize: 11}}>Last 24h of OSLog · redacted via gitleaks patterns · AppStore.history snapshot</div>
          </div>
          <button className="btn btn-glass"><Icon name="download" size={11}/> Export</button>
        </div>
      </div>
    </div>
  </>
);

// === SECRETS ===
const SecretsScreen = () => (
  <>
    <Toolbar eyebrow="HYGIENE / SECRETS / gitleaks 8.30.1 · pre-commit" title="Secret scan"/>
    <div className="detail">
      <div className="detail-inner">
        <Eyebrow>BUNDLED · MIT · re-signed with --options=runtime</Eyebrow>
        <h1 className="detail-h1" style={{fontSize: 30}}>NO LIVE FINDINGS.</h1>
        <div className="detail-sub">Last scan ran on push <span className="mono lime">a3f9c2e</span>. Two false positives suppressed via repo allowlist. High-confidence provider keys (AWS, GitHub PAT, OpenAI, Stripe) cannot be bypassed for 5s — you read the warning.</div>

        <div className="stat-strip mt-6">
          <div className="stat">
            <div className="stat-label">Last scan</div>
            <div className="stat-value">2<span className="unit">hours</span></div>
            <div className="stat-meta">a3f9c2e · pre-commit</div>
          </div>
          <div className="stat">
            <div className="stat-label">Findings</div>
            <div className="stat-value lime">0</div>
            <div className="stat-meta">since last push</div>
          </div>
          <div className="stat">
            <div className="stat-label">Allowlisted</div>
            <div className="stat-value">2</div>
            <div className="stat-meta">test fixtures · repo-scoped</div>
          </div>
          <div className="stat">
            <div className="stat-label">Rules</div>
            <div className="stat-value">142</div>
            <div className="stat-meta">.gitleaks.toml · bundled</div>
          </div>
        </div>

        <h2 className="detail-h2 mt-6">Last scan output</h2>
        <div className="log" style={{maxHeight: 220}}>
<span className="ts">14:21:58</span> <span className="dim">$</span> gitleaks dir --staged --no-git --report-format json{'\n'}
<span className="ts">14:21:58</span> <span className="lime">→</span> scanning 47 staged files (4.2 MB){'\n'}
<span className="ts">14:21:59</span> <span className="ok">✓</span> rule set: 142 patterns loaded from .gitleaks.toml{'\n'}
<span className="ts">14:22:00</span> <span className="ok">✓</span> dotfiles/dot_zshrc.tmpl    clean{'\n'}
<span className="ts">14:22:00</span> <span className="ok">✓</span> dotfiles/dot_gitconfig.tmpl clean{'\n'}
<span className="ts">14:22:01</span> <span className="warn">⚠</span> packages.toml:42  generic-api-key  → ALLOWLISTED (repo){'\n'}
<span className="ts">14:22:01</span> <span className="ok">✓</span> 47 files scanned, 0 findings, 2 allowlisted{'\n'}
<span className="ts">14:22:01</span> <span className="lime">━</span> commit allowed. proceeding to push.{'\n'}
        </div>
      </div>
    </div>
  </>
);

window.OverviewScreen = OverviewScreen;
window.PackagesScreen = PackagesScreen;
window.DotfilesScreen = DotfilesScreen;
window.PreferencesScreen = PreferencesScreen;
window.HistoryScreen = HistoryScreen;
window.MachinesScreen = MachinesScreen;
window.CleanupScreen = CleanupScreen;
window.SettingsScreen = SettingsScreen;
window.SecretsScreen = SecretsScreen;
