// Sojourn logo — inline SVGs, two variants:
//
//   <SojournLogo variant="app" size={64}/>     — full-color squircle app icon (lime square, void S)
//   <SojournLogo variant="mark" size={14}/>    — monochrome stencil glyph (uses currentColor)
//   <SojournLogo variant="wordmark" height={20}/> — mark + "SOJOURN" stencil text
//
// The mark itself: a stencil "S" carved out of a square frame. Two horizontal stencil cuts
// keep the curve readable at 14px (menu bar size) while the squared terminals echo the rest of
// the type system. Negative space inside the S forms a "path between two points" — the carry
// metaphor without resorting to a suitcase.

const SojournMark = ({ size = 64, color = 'currentColor', strokeOnly = false }) => (
  <svg width={size} height={size} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* outer square frame */}
    <rect x="6" y="6" width="52" height="52" rx="3" stroke={color} strokeWidth="3" fill="none"/>
    {/* inner stencil S - drawn as one filled path with two stencil bridges that knock out via even-odd */}
    {!strokeOnly && (
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        fill={color}
        d="
          M16 18
          L16 31
          L40 31
          L40 36
          L16 36
          L16 49
          L48 49
          L48 36
          L24 36
          L24 31
          L48 31
          L48 18
          Z
          M20 22
          L44 22
          L44 27
          L20 27
          Z
          M20 40
          L44 40
          L44 45
          L20 45
          Z
        "
      />
    )}
    {/* two stencil bridges — hard horizontal cuts that give the S its industrial bite */}
    <rect x="6" y="29" width="52" height="2" fill={color} opacity={strokeOnly ? 1 : 0}/>
    <rect x="6" y="38" width="52" height="2" fill={color} opacity={strokeOnly ? 1 : 0}/>
  </svg>
);

// App-icon variant: a lime squircle with the void mark inside.
// Sized 64×64 by default; render at any size.
const SojournAppIcon = ({ size = 64 }) => (
  <svg width={size} height={size} viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="sj-bg" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
        <stop offset="0" stopColor="#D4FF55"/>
        <stop offset="1" stopColor="#C6FF24"/>
      </linearGradient>
      <linearGradient id="sj-shine" x1="0" y1="0" x2="0" y2="64" gradientUnits="userSpaceOnUse">
        <stop offset="0" stopColor="#FFFFFF" stopOpacity="0.32"/>
        <stop offset="0.5" stopColor="#FFFFFF" stopOpacity="0"/>
      </linearGradient>
    </defs>
    {/* macOS squircle (~13/64 corner radius gives the right "Big Sur" feel) */}
    <path d="M14 1h36c7.18 0 13 5.82 13 13v36c0 7.18-5.82 13-13 13H14C6.82 63 1 57.18 1 50V14C1 6.82 6.82 1 14 1z" fill="url(#sj-bg)"/>
    {/* glass shine */}
    <path d="M14 1h36c7.18 0 13 5.82 13 13v8c0 0-15-5-31-5S1 22 1 22v-8C1 6.82 6.82 1 14 1z" fill="url(#sj-shine)"/>
    {/* mark in void */}
    <g transform="translate(2, 2) scale(0.9375)">
      <rect x="6" y="6" width="52" height="52" rx="3" stroke="#0E0E0E" strokeWidth="3" fill="none"/>
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        fill="#0E0E0E"
        d="M16 18L16 31L40 31L40 36L16 36L16 49L48 49L48 36L24 36L24 31L48 31L48 18ZM20 22L44 22L44 27L20 27ZM20 40L44 40L44 45L20 45Z"
      />
    </g>
    {/* outer 1px border for definition */}
    <path d="M14 1h36c7.18 0 13 5.82 13 13v36c0 7.18-5.82 13-13 13H14C6.82 63 1 57.18 1 50V14C1 6.82 6.82 1 14 1z" fill="none" stroke="rgba(0,0,0,0.18)" strokeWidth="0.7"/>
  </svg>
);

// Wordmark: mark + "SOJOURN" stencil text, baseline-aligned.
const SojournWordmark = ({ height = 20, color = 'currentColor' }) => {
  const markSize = height;
  return (
    <span style={{display:'inline-flex', alignItems:'center', gap: Math.round(height * 0.32), color, lineHeight: 1}}>
      <SojournMark size={markSize} color={color}/>
      <span style={{
        fontFamily: 'var(--f-stencil), Impact, sans-serif',
        fontWeight: 800,
        fontSize: Math.round(height * 0.95),
        letterSpacing: '0.06em',
        textTransform: 'uppercase',
      }}>SOJOURN</span>
    </span>
  );
};

const SojournLogo = ({ variant = 'mark', size, height, color, strokeOnly }) => {
  if (variant === 'app')      return <SojournAppIcon size={size || 64}/>;
  if (variant === 'wordmark') return <SojournWordmark height={height || 20} color={color}/>;
  return <SojournMark size={size || 24} color={color || 'currentColor'} strokeOnly={strokeOnly}/>;
};

window.SojournLogo = SojournLogo;
window.SojournMark = SojournMark;
window.SojournAppIcon = SojournAppIcon;
window.SojournWordmark = SojournWordmark;
