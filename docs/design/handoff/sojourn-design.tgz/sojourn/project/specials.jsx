// Specialty screens — Bootstrap, Push sheet, Conflict resolution, Menu bar

// === BOOTSTRAP (first-run wizard, full window) ===
const BootstrapScreen = () => (
  <div style={{flex:1, display:'flex', flexDirection:'column', overflow:'hidden'}}>
    <div className="titlebar">
      <div className="traffic"><span className="red"></span><span className="yellow"></span><span className="green"></span></div>
      <div className="titlebar-title"><SojournMark size={13} color="var(--bzr-lime)"/> Sojourn · First Run</div>
    </div>
    <div style={{flex:1, display:'flex', alignItems:'stretch', overflow:'auto'}}>
      <div style={{width:280, padding:'32px 24px', borderRight:'0.5px solid var(--hairline)', background:'rgba(20,20,22,0.30)'}}>
        <Eyebrow>BIZARRE / SOJOURN / FIRST RUN</Eyebrow>
        <div style={{fontFamily:'var(--f-stencil)', fontWeight:800, fontSize:42, lineHeight:0.92, marginTop:14, letterSpacing:'0.02em'}}>
          YOU<br/>ALREADY<br/><span className="lime">KNOW.</span>
        </div>
        <div className="subtle mt-4" style={{fontSize:12, lineHeight:1.5}}>
          Three commands separate "fresh Mac" from "your Mac." Sojourn handles two automatically and prompts you for the third. One Authorization dialog. Then we get out of your way.
        </div>
        <div className="mt-6">
          {[
            ['1', 'PROBE',     'done'],
            ['2', 'CONSENT',   'done'],
            ['3', 'XCODE CLT', 'active'],
            ['4', 'HOMEBREW',  'pending'],
            ['5', 'mpm',       'pending'],
            ['6', 'chezmoi',   'pending'],
            ['7', 'READY',     'pending'],
          ].map(s => (
            <div key={s[0]} className="row" style={{padding:'8px 0', borderBottom:'0.5px solid var(--hairline-inner)'}}>
              <span className="mono" style={{
                width:24, height:24, borderRadius:4,
                background: s[2]==='done'?'var(--bzr-lime)':s[2]==='active'?'rgba(198,255,36,0.20)':'rgba(255,255,255,0.04)',
                color: s[2]==='done'?'var(--bzr-void)':s[2]==='active'?'var(--bzr-lime)':'var(--txt-tertiary)',
                display:'inline-flex', alignItems:'center', justifyContent:'center',
                fontWeight:700, fontSize:11,
                boxShadow: s[2]==='active'?'inset 0 0 0 0.5px var(--bzr-lime)':'none',
              }}>{s[2]==='done'?'✓':s[0]}</span>
              <span style={{fontFamily:'var(--f-stencil)', fontSize:14, fontWeight:700, letterSpacing:'0.05em', flex:1, marginLeft:6, color: s[2]==='pending'?'var(--txt-tertiary)':'var(--txt-primary)'}}>{s[1]}</span>
              {s[2]==='active' && <span className="dot lime" style={{animation:'pulse 1.5s infinite'}}></span>}
            </div>
          ))}
        </div>
      </div>
      <div style={{flex:1, padding:'32px 36px', overflow:'auto'}}>
        <Eyebrow>STEP 3 / 7 · INSTALLING</Eyebrow>
        <h1 className="detail-h1" style={{fontSize:36, marginTop:6}}>XCODE COMMAND LINE TOOLS</h1>
        <div className="detail-sub">macOS sheet is open. We're polling <span className="mono lime">xcode-select -p</span> every 5s and watching for exit code 0. Minimize to the menu bar — Sojourn will keep going.</div>

        <div className="row mt-4 gap-2">
          <span className="badge badge-lime"><span className="dot lime"></span> RUNNING</span>
          <span className="badge badge-mute">~3 min remaining</span>
          <span className="right mono subtle" style={{fontSize:10}}>elapsed 1:42</span>
        </div>

        <div className="progress-track mt-4" style={{height:6}}>
          <div className="progress-fill" style={{width:'42%'}}></div>
        </div>

        <h2 className="detail-h2 mt-6">Probe results</h2>
        <table className="bzr-table">
          <thead><tr><th>Tool</th><th>Path</th><th>Version</th><th>Status</th></tr></thead>
          <tbody>
            <tr><td className="col-pkg">git</td><td className="col-meta">/usr/bin/git</td><td className="col-ver-new">2.42.1</td><td><span className="badge badge-success">FOUND</span></td></tr>
            <tr><td className="col-pkg">xcode-select</td><td className="col-meta">/usr/bin/xcode-select</td><td className="col-meta">—</td><td><span className="badge badge-tier-c">INSTALLING</span></td></tr>
            <tr><td className="col-pkg">brew</td><td className="col-meta">—</td><td className="col-meta">—</td><td><span className="badge badge-mute">PENDING</span></td></tr>
            <tr><td className="col-pkg">mpm</td><td className="col-meta">—</td><td className="col-meta">—</td><td><span className="badge badge-mute">PENDING</span></td></tr>
            <tr><td className="col-pkg">chezmoi</td><td className="col-meta">—</td><td className="col-meta">—</td><td><span className="badge badge-mute">PENDING</span></td></tr>
            <tr><td className="col-pkg">gitleaks</td><td className="col-meta">…/Resources/bin/gitleaks</td><td className="col-ver-new">8.30.1</td><td><span className="badge badge-lime">BUNDLED</span></td></tr>
            <tr><td className="col-pkg">age</td><td className="col-meta">…/Resources/bin/age</td><td className="col-ver-new">1.2.0</td><td><span className="badge badge-lime">BUNDLED</span></td></tr>
          </tbody>
        </table>

        <h2 className="detail-h2 mt-6">Live log</h2>
        <div className="log">
<span className="ts">14:18:01</span> <span className="dim">$</span> /usr/bin/xcode-select -p{'\n'}
<span className="ts">14:18:01</span> <span className="warn">⚠</span> exit 2 · CLT not installed{'\n'}
<span className="ts">14:18:02</span> <span className="dim">$</span> /usr/bin/xcode-select --install{'\n'}
<span className="ts">14:18:03</span> <span className="lime">→</span> system sheet presented to user{'\n'}
<span className="ts">14:18:08</span> <span className="ok">✓</span> user accepted license{'\n'}
<span className="ts">14:18:12</span> <span className="dim">→</span> downloading Command Line Tools (Sonoma 14.5){'\n'}
<span className="ts">14:19:33</span> <span className="dim">→</span> 142 MB / 327 MB · 43%{'\n'}
<span className="ts">14:19:43</span> <span className="dim">→</span> 167 MB / 327 MB · 51%{'\n'}
<span className="ts">14:19:43</span> <span className="dim">→</span> polling xcode-select -p every 5s...{'\n'}
        </div>

        <div className="callout mt-6">
          <div className="callout-mark">★</div>
          <div className="callout-body">
            <div className="callout-title">NO CURL | BASH HERE</div>
            <div className="callout-text">Homebrew goes in via the signed .pkg. One native Authorization dialog. No sudo ticket games. The bench is honest.</div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

// === PUSH SHEET ===
const PushSheet = ({ onClose }) => (
  <div className="sheet">
    <div className="sheet-head">
      <Eyebrow>SYNC / PUSH / WORK-MBP → origin/main</Eyebrow>
      <h2 className="stencil" style={{fontSize:24, fontWeight:800, marginTop:6, letterSpacing:'0.04em'}}>READY TO PUSH 3 CHANGES</h2>
      <div className="subtle mt-2" style={{fontSize:12}}>gitleaks scanned · pre-op tarball at <span className="mono lime">.sojourn/backups/2026-04-28T14-30-pre-push.tgz</span></div>
    </div>
    <div className="sheet-body">
      <h2 className="detail-h2" style={{margin:'0 0 10px', fontSize:14}}>Changes</h2>
      <div className="card" style={{padding:0}}>
        {[
          ['M', 'packages.toml',                              '+3 −0', 'mpm', 'ripgrep, fd, eza added'],
          ['M', 'dotfiles/dot_zshrc.tmpl',                    '+4 −1', 'chezmoi', 'EDITOR=nvim · per-machine block'],
          ['M', 'preferences/com.googlecode.iterm2.plist',    '+7 −1', 'defaults', 'JetBrainsMono · cursor type'],
        ].map((r,i)=>(
          <div key={i} className="row" style={{padding:'10px 14px', borderBottom: i<2 ? '0.5px solid var(--hairline-inner)':'none'}}>
            <span className="ml-row-icon" style={{width:24, height:24, fontSize:11, background:'rgba(232,163,61,0.20)', color:'#ffb84a'}}>M</span>
            <div style={{flex:1}}>
              <div className="mono" style={{fontSize:12, fontWeight:600}}>{r[1]}</div>
              <div className="mono subtle mt-2" style={{fontSize:10}}>{r[3]} · {r[4]}</div>
            </div>
            <span className="mono lime" style={{fontSize:11}}>{r[2]}</span>
          </div>
        ))}
      </div>

      <h2 className="detail-h2" style={{fontSize:14, marginTop:18}}>Pre-flight</h2>
      <div className="card" style={{padding:'10px 14px'}}>
        {[
          ['gitleaks dir --staged', 'ok', '0 findings · 2 allowlisted'],
          ['snapshot tarball',      'ok', 'backups/2026-04-28T14-30-pre-push.tgz'],
          ['fetch origin/main',     'ok', 'no diverge · fast-forward ready'],
          ['active.toml writer',    'ok', 'work-mbp holds lock'],
        ].map((r,i)=>(
          <div key={i} className="row" style={{padding:'5px 0'}}>
            <span className="dot ok"></span>
            <span className="mono" style={{fontSize:11, flex:1, marginLeft:6}}>{r[0]}</span>
            <span className="subtle mono" style={{fontSize:10}}>{r[2]}</span>
          </div>
        ))}
      </div>

      <h2 className="detail-h2" style={{fontSize:14, marginTop:18}}>Commit message</h2>
      <input className="input" defaultValue="install ripgrep, fd, eza · iterm2 prefs"/>
      <div className="mono subtle mt-2" style={{fontSize:10}}>SIGNED-OFF-BY · GIT-CREDENTIAL-OSXKEYCHAIN · GH:YOU</div>
    </div>
    <div className="sheet-foot">
      <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
      <button className="btn btn-glass">Save draft</button>
      <button className="btn btn-primary"><Icon name="push" size={11}/> Push to origin/main</button>
    </div>
  </div>
);

// === PULL SHEET (with conflict) ===
const PullSheet = ({ onClose }) => (
  <div className="sheet">
    <div className="sheet-head">
      <Eyebrow>SYNC / PULL / origin/main → WORK-MBP</Eyebrow>
      <h2 className="stencil" style={{fontSize:24, fontWeight:800, marginTop:6, letterSpacing:'0.04em', color:'var(--bzr-warn)'}}>1 CONFLICT · RESOLVE TO CONTINUE</h2>
      <div className="subtle mt-2" style={{fontSize:12}}>Inbound 6 changes from <span className="mono lime">personal-mini</span>. The .zshrc was edited on both Macs since the common ancestor. Pick a side.</div>
    </div>
    <div className="sheet-body">
      <div className="callout callout-warn">
        <div className="callout-mark">!</div>
        <div className="callout-body">
          <div className="callout-title">CONFLICT · TEXT EDIT</div>
          <div className="callout-text">dotfiles/dot_zshrc.tmpl edited on both Macs. We can't safely auto-merge templated dotfiles. Choose Keep local, Keep remote, or open the manual editor.</div>
        </div>
      </div>

      <h2 className="detail-h2" style={{fontSize:14, marginTop:14}}>Three-way diff · dot_zshrc.tmpl</h2>
      <div className="row gap-2">
        <div style={{flex:1}}>
          <div className="card-eyebrow">LOCAL · work-mbp · 2h ago</div>
          <div className="diff" style={{fontSize:10}}>
            <div className="diff-line diff-ctx mono"><span className="ln">44</span>export EDITOR=nvim</div>
            <div className="diff-line diff-add mono"><span className="ln">45</span>export VISUAL=nvim</div>
            <div className="diff-line diff-add mono"><span className="ln">46</span>{'{{- if eq .chezmoi.hostname "work-mbp" }}'}</div>
            <div className="diff-line diff-add mono"><span className="ln">47</span>export AWS_PROFILE=acme-prod</div>
            <div className="diff-line diff-add mono"><span className="ln">48</span>{'{{- end }}'}</div>
          </div>
        </div>
        <div style={{flex:1}}>
          <div className="card-eyebrow">REMOTE · personal-mini · 2d ago</div>
          <div className="diff" style={{fontSize:10}}>
            <div className="diff-line diff-ctx mono"><span className="ln">44</span>export EDITOR=nvim</div>
            <div className="diff-line diff-add mono"><span className="ln">45</span>export PAGER=bat</div>
            <div className="diff-line diff-add mono"><span className="ln">46</span>alias g=git</div>
            <div className="diff-line diff-add mono"><span className="ln">47</span>alias k=kubectl</div>
          </div>
        </div>
      </div>

      <div className="row gap-2 mt-4">
        <button className="btn btn-glass flex-1"><Icon name="laptop" size={11}/> Keep local</button>
        <button className="btn btn-glass flex-1"><Icon name="download" size={11}/> Keep remote</button>
        <button className="btn btn-primary flex-1"><Icon name="terminal" size={11}/> Manual merge</button>
      </div>

      <h2 className="detail-h2" style={{fontSize:14, marginTop:18}}>Other inbound changes (clean)</h2>
      <div className="card" style={{padding:0}}>
        {[
          ['+', 'packages.toml',     '+2 −0',  'cargo: ripgrep-all, du-dust'],
          ['M', 'dotfiles/.tmux.conf', '+12 −3', 'mouse mode + new prefix'],
          ['+', 'preferences/com.raycast.macos.plist', '+89 −0', 'fresh export'],
          ['M', '.sojourn/machines/personal-mini.toml', '+1 −1', 'last_push timestamp'],
          ['M', '.sojourn/active.toml', '+1 −1', 'writer = "personal-mini" → "work-mbp"'],
        ].map((r,i)=>(
          <div key={i} className="row" style={{padding:'7px 14px', borderBottom: i<4 ? '0.5px solid var(--hairline-inner)':'none'}}>
            <span className="ml-row-icon" style={{width:20, height:20, fontSize:10,
              background: r[0]==='+' ? 'rgba(63,185,80,0.20)':'rgba(232,163,61,0.20)',
              color: r[0]==='+' ? '#6ce67c':'#ffb84a'}}>{r[0]}</span>
            <div className="mono" style={{fontSize:11, flex:1}}>{r[1]}</div>
            <span className="subtle mono" style={{fontSize:10}}>{r[3]}</span>
            <span className="mono lime" style={{fontSize:11, marginLeft:14}}>{r[2]}</span>
          </div>
        ))}
      </div>
    </div>
    <div className="sheet-foot">
      <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
      <button className="btn btn-glass">Stash local & pull</button>
      <button className="btn btn-primary" style={{opacity:0.5}}><Icon name="pull" size={11}/> Apply (resolve first)</button>
    </div>
  </div>
);

// === MENU BAR EXTRA ===
const MenuBarExtra = () => (
  <div className="menubar-extra">
    <div style={{padding:'14px 16px 10px', borderBottom:'0.5px solid var(--hairline)'}}>
      <div className="row">
        <SojournMark size={16} color="var(--bzr-lime)"/>
        <span style={{fontFamily:'var(--f-stencil)', fontWeight:800, fontSize:14, letterSpacing:'0.05em'}}>SOJOURN</span>
        <span className="right">
          <span className="badge badge-lime" style={{fontSize:8}}><span className="dot lime"></span> ACTIVE</span>
        </span>
      </div>
      <div className="mono subtle mt-2" style={{fontSize:9}}>WORK-MBP · WRITER · ↑ a3f9c2e · 2h AGO</div>
    </div>

    <div style={{padding:'10px 16px', borderBottom:'0.5px solid var(--hairline)'}}>
      <div className="row">
        <span className="card-eyebrow" style={{margin:0}}>RUNNING JOBS · 1</span>
      </div>
      <div className="row mt-2 gap-2">
        <span className="dot lime" style={{animation:'pulse 1.5s infinite'}}></span>
        <span style={{fontSize:12, fontWeight:600}}>brew outdated</span>
        <span className="right mono subtle" style={{fontSize:10}}>00:14</span>
      </div>
      <div className="progress-track mt-2"><div className="progress-fill" style={{width:'68%'}}></div></div>
    </div>

    <div style={{padding:'10px 8px'}}>
      {[
        ['push',     'Push 3 changes',          'a3f9c2e+', 'lime'],
        ['pull',     'Pull · check origin',     null,       null],
        ['sync',     'Refresh outdated',        '6h since', null],
        ['branch',   'Take writer lock',        'held',     null],
      ].map(([icon, label, meta, hl]) => (
        <div key={label} className="row" style={{
          padding:'7px 10px', borderRadius:6, cursor:'pointer',
          background: hl ? 'rgba(198,255,36,0.10)' : 'transparent'
        }}>
          <Icon name={icon} size={13} style={{color: hl ? 'var(--bzr-lime)' : 'var(--txt-secondary)'}}/>
          <span style={{fontSize:13, fontWeight: hl?600:500, marginLeft:4, color: hl?'var(--bzr-lime)':'var(--txt-primary)'}}>{label}</span>
          {meta && <span className="right mono subtle" style={{fontSize:10}}>{meta}</span>}
        </div>
      ))}
    </div>

    <div style={{padding:'10px 16px', borderTop:'0.5px solid var(--hairline)'}}>
      <div className="card-eyebrow">SCHEDULER · ALERTS</div>
      <div className="row gap-2 mt-2">
        <span className="badge badge-tier-c">5 ELIGIBLE</span>
        <span className="badge badge-mute">12 AGING</span>
        <span className="right">
          <button className="btn btn-glass" style={{fontSize:10, padding:'3px 9px'}}>Review</button>
        </span>
      </div>
      <div className="row gap-2 mt-2">
        <span className="badge badge-tier-e">12 ORPHANS</span>
        <span className="badge badge-mute">2.4GB</span>
      </div>
    </div>

    <div style={{padding:'8px 12px', background:'rgba(0,0,0,0.20)', borderTop:'0.5px solid var(--hairline)'}}>
      <div className="row" style={{fontSize:11, color:'var(--txt-secondary)'}}>
        <span className="mono">⌘ ↑ S</span><span style={{marginLeft:8}}>Open Sojourn</span>
        <span className="right mono subtle" style={{fontSize:10}}>QUIT ⌘Q</span>
      </div>
    </div>
  </div>
);

// === DESKTOP MENUBAR (for context above the menu bar extra) ===
const DesktopMenuBar = () => (
  <div className="menubar-strip">
    <SojournMark size={12} color="var(--text-primary)"/>
    <span className="app">Sojourn</span>
    <span className="item">File</span>
    <span className="item">Edit</span>
    <span className="item">Sync</span>
    <span className="item">Window</span>
    <span className="item">Help</span>
    <span className="right">
      <span style={{display:'inline-flex',alignItems:'center',gap:4,color:'var(--bzr-lime)'}}>
        <span style={{width:14, height:14, display:'inline-flex',alignItems:'center'}}><SojournMark size={12} color="var(--bzr-lime)"/></span>
        <span className="mono" style={{fontSize:10, letterSpacing:'0.05em'}}>↑ 3</span>
      </span>
      <Icon name="wifi" size={13}/>
      <Icon name="battery" size={14}/>
      <span className="mono" style={{fontSize:11}}>Mon 28 Apr 14:30</span>
    </span>
  </div>
);

window.BootstrapScreen = BootstrapScreen;
window.PushSheet = PushSheet;
window.PullSheet = PullSheet;
window.MenuBarExtra = MenuBarExtra;
window.DesktopMenuBar = DesktopMenuBar;
